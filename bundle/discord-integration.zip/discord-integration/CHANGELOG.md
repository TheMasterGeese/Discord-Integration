# Discord Integration

##  2.0.0
- Added sendDiscordMessage hook
##  1.0.0
- Discord Integraiton