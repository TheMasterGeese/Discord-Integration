// TODO discord-integration#34: Thrown on Hooks.on(), cause and fix unknown
/* eslint-disable @typescript-eslint/no-unsafe-call */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
let gameUsers;
let foundryGame;
// Discord user-ids are always exactly 18 digits.
const DISCORD_ID_LENGTH = 18;
function getGame() {
    return game;
}
Hooks.once("ready", function () {
    gameUsers = (game.users).contents;
});
Hooks.once("init", function () {
    foundryGame = getGame();
    // add settings option for URL of Discord Webhook
    foundryGame.settings.register("discord-integration", "discordWebhook", {
        name: foundryGame.i18n.localize("DISCORDINTEGRATION.SettingsDiscordWebhook"),
        hint: foundryGame.i18n.localize("DISCORDINTEGRATION.SettingsDiscordWebhookHint"),
        scope: "world",
        config: true,
        type: String,
        default: "",
    });
    // add settings option for pinging by on character name
    foundryGame.settings.register("discord-integration", "pingByCharacterName", {
        name: foundryGame.i18n.localize("DISCORDINTEGRATION.SettingsPingByCharacterName"),
        hint: foundryGame.i18n.localize("DISCORDINTEGRATION.SettingsPingByCharacterNameHint"),
        scope: "world",
        config: true,
        default: true,
        type: Boolean
    });
    // add settings option for pinging by user name
    foundryGame.settings.register("discord-integration", "pingByUserName", {
        name: foundryGame.i18n.localize("DISCORDINTEGRATION.SettingsPingByUserName"),
        hint: foundryGame.i18n.localize("DISCORDINTEGRATION.SettingsPingByUserNameHint"),
        scope: "world",
        config: true,
        default: true,
        type: Boolean
    });
});
// add in the extra field for DiscordID
Hooks.on("renderUserConfig", function (config, element) {
    return __awaiter(this, void 0, void 0, function* () {
        // find the user that you're opening config for
        const foundryUser = gameUsers.filter((user) => { return user.id === (config.object).data._id; })[0];
        // get their Discord ID if it exists
        let discordUserId = yield foundryUser.getFlag('discord-integration', 'discordID');
        discordUserId = discordUserId ? discordUserId : "";
        // create the input field to configure it.
        const discordIdInput = `<input type="text" name="discord-id-config" value="${discordUserId}" data-dtype="String">`;
        const discordIDSetting = `
        <div id="discord-id-setting" class="form-group discord">
            <label>${foundryGame.i18n.localize("DISCORDINTEGRATION.UserDiscordIdLabel")}</label>
            ${discordIdInput}
        </div>`;
        // Put the input fields below the "Player Color group" field.
        const playerColorGroup = element.find('.form-group').eq(2);
        playerColorGroup.after([$(discordIDSetting)]);
        if (foundryUser.isGM) {
            /*
            // get their GM Notification status if it exists, defaulting to true.
            const sendGMNotifications: boolean = await foundryUser.getFlag('discord-integration', 'sendGMNotifications') as boolean;
    
            
            const isChecked = sendGMNotifications ? "checked" : "";
            const gmNotificationCheckbox = `<input type="checkbox" name="gm-notification-config" ${isChecked}>`
    
            const gmNotificationSetting = `
                <div>
                    <label>${game.i18n.localize("DISCORDINTEGRATION.GMNotificationsLabel") as string}</label>
                    ${gmNotificationCheckbox}
                </div>`
            */
        }
    });
});
// commit any changes to userConfig
Hooks.on("closeUserConfig", function (config, element) {
    return __awaiter(this, void 0, void 0, function* () {
        // find the user that the config was open for
        const foundryUser = gameUsers.filter(user => { return user.id === (config.object).data._id; })[0];
        const discordID = element.find("input[name = 'discord-id-config']")[0].value;
        if (discordID.length !== DISCORD_ID_LENGTH || isNaN(parseInt(discordID))) {
            ui.notifications.error(foundryGame.i18n.localize("DISCORDINTEGRATION.InvalidIdError"));
        }
        else {
            yield foundryUser.update({ 'flags.discord-integration.discordID': discordID });
        }
        /*
        const gmNotificationElement = element.find("input[name = 'gm-notification-config']");
        let gmNotifications: boolean
        if (gmNotificationElement && gmNotificationElement[0]) {
            gmNotifications = (element.find("input[name = 'gm-notification-config']")[0] as HTMLInputElement).checked;
        }
        */
        // update the flag
        //await foundryUser.update({ 'flags.discord-integration.sendGMNotifications': gmNotifications });
    });
});
/**
 * To forward a message to discord, do one of two things:
 *
 * -include "@<username>" for a user in the game, it will then look up the corresponding discordID
 * and send a message pinging them. If you @ multiple people, it will ping all of them. Will not
 * send a message unless the username matches up with an actual user.
 *
 * -include "@Discord", which will unconditionally forward the message (minus the @Discord) to the Discord Webhook.
 */
// whenever someone sends a chat message, if it is marked up properly forward it to Discord.
Hooks.on("chatMessage", function (_chatLog, message) {
    const discordTags = [];
    discordTags.push("@Discord");
    gameUsers.forEach((user) => {
        if (game.settings.get('discord-integration', 'pingByUserName')) {
            discordTags.push(`@${user.name}`);
        }
        if (game.settings.get('discord-integration', 'pingByCharacterName') && user.character) {
            discordTags.push(`@${user.character.name}`);
        }
    });
    let shouldSendMessage = false;
    discordTags.forEach(tag => {
        if (message.includes(tag)) {
            shouldSendMessage = true;
        }
    });
    if (shouldSendMessage) {
        Hooks.callAll("sendDiscordMessage", message);
    }
    else {
        // TODO discord-integration#35: This exists as a way to test when a message is not sent. Figure out a way to do it without modifying the code later.
        console.log("Message not sent.");
    }
});
Hooks.on("sendDiscordMessage", function (message) {
    sendDiscordMessage(message).catch((reason) => {
        console.error(reason);
    });
});
/**
 * Sends a message through the discord webhook as configured in settings.
 *
 * Messages that ping users in Discord need to have "@<gameUserName>" and the users must have their discord IDs configured.
 *
 * @param message The message to forward to Discord
 */
function sendDiscordMessage(message) {
    return __awaiter(this, void 0, void 0, function* () {
        let sendMessage = true;
        const discordWebhook = game.settings.get('discord-integration', 'discordWebhook');
        if (!discordWebhook) {
            ui.notifications.error(foundryGame.i18n.localize("DISCORDINTEGRATION.CouldNotSendMessage")
                + foundryGame.i18n.localize("DISCORDINTEGRATION.NoDiscordWebhookError"));
            return;
        }
        const usersToChars = new Map();
        const usersToPing = [];
        gameUsers.forEach((user) => {
            if (message.indexOf(`@${user.name}`) !== -1) {
                usersToPing.push(user.name);
            }
            if (user.character) {
                usersToChars.set(user.name, (user.character.name));
            }
        });
        usersToChars.forEach((charName, userName, _map) => {
            // Ping if a user or their character's name is tagged
            if (message.indexOf(`@${charName}`) !== -1) {
                usersToPing.push(userName);
            }
        });
        // search for @Discord in the message
        const shouldPingDiscord = (message.search(`@Discord`) !== -1);
        // if it found any @<username> values, replace the values in the message with appropriate discord pings, then send discord message.
        if (usersToPing.length !== 0) {
            usersToPing.forEach((userName) => {
                const currentUser = gameUsers.filter((user) => { return user.data.name === userName; })[0];
                if (currentUser) {
                    const currentUserDiscordID = currentUser.getFlag('discord-integration', 'discordID');
                    if (!currentUserDiscordID) {
                        ui.notifications.error(foundryGame.i18n.localize("DISCORDINTEGRATION.CouldNotSendMessage")
                            + currentUser.name
                            + foundryGame.i18n.localize("DISCORDINTEGRATION.UserHasNoIdError"));
                        sendMessage = false;
                        return;
                    }
                    message = message.replace(`@${userName}`, `<@${currentUserDiscordID}>`);
                    message = message.replace(`@${usersToChars.get(userName)}`, `<@${currentUserDiscordID}>`);
                }
            });
            // else if Discord as a whole is being pinged, remove the "@Discord" part and then send the message.
        }
        else if (shouldPingDiscord) {
            message = message.split("@Discord").pop() || "";
        }
        const messageJSON = {
            "content": message
        };
        let jsonMessage;
        try {
            jsonMessage = JSON.stringify(messageJSON);
        }
        catch (e) {
            ui.notifications.error(foundryGame.i18n.localize("DISCORDINTEGRATION.CouldNotSendMessage")
                + foundryGame.i18n.localize("DISCORDINTEGRATION.CouldNotStringifyJsonError"));
            sendMessage = false;
        }
        if (sendMessage) {
            yield $.ajax({
                method: 'POST',
                url: discordWebhook,
                contentType: "application/json",
                data: jsonMessage
            });
        }
    });
}
export {};

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9EaXNjb3JkSW50ZWdyYXRpb24udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsMkVBQTJFO0FBQzNFLHNEQUFzRDs7Ozs7Ozs7OztBQUl0RCxJQUFJLFNBQWlDLENBQUE7QUFDckMsSUFBSSxXQUFpQixDQUFDO0FBRXRCLGlEQUFpRDtBQUNqRCxNQUFNLGlCQUFpQixHQUFHLEVBQUUsQ0FBQztBQUU3QixTQUFTLE9BQU87SUFDWixPQUFPLElBQUksQ0FBQztBQUNoQixDQUFDO0FBRUQsS0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUU7SUFDaEIsU0FBUyxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUN0QyxDQUFDLENBQUMsQ0FBQztBQUVILEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO0lBQ2YsV0FBVyxHQUFHLE9BQU8sRUFBRSxDQUFDO0lBQ3hCLGlEQUFpRDtJQUNqRCxXQUFXLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxxQkFBcUIsRUFBRSxnQkFBZ0IsRUFBRTtRQUNuRSxJQUFJLEVBQUUsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsMkNBQTJDLENBQUM7UUFDNUUsSUFBSSxFQUFFLFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLCtDQUErQyxDQUFDO1FBQ2hGLEtBQUssRUFBRSxPQUFPO1FBQ2QsTUFBTSxFQUFFLElBQUk7UUFDWixJQUFJLEVBQUUsTUFBTTtRQUNaLE9BQU8sRUFBRSxFQUFFO0tBQ2QsQ0FBQyxDQUFDO0lBQ0gsdURBQXVEO0lBQ3ZELFdBQVcsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLHFCQUFxQixFQUFFLHFCQUFxQixFQUFFO1FBQ3hFLElBQUksRUFBRSxXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxnREFBZ0QsQ0FBQztRQUNqRixJQUFJLEVBQUUsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsb0RBQW9ELENBQUM7UUFDckYsS0FBSyxFQUFFLE9BQU87UUFDZCxNQUFNLEVBQUUsSUFBSTtRQUNaLE9BQU8sRUFBRSxJQUFJO1FBQ2IsSUFBSSxFQUFFLE9BQU87S0FDaEIsQ0FBQyxDQUFDO0lBQ0gsK0NBQStDO0lBQy9DLFdBQVcsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLHFCQUFxQixFQUFFLGdCQUFnQixFQUFFO1FBQ25FLElBQUksRUFBRSxXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQywyQ0FBMkMsQ0FBQztRQUM1RSxJQUFJLEVBQUUsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsK0NBQStDLENBQUM7UUFDaEYsS0FBSyxFQUFFLE9BQU87UUFDZCxNQUFNLEVBQUUsSUFBSTtRQUNaLE9BQU8sRUFBRSxJQUFJO1FBQ2IsSUFBSSxFQUFFLE9BQU87S0FDaEIsQ0FBQyxDQUFDO0FBQ1AsQ0FBQyxDQUFDLENBQUM7QUFFSCx1Q0FBdUM7QUFDdkMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxrQkFBa0IsRUFBRSxVQUFnQixNQUFrQixFQUFFLE9BQWU7O1FBRTVFLCtDQUErQztRQUMvQyxNQUFNLFdBQVcsR0FBeUIsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQVUsRUFBRSxFQUFFLEdBQUcsT0FBTyxJQUFJLENBQUMsRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUUvSCxvQ0FBb0M7UUFDcEMsSUFBSSxhQUFhLEdBQVcsTUFBTSxXQUFXLENBQUMsT0FBTyxDQUFDLHFCQUFxQixFQUFFLFdBQVcsQ0FBVyxDQUFBO1FBQ25HLGFBQWEsR0FBRyxhQUFhLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFBO1FBRWxELDBDQUEwQztRQUMxQyxNQUFNLGNBQWMsR0FBRyxzREFBc0QsYUFBYSx3QkFBd0IsQ0FBQTtRQUVsSCxNQUFNLGdCQUFnQixHQUFHOztxQkFFUixXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyx1Q0FBdUMsQ0FBQztjQUN6RSxjQUFjO2VBQ2IsQ0FBQTtRQUVYLDZEQUE2RDtRQUM3RCxNQUFNLGdCQUFnQixHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzNELGdCQUFnQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUU5QyxJQUFJLFdBQVcsQ0FBQyxJQUFJLEVBQUU7WUFDbEI7Ozs7Ozs7Ozs7Ozs7Y0FhRTtTQUNMO0lBQ0wsQ0FBQztDQUFBLENBQUMsQ0FBQztBQUVILG1DQUFtQztBQUNuQyxLQUFLLENBQUMsRUFBRSxDQUFDLGlCQUFpQixFQUFFLFVBQWdCLE1BQWtCLEVBQUUsT0FBZTs7UUFDM0UsNkNBQTZDO1FBQzdDLE1BQU0sV0FBVyxHQUF5QixTQUFTLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFFLEdBQUcsT0FBTyxJQUFJLENBQUMsRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN2SCxNQUFNLFNBQVMsR0FBWSxPQUFPLENBQUMsSUFBSSxDQUFDLG1DQUFtQyxDQUFDLENBQUMsQ0FBQyxDQUFzQixDQUFDLEtBQUssQ0FBQztRQUUzRyxJQUFJLFNBQVMsQ0FBQyxNQUFNLEtBQUssaUJBQWlCLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFO1lBQ3RFLEVBQUUsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLG1DQUFtQyxDQUFDLENBQUMsQ0FBQTtTQUN6RjthQUFNO1lBQ0gsTUFBTSxXQUFXLENBQUMsTUFBTSxDQUFDLEVBQUUscUNBQXFDLEVBQUUsU0FBUyxFQUFFLENBQUMsQ0FBQztTQUNsRjtRQUNEOzs7Ozs7VUFNRTtRQUNGLGtCQUFrQjtRQUNsQixpR0FBaUc7SUFDckcsQ0FBQztDQUFBLENBQUMsQ0FBQztBQUVIOzs7Ozs7OztHQVFHO0FBRUgsNEZBQTRGO0FBQzVGLEtBQUssQ0FBQyxFQUFFLENBQUMsYUFBYSxFQUFFLFVBQVUsUUFBaUIsRUFBRSxPQUFlO0lBQ2hFLE1BQU0sV0FBVyxHQUFhLEVBQUUsQ0FBQztJQUNqQyxXQUFXLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBRTdCLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFXLEVBQUUsRUFBRTtRQUM5QixJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLHFCQUFxQixFQUFFLGdCQUFnQixDQUFDLEVBQUU7WUFDNUQsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFBO1NBQ3BDO1FBQ0QsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsRUFBRSxxQkFBcUIsQ0FBQyxJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUU7WUFDbkYsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFLLElBQUksQ0FBQyxTQUF1QixDQUFDLElBQUksRUFBRSxDQUFDLENBQUE7U0FDN0Q7SUFDTCxDQUFDLENBQUMsQ0FBQTtJQUVGLElBQUksaUJBQWlCLEdBQUcsS0FBSyxDQUFDO0lBQzlCLFdBQVcsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUU7UUFDdEIsSUFBSSxPQUFPLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQ3ZCLGlCQUFpQixHQUFHLElBQUksQ0FBQztTQUM1QjtJQUNMLENBQUMsQ0FBQyxDQUFBO0lBRUYsSUFBSSxpQkFBaUIsRUFBRTtRQUNuQixLQUFLLENBQUMsT0FBTyxDQUFDLG9CQUFvQixFQUFFLE9BQU8sQ0FBQyxDQUFDO0tBQ2hEO1NBQU07UUFDSCxvSkFBb0o7UUFDcEosT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFBO0tBQ25DO0FBQ0wsQ0FBQyxDQUFDLENBQUM7QUFFSCxLQUFLLENBQUMsRUFBRSxDQUFDLG9CQUFvQixFQUFFLFVBQVUsT0FBZTtJQUNwRCxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLEVBQUUsRUFBRTtRQUN6QyxPQUFPLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQzFCLENBQUMsQ0FBQyxDQUFDO0FBQ1AsQ0FBQyxDQUFDLENBQUM7QUFFSDs7Ozs7O0dBTUc7QUFDSCxTQUFlLGtCQUFrQixDQUFDLE9BQWU7O1FBRTdDLElBQUksV0FBVyxHQUFHLElBQUksQ0FBQztRQUV2QixNQUFNLGNBQWMsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsRUFBRSxnQkFBZ0IsQ0FBVyxDQUFDO1FBQzVGLElBQUksQ0FBQyxjQUFjLEVBQUU7WUFDakIsRUFBRSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQ2xCLFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLHdDQUF3QyxDQUFDO2tCQUNqRSxXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQywwQ0FBMEMsQ0FBQyxDQUFDLENBQUE7WUFDNUUsT0FBTztTQUNWO1FBRUQsTUFBTSxZQUFZLEdBQXdCLElBQUksR0FBRyxFQUFrQixDQUFDO1FBRXBFLE1BQU0sV0FBVyxHQUFhLEVBQUUsQ0FBQztRQUVqQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBVSxFQUFFLEVBQUU7WUFDN0IsSUFBSSxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUU7Z0JBQ3pDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQy9CO1lBQ0QsSUFBSSxJQUFJLENBQUMsU0FBUyxFQUFFO2dCQUNoQixZQUFZLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBRSxJQUFJLENBQUMsU0FBdUIsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2FBQ3JFO1FBQ0wsQ0FBQyxDQUFDLENBQUE7UUFFRixZQUFZLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBaUIsRUFBRSxRQUFpQixFQUFFLElBQUksRUFBRSxFQUFFO1lBQ2hFLHFEQUFxRDtZQUNyRCxJQUFJLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxRQUFRLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFO2dCQUN4QyxXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2FBQzlCO1FBQ0wsQ0FBQyxDQUFDLENBQUE7UUFFRixxQ0FBcUM7UUFDckMsTUFBTSxpQkFBaUIsR0FBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUV2RSxtSUFBbUk7UUFDbkksSUFBSSxXQUFXLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUMxQixXQUFXLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBZ0IsRUFBRSxFQUFFO2dCQUNyQyxNQUFNLFdBQVcsR0FBcUIsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQVUsRUFBRSxFQUFFLEdBQUcsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksS0FBSyxRQUFRLENBQUEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDbEgsSUFBSSxXQUFXLEVBQUU7b0JBQ2IsTUFBTSxvQkFBb0IsR0FBVyxXQUFXLENBQUMsT0FBTyxDQUFDLHFCQUFxQixFQUFFLFdBQVcsQ0FBVyxDQUFDO29CQUN2RyxJQUFJLENBQUMsb0JBQW9CLEVBQUU7d0JBQ3ZCLEVBQUUsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUNsQixXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyx3Q0FBd0MsQ0FBQzs4QkFDakUsV0FBVyxDQUFDLElBQUk7OEJBQ2hCLFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLHFDQUFxQyxDQUFDLENBQUMsQ0FBQTt3QkFDdkUsV0FBVyxHQUFHLEtBQUssQ0FBQzt3QkFDcEIsT0FBTztxQkFDVjtvQkFDRCxPQUFPLEdBQUcsT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLFFBQVEsRUFBRSxFQUFFLEtBQUssb0JBQW9CLEdBQUcsQ0FBQyxDQUFDO29CQUN4RSxPQUFPLEdBQUcsT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLFlBQVksQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEVBQUUsRUFBRSxLQUFLLG9CQUFvQixHQUFHLENBQUMsQ0FBQztpQkFDN0Y7WUFDTCxDQUFDLENBQUMsQ0FBQTtZQUNGLG9HQUFvRztTQUN2RzthQUFNLElBQUksaUJBQWlCLEVBQUU7WUFDMUIsT0FBTyxHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsR0FBRyxFQUFFLElBQUksRUFBRSxDQUFDO1NBQ25EO1FBRUQsTUFBTSxXQUFXLEdBQUc7WUFDaEIsU0FBUyxFQUFFLE9BQU87U0FDckIsQ0FBQTtRQUVELElBQUksV0FBbUIsQ0FBQztRQUN4QixJQUFJO1lBQ0EsV0FBVyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUM7U0FDN0M7UUFBQyxPQUFPLENBQUMsRUFBRTtZQUNSLEVBQUUsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUNsQixXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyx3Q0FBd0MsQ0FBQztrQkFDakUsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsK0NBQStDLENBQUMsQ0FBQyxDQUFBO1lBQ2pGLFdBQVcsR0FBRyxLQUFLLENBQUM7U0FDdkI7UUFFRCxJQUFJLFdBQVcsRUFBRTtZQUNiLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDVCxNQUFNLEVBQUUsTUFBTTtnQkFDZCxHQUFHLEVBQUUsY0FBYztnQkFDbkIsV0FBVyxFQUFFLGtCQUFrQjtnQkFDL0IsSUFBSSxFQUFFLFdBQVc7YUFDcEIsQ0FBQyxDQUFDO1NBQ047SUFDTCxDQUFDO0NBQUEiLCJmaWxlIjoiRGlzY29yZEludGVncmF0aW9uLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLy8gVE9ETyBkaXNjb3JkLWludGVncmF0aW9uIzM0OiBUaHJvd24gb24gSG9va3Mub24oKSwgY2F1c2UgYW5kIGZpeCB1bmtub3duXHJcbi8qIGVzbGludC1kaXNhYmxlIEB0eXBlc2NyaXB0LWVzbGludC9uby11bnNhZmUtY2FsbCAqL1xyXG5cclxuaW1wb3J0IHsgQWN0b3JEYXRhIH0gZnJvbSBcIkBsZWFndWUtb2YtZm91bmRyeS1kZXZlbG9wZXJzL2ZvdW5kcnktdnR0LXR5cGVzL3NyYy9mb3VuZHJ5L2NvbW1vbi9kYXRhL2RhdGEubWpzL2FjdG9yRGF0YVwiO1xyXG5cclxubGV0IGdhbWVVc2VyczogU3RvcmVkRG9jdW1lbnQ8VXNlcj5bXVxyXG5sZXQgZm91bmRyeUdhbWU6IEdhbWU7XHJcblxyXG4vLyBEaXNjb3JkIHVzZXItaWRzIGFyZSBhbHdheXMgZXhhY3RseSAxOCBkaWdpdHMuXHJcbmNvbnN0IERJU0NPUkRfSURfTEVOR1RIID0gMTg7XHJcblxyXG5mdW5jdGlvbiBnZXRHYW1lKCk6IEdhbWUge1xyXG4gICAgcmV0dXJuIGdhbWU7XHJcbn1cclxuXHJcbkhvb2tzLm9uY2UoXCJyZWFkeVwiLCBmdW5jdGlvbiAoKSB7XHJcbiAgICBnYW1lVXNlcnMgPSAoZ2FtZS51c2VycykuY29udGVudHM7XHJcbn0pO1xyXG5cclxuSG9va3Mub25jZShcImluaXRcIiwgZnVuY3Rpb24gKCkge1xyXG4gICAgZm91bmRyeUdhbWUgPSBnZXRHYW1lKCk7XHJcbiAgICAvLyBhZGQgc2V0dGluZ3Mgb3B0aW9uIGZvciBVUkwgb2YgRGlzY29yZCBXZWJob29rXHJcbiAgICBmb3VuZHJ5R2FtZS5zZXR0aW5ncy5yZWdpc3RlcihcImRpc2NvcmQtaW50ZWdyYXRpb25cIiwgXCJkaXNjb3JkV2ViaG9va1wiLCB7XHJcbiAgICAgICAgbmFtZTogZm91bmRyeUdhbWUuaTE4bi5sb2NhbGl6ZShcIkRJU0NPUkRJTlRFR1JBVElPTi5TZXR0aW5nc0Rpc2NvcmRXZWJob29rXCIpLFxyXG4gICAgICAgIGhpbnQ6IGZvdW5kcnlHYW1lLmkxOG4ubG9jYWxpemUoXCJESVNDT1JESU5URUdSQVRJT04uU2V0dGluZ3NEaXNjb3JkV2ViaG9va0hpbnRcIiksXHJcbiAgICAgICAgc2NvcGU6IFwid29ybGRcIixcclxuICAgICAgICBjb25maWc6IHRydWUsXHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIGRlZmF1bHQ6IFwiXCIsXHJcbiAgICB9KTtcclxuICAgIC8vIGFkZCBzZXR0aW5ncyBvcHRpb24gZm9yIHBpbmdpbmcgYnkgb24gY2hhcmFjdGVyIG5hbWVcclxuICAgIGZvdW5kcnlHYW1lLnNldHRpbmdzLnJlZ2lzdGVyKFwiZGlzY29yZC1pbnRlZ3JhdGlvblwiLCBcInBpbmdCeUNoYXJhY3Rlck5hbWVcIiwge1xyXG4gICAgICAgIG5hbWU6IGZvdW5kcnlHYW1lLmkxOG4ubG9jYWxpemUoXCJESVNDT1JESU5URUdSQVRJT04uU2V0dGluZ3NQaW5nQnlDaGFyYWN0ZXJOYW1lXCIpLFxyXG4gICAgICAgIGhpbnQ6IGZvdW5kcnlHYW1lLmkxOG4ubG9jYWxpemUoXCJESVNDT1JESU5URUdSQVRJT04uU2V0dGluZ3NQaW5nQnlDaGFyYWN0ZXJOYW1lSGludFwiKSxcclxuICAgICAgICBzY29wZTogXCJ3b3JsZFwiLFxyXG4gICAgICAgIGNvbmZpZzogdHJ1ZSxcclxuICAgICAgICBkZWZhdWx0OiB0cnVlLFxyXG4gICAgICAgIHR5cGU6IEJvb2xlYW5cclxuICAgIH0pO1xyXG4gICAgLy8gYWRkIHNldHRpbmdzIG9wdGlvbiBmb3IgcGluZ2luZyBieSB1c2VyIG5hbWVcclxuICAgIGZvdW5kcnlHYW1lLnNldHRpbmdzLnJlZ2lzdGVyKFwiZGlzY29yZC1pbnRlZ3JhdGlvblwiLCBcInBpbmdCeVVzZXJOYW1lXCIsIHtcclxuICAgICAgICBuYW1lOiBmb3VuZHJ5R2FtZS5pMThuLmxvY2FsaXplKFwiRElTQ09SRElOVEVHUkFUSU9OLlNldHRpbmdzUGluZ0J5VXNlck5hbWVcIiksXHJcbiAgICAgICAgaGludDogZm91bmRyeUdhbWUuaTE4bi5sb2NhbGl6ZShcIkRJU0NPUkRJTlRFR1JBVElPTi5TZXR0aW5nc1BpbmdCeVVzZXJOYW1lSGludFwiKSxcclxuICAgICAgICBzY29wZTogXCJ3b3JsZFwiLFxyXG4gICAgICAgIGNvbmZpZzogdHJ1ZSxcclxuICAgICAgICBkZWZhdWx0OiB0cnVlLFxyXG4gICAgICAgIHR5cGU6IEJvb2xlYW5cclxuICAgIH0pO1xyXG59KTtcclxuXHJcbi8vIGFkZCBpbiB0aGUgZXh0cmEgZmllbGQgZm9yIERpc2NvcmRJRFxyXG5Ib29rcy5vbihcInJlbmRlclVzZXJDb25maWdcIiwgYXN5bmMgZnVuY3Rpb24gKGNvbmZpZzogVXNlckNvbmZpZywgZWxlbWVudDogSlF1ZXJ5KSB7XHJcblxyXG4gICAgLy8gZmluZCB0aGUgdXNlciB0aGF0IHlvdSdyZSBvcGVuaW5nIGNvbmZpZyBmb3JcclxuICAgIGNvbnN0IGZvdW5kcnlVc2VyOiBTdG9yZWREb2N1bWVudDxVc2VyPiA9IGdhbWVVc2Vycy5maWx0ZXIoKHVzZXI6IFVzZXIpID0+IHsgcmV0dXJuIHVzZXIuaWQgPT09IChjb25maWcub2JqZWN0KS5kYXRhLl9pZCB9KVswXTtcclxuXHJcbiAgICAvLyBnZXQgdGhlaXIgRGlzY29yZCBJRCBpZiBpdCBleGlzdHNcclxuICAgIGxldCBkaXNjb3JkVXNlcklkOiBzdHJpbmcgPSBhd2FpdCBmb3VuZHJ5VXNlci5nZXRGbGFnKCdkaXNjb3JkLWludGVncmF0aW9uJywgJ2Rpc2NvcmRJRCcpIGFzIHN0cmluZ1xyXG4gICAgZGlzY29yZFVzZXJJZCA9IGRpc2NvcmRVc2VySWQgPyBkaXNjb3JkVXNlcklkIDogXCJcIlxyXG5cclxuICAgIC8vIGNyZWF0ZSB0aGUgaW5wdXQgZmllbGQgdG8gY29uZmlndXJlIGl0LlxyXG4gICAgY29uc3QgZGlzY29yZElkSW5wdXQgPSBgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgbmFtZT1cImRpc2NvcmQtaWQtY29uZmlnXCIgdmFsdWU9XCIke2Rpc2NvcmRVc2VySWR9XCIgZGF0YS1kdHlwZT1cIlN0cmluZ1wiPmBcclxuXHJcbiAgICBjb25zdCBkaXNjb3JkSURTZXR0aW5nID0gYFxyXG4gICAgICAgIDxkaXYgaWQ9XCJkaXNjb3JkLWlkLXNldHRpbmdcIiBjbGFzcz1cImZvcm0tZ3JvdXAgZGlzY29yZFwiPlxyXG4gICAgICAgICAgICA8bGFiZWw+JHtmb3VuZHJ5R2FtZS5pMThuLmxvY2FsaXplKFwiRElTQ09SRElOVEVHUkFUSU9OLlVzZXJEaXNjb3JkSWRMYWJlbFwiKX08L2xhYmVsPlxyXG4gICAgICAgICAgICAke2Rpc2NvcmRJZElucHV0fVxyXG4gICAgICAgIDwvZGl2PmBcclxuXHJcbiAgICAvLyBQdXQgdGhlIGlucHV0IGZpZWxkcyBiZWxvdyB0aGUgXCJQbGF5ZXIgQ29sb3IgZ3JvdXBcIiBmaWVsZC5cclxuICAgIGNvbnN0IHBsYXllckNvbG9yR3JvdXAgPSBlbGVtZW50LmZpbmQoJy5mb3JtLWdyb3VwJykuZXEoMik7XHJcbiAgICBwbGF5ZXJDb2xvckdyb3VwLmFmdGVyKFskKGRpc2NvcmRJRFNldHRpbmcpXSk7XHJcblxyXG4gICAgaWYgKGZvdW5kcnlVc2VyLmlzR00pIHtcclxuICAgICAgICAvKlxyXG4gICAgICAgIC8vIGdldCB0aGVpciBHTSBOb3RpZmljYXRpb24gc3RhdHVzIGlmIGl0IGV4aXN0cywgZGVmYXVsdGluZyB0byB0cnVlLlxyXG4gICAgICAgIGNvbnN0IHNlbmRHTU5vdGlmaWNhdGlvbnM6IGJvb2xlYW4gPSBhd2FpdCBmb3VuZHJ5VXNlci5nZXRGbGFnKCdkaXNjb3JkLWludGVncmF0aW9uJywgJ3NlbmRHTU5vdGlmaWNhdGlvbnMnKSBhcyBib29sZWFuO1xyXG5cclxuICAgICAgICBcclxuICAgICAgICBjb25zdCBpc0NoZWNrZWQgPSBzZW5kR01Ob3RpZmljYXRpb25zID8gXCJjaGVja2VkXCIgOiBcIlwiO1xyXG4gICAgICAgIGNvbnN0IGdtTm90aWZpY2F0aW9uQ2hlY2tib3ggPSBgPGlucHV0IHR5cGU9XCJjaGVja2JveFwiIG5hbWU9XCJnbS1ub3RpZmljYXRpb24tY29uZmlnXCIgJHtpc0NoZWNrZWR9PmBcclxuXHJcbiAgICAgICAgY29uc3QgZ21Ob3RpZmljYXRpb25TZXR0aW5nID0gYFxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsPiR7Z2FtZS5pMThuLmxvY2FsaXplKFwiRElTQ09SRElOVEVHUkFUSU9OLkdNTm90aWZpY2F0aW9uc0xhYmVsXCIpIGFzIHN0cmluZ308L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgJHtnbU5vdGlmaWNhdGlvbkNoZWNrYm94fVxyXG4gICAgICAgICAgICA8L2Rpdj5gXHJcbiAgICAgICAgKi9cclxuICAgIH1cclxufSk7XHJcblxyXG4vLyBjb21taXQgYW55IGNoYW5nZXMgdG8gdXNlckNvbmZpZ1xyXG5Ib29rcy5vbihcImNsb3NlVXNlckNvbmZpZ1wiLCBhc3luYyBmdW5jdGlvbiAoY29uZmlnOiBVc2VyQ29uZmlnLCBlbGVtZW50OiBKUXVlcnkpIHtcclxuICAgIC8vIGZpbmQgdGhlIHVzZXIgdGhhdCB0aGUgY29uZmlnIHdhcyBvcGVuIGZvclxyXG4gICAgY29uc3QgZm91bmRyeVVzZXI6IFN0b3JlZERvY3VtZW50PFVzZXI+ID0gZ2FtZVVzZXJzLmZpbHRlcih1c2VyID0+IHsgcmV0dXJuIHVzZXIuaWQgPT09IChjb25maWcub2JqZWN0KS5kYXRhLl9pZCB9KVswXTtcclxuICAgIGNvbnN0IGRpc2NvcmRJRDogc3RyaW5nID0gKGVsZW1lbnQuZmluZChcImlucHV0W25hbWUgPSAnZGlzY29yZC1pZC1jb25maWcnXVwiKVswXSBhcyBIVE1MSW5wdXRFbGVtZW50KS52YWx1ZTtcclxuXHJcbiAgICBpZiAoZGlzY29yZElELmxlbmd0aCAhPT0gRElTQ09SRF9JRF9MRU5HVEggfHwgaXNOYU4ocGFyc2VJbnQoZGlzY29yZElEKSkpIHtcclxuICAgICAgICB1aS5ub3RpZmljYXRpb25zLmVycm9yKGZvdW5kcnlHYW1lLmkxOG4ubG9jYWxpemUoXCJESVNDT1JESU5URUdSQVRJT04uSW52YWxpZElkRXJyb3JcIikpXHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIGF3YWl0IGZvdW5kcnlVc2VyLnVwZGF0ZSh7ICdmbGFncy5kaXNjb3JkLWludGVncmF0aW9uLmRpc2NvcmRJRCc6IGRpc2NvcmRJRCB9KTtcclxuICAgIH1cclxuICAgIC8qXHJcbiAgICBjb25zdCBnbU5vdGlmaWNhdGlvbkVsZW1lbnQgPSBlbGVtZW50LmZpbmQoXCJpbnB1dFtuYW1lID0gJ2dtLW5vdGlmaWNhdGlvbi1jb25maWcnXVwiKTtcclxuICAgIGxldCBnbU5vdGlmaWNhdGlvbnM6IGJvb2xlYW5cclxuICAgIGlmIChnbU5vdGlmaWNhdGlvbkVsZW1lbnQgJiYgZ21Ob3RpZmljYXRpb25FbGVtZW50WzBdKSB7XHJcbiAgICAgICAgZ21Ob3RpZmljYXRpb25zID0gKGVsZW1lbnQuZmluZChcImlucHV0W25hbWUgPSAnZ20tbm90aWZpY2F0aW9uLWNvbmZpZyddXCIpWzBdIGFzIEhUTUxJbnB1dEVsZW1lbnQpLmNoZWNrZWQ7XHJcbiAgICB9XHJcbiAgICAqL1xyXG4gICAgLy8gdXBkYXRlIHRoZSBmbGFnXHJcbiAgICAvL2F3YWl0IGZvdW5kcnlVc2VyLnVwZGF0ZSh7ICdmbGFncy5kaXNjb3JkLWludGVncmF0aW9uLnNlbmRHTU5vdGlmaWNhdGlvbnMnOiBnbU5vdGlmaWNhdGlvbnMgfSk7XHJcbn0pO1xyXG5cclxuLyoqXHJcbiAqIFRvIGZvcndhcmQgYSBtZXNzYWdlIHRvIGRpc2NvcmQsIGRvIG9uZSBvZiB0d28gdGhpbmdzOlxyXG4gKiBcclxuICogLWluY2x1ZGUgXCJAPHVzZXJuYW1lPlwiIGZvciBhIHVzZXIgaW4gdGhlIGdhbWUsIGl0IHdpbGwgdGhlbiBsb29rIHVwIHRoZSBjb3JyZXNwb25kaW5nIGRpc2NvcmRJRCBcclxuICogYW5kIHNlbmQgYSBtZXNzYWdlIHBpbmdpbmcgdGhlbS4gSWYgeW91IEAgbXVsdGlwbGUgcGVvcGxlLCBpdCB3aWxsIHBpbmcgYWxsIG9mIHRoZW0uIFdpbGwgbm90XHJcbiAqIHNlbmQgYSBtZXNzYWdlIHVubGVzcyB0aGUgdXNlcm5hbWUgbWF0Y2hlcyB1cCB3aXRoIGFuIGFjdHVhbCB1c2VyLlxyXG4gKiBcclxuICogLWluY2x1ZGUgXCJARGlzY29yZFwiLCB3aGljaCB3aWxsIHVuY29uZGl0aW9uYWxseSBmb3J3YXJkIHRoZSBtZXNzYWdlIChtaW51cyB0aGUgQERpc2NvcmQpIHRvIHRoZSBEaXNjb3JkIFdlYmhvb2suXHJcbiAqL1xyXG5cclxuLy8gd2hlbmV2ZXIgc29tZW9uZSBzZW5kcyBhIGNoYXQgbWVzc2FnZSwgaWYgaXQgaXMgbWFya2VkIHVwIHByb3Blcmx5IGZvcndhcmQgaXQgdG8gRGlzY29yZC5cclxuSG9va3Mub24oXCJjaGF0TWVzc2FnZVwiLCBmdW5jdGlvbiAoX2NoYXRMb2c6IENoYXRMb2csIG1lc3NhZ2U6IHN0cmluZykge1xyXG4gICAgY29uc3QgZGlzY29yZFRhZ3M6IHN0cmluZ1tdID0gW107XHJcbiAgICBkaXNjb3JkVGFncy5wdXNoKFwiQERpc2NvcmRcIik7XHJcblxyXG4gICAgZ2FtZVVzZXJzLmZvckVhY2goKHVzZXIgOiBVc2VyKSA9PiB7XHJcbiAgICAgICAgaWYgKGdhbWUuc2V0dGluZ3MuZ2V0KCdkaXNjb3JkLWludGVncmF0aW9uJywgJ3BpbmdCeVVzZXJOYW1lJykpIHtcclxuICAgICAgICAgICAgZGlzY29yZFRhZ3MucHVzaChgQCR7dXNlci5uYW1lfWApXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChnYW1lLnNldHRpbmdzLmdldCgnZGlzY29yZC1pbnRlZ3JhdGlvbicsICdwaW5nQnlDaGFyYWN0ZXJOYW1lJykgJiYgdXNlci5jaGFyYWN0ZXIpIHtcclxuICAgICAgICAgICAgZGlzY29yZFRhZ3MucHVzaChgQCR7KHVzZXIuY2hhcmFjdGVyIGFzIEFjdG9yRGF0YSkubmFtZX1gKVxyXG4gICAgICAgIH1cclxuICAgIH0pXHJcblxyXG4gICAgbGV0IHNob3VsZFNlbmRNZXNzYWdlID0gZmFsc2U7XHJcbiAgICBkaXNjb3JkVGFncy5mb3JFYWNoKHRhZyA9PiB7XHJcbiAgICAgICAgaWYgKG1lc3NhZ2UuaW5jbHVkZXModGFnKSkge1xyXG4gICAgICAgICAgICBzaG91bGRTZW5kTWVzc2FnZSA9IHRydWU7XHJcbiAgICAgICAgfVxyXG4gICAgfSlcclxuXHJcbiAgICBpZiAoc2hvdWxkU2VuZE1lc3NhZ2UpIHtcclxuICAgICAgICBIb29rcy5jYWxsQWxsKFwic2VuZERpc2NvcmRNZXNzYWdlXCIsIG1lc3NhZ2UpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgICAvLyBUT0RPIGRpc2NvcmQtaW50ZWdyYXRpb24jMzU6IFRoaXMgZXhpc3RzIGFzIGEgd2F5IHRvIHRlc3Qgd2hlbiBhIG1lc3NhZ2UgaXMgbm90IHNlbnQuIEZpZ3VyZSBvdXQgYSB3YXkgdG8gZG8gaXQgd2l0aG91dCBtb2RpZnlpbmcgdGhlIGNvZGUgbGF0ZXIuXHJcbiAgICAgICAgY29uc29sZS5sb2coXCJNZXNzYWdlIG5vdCBzZW50LlwiKVxyXG4gICAgfVxyXG59KTtcclxuXHJcbkhvb2tzLm9uKFwic2VuZERpc2NvcmRNZXNzYWdlXCIsIGZ1bmN0aW9uIChtZXNzYWdlOiBzdHJpbmcpIHtcclxuICAgIHNlbmREaXNjb3JkTWVzc2FnZShtZXNzYWdlKS5jYXRjaCgocmVhc29uKSA9PiB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihyZWFzb24pO1xyXG4gICAgfSk7XHJcbn0pO1xyXG5cclxuLyoqXHJcbiAqIFNlbmRzIGEgbWVzc2FnZSB0aHJvdWdoIHRoZSBkaXNjb3JkIHdlYmhvb2sgYXMgY29uZmlndXJlZCBpbiBzZXR0aW5ncy5cclxuICogXHJcbiAqIE1lc3NhZ2VzIHRoYXQgcGluZyB1c2VycyBpbiBEaXNjb3JkIG5lZWQgdG8gaGF2ZSBcIkA8Z2FtZVVzZXJOYW1lPlwiIGFuZCB0aGUgdXNlcnMgbXVzdCBoYXZlIHRoZWlyIGRpc2NvcmQgSURzIGNvbmZpZ3VyZWQuXHJcbiAqIFxyXG4gKiBAcGFyYW0gbWVzc2FnZSBUaGUgbWVzc2FnZSB0byBmb3J3YXJkIHRvIERpc2NvcmRcclxuICovXHJcbmFzeW5jIGZ1bmN0aW9uIHNlbmREaXNjb3JkTWVzc2FnZShtZXNzYWdlOiBzdHJpbmcpIHtcclxuXHJcbiAgICBsZXQgc2VuZE1lc3NhZ2UgPSB0cnVlO1xyXG5cclxuICAgIGNvbnN0IGRpc2NvcmRXZWJob29rID0gZ2FtZS5zZXR0aW5ncy5nZXQoJ2Rpc2NvcmQtaW50ZWdyYXRpb24nLCAnZGlzY29yZFdlYmhvb2snKSBhcyBzdHJpbmc7XHJcbiAgICBpZiAoIWRpc2NvcmRXZWJob29rKSB7XHJcbiAgICAgICAgdWkubm90aWZpY2F0aW9ucy5lcnJvcihcclxuICAgICAgICAgICAgZm91bmRyeUdhbWUuaTE4bi5sb2NhbGl6ZShcIkRJU0NPUkRJTlRFR1JBVElPTi5Db3VsZE5vdFNlbmRNZXNzYWdlXCIpXHJcbiAgICAgICAgICAgICsgZm91bmRyeUdhbWUuaTE4bi5sb2NhbGl6ZShcIkRJU0NPUkRJTlRFR1JBVElPTi5Ob0Rpc2NvcmRXZWJob29rRXJyb3JcIikpXHJcbiAgICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IHVzZXJzVG9DaGFyczogTWFwPHN0cmluZywgc3RyaW5nPiA9IG5ldyBNYXA8c3RyaW5nLCBzdHJpbmc+KCk7XHJcblxyXG4gICAgY29uc3QgdXNlcnNUb1Bpbmc6IHN0cmluZ1tdID0gW107XHJcblxyXG4gICAgZ2FtZVVzZXJzLmZvckVhY2goKHVzZXI6IFVzZXIpID0+IHtcclxuICAgICAgICBpZiAobWVzc2FnZS5pbmRleE9mKGBAJHt1c2VyLm5hbWV9YCkgIT09IC0xKSB7XHJcbiAgICAgICAgICAgIHVzZXJzVG9QaW5nLnB1c2godXNlci5uYW1lKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHVzZXIuY2hhcmFjdGVyKSB7XHJcbiAgICAgICAgICAgIHVzZXJzVG9DaGFycy5zZXQodXNlci5uYW1lLCAoKHVzZXIuY2hhcmFjdGVyIGFzIEFjdG9yRGF0YSkubmFtZSkpO1xyXG4gICAgICAgIH1cclxuICAgIH0pXHJcblxyXG4gICAgdXNlcnNUb0NoYXJzLmZvckVhY2goKGNoYXJOYW1lIDogc3RyaW5nLCB1c2VyTmFtZSA6IHN0cmluZywgX21hcCkgPT4ge1xyXG4gICAgICAgIC8vIFBpbmcgaWYgYSB1c2VyIG9yIHRoZWlyIGNoYXJhY3RlcidzIG5hbWUgaXMgdGFnZ2VkXHJcbiAgICAgICAgaWYgKG1lc3NhZ2UuaW5kZXhPZihgQCR7Y2hhck5hbWV9YCkgIT09IC0xKSB7XHJcbiAgICAgICAgICAgIHVzZXJzVG9QaW5nLnB1c2godXNlck5hbWUpO1xyXG4gICAgICAgIH0gXHJcbiAgICB9KVxyXG4gICAgXHJcbiAgICAvLyBzZWFyY2ggZm9yIEBEaXNjb3JkIGluIHRoZSBtZXNzYWdlXHJcbiAgICBjb25zdCBzaG91bGRQaW5nRGlzY29yZDogYm9vbGVhbiA9IChtZXNzYWdlLnNlYXJjaChgQERpc2NvcmRgKSAhPT0gLTEpO1xyXG5cclxuICAgIC8vIGlmIGl0IGZvdW5kIGFueSBAPHVzZXJuYW1lPiB2YWx1ZXMsIHJlcGxhY2UgdGhlIHZhbHVlcyBpbiB0aGUgbWVzc2FnZSB3aXRoIGFwcHJvcHJpYXRlIGRpc2NvcmQgcGluZ3MsIHRoZW4gc2VuZCBkaXNjb3JkIG1lc3NhZ2UuXHJcbiAgICBpZiAodXNlcnNUb1BpbmcubGVuZ3RoICE9PSAwKSB7XHJcbiAgICAgICAgdXNlcnNUb1BpbmcuZm9yRWFjaCgodXNlck5hbWU6IHN0cmluZykgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCBjdXJyZW50VXNlcjogVXNlciB8IHVuZGVmaW5lZCA9IGdhbWVVc2Vycy5maWx0ZXIoKHVzZXI6IFVzZXIpID0+IHsgcmV0dXJuIHVzZXIuZGF0YS5uYW1lID09PSB1c2VyTmFtZSB9KVswXTtcclxuICAgICAgICAgICAgaWYgKGN1cnJlbnRVc2VyKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBjdXJyZW50VXNlckRpc2NvcmRJRDogc3RyaW5nID0gY3VycmVudFVzZXIuZ2V0RmxhZygnZGlzY29yZC1pbnRlZ3JhdGlvbicsICdkaXNjb3JkSUQnKSBhcyBzdHJpbmc7XHJcbiAgICAgICAgICAgICAgICBpZiAoIWN1cnJlbnRVc2VyRGlzY29yZElEKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdWkubm90aWZpY2F0aW9ucy5lcnJvcihcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm91bmRyeUdhbWUuaTE4bi5sb2NhbGl6ZShcIkRJU0NPUkRJTlRFR1JBVElPTi5Db3VsZE5vdFNlbmRNZXNzYWdlXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICsgY3VycmVudFVzZXIubmFtZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICArIGZvdW5kcnlHYW1lLmkxOG4ubG9jYWxpemUoXCJESVNDT1JESU5URUdSQVRJT04uVXNlckhhc05vSWRFcnJvclwiKSlcclxuICAgICAgICAgICAgICAgICAgICBzZW5kTWVzc2FnZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIG1lc3NhZ2UgPSBtZXNzYWdlLnJlcGxhY2UoYEAke3VzZXJOYW1lfWAsIGA8QCR7Y3VycmVudFVzZXJEaXNjb3JkSUR9PmApO1xyXG4gICAgICAgICAgICAgICAgbWVzc2FnZSA9IG1lc3NhZ2UucmVwbGFjZShgQCR7dXNlcnNUb0NoYXJzLmdldCh1c2VyTmFtZSl9YCwgYDxAJHtjdXJyZW50VXNlckRpc2NvcmRJRH0+YCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KVxyXG4gICAgICAgIC8vIGVsc2UgaWYgRGlzY29yZCBhcyBhIHdob2xlIGlzIGJlaW5nIHBpbmdlZCwgcmVtb3ZlIHRoZSBcIkBEaXNjb3JkXCIgcGFydCBhbmQgdGhlbiBzZW5kIHRoZSBtZXNzYWdlLlxyXG4gICAgfSBlbHNlIGlmIChzaG91bGRQaW5nRGlzY29yZCkge1xyXG4gICAgICAgIG1lc3NhZ2UgPSBtZXNzYWdlLnNwbGl0KFwiQERpc2NvcmRcIikucG9wKCkgfHwgXCJcIjtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBtZXNzYWdlSlNPTiA9IHtcclxuICAgICAgICBcImNvbnRlbnRcIjogbWVzc2FnZVxyXG4gICAgfVxyXG5cclxuICAgIGxldCBqc29uTWVzc2FnZTogc3RyaW5nO1xyXG4gICAgdHJ5IHtcclxuICAgICAgICBqc29uTWVzc2FnZSA9IEpTT04uc3RyaW5naWZ5KG1lc3NhZ2VKU09OKTtcclxuICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICB1aS5ub3RpZmljYXRpb25zLmVycm9yKFxyXG4gICAgICAgICAgICBmb3VuZHJ5R2FtZS5pMThuLmxvY2FsaXplKFwiRElTQ09SRElOVEVHUkFUSU9OLkNvdWxkTm90U2VuZE1lc3NhZ2VcIilcclxuICAgICAgICAgICAgKyBmb3VuZHJ5R2FtZS5pMThuLmxvY2FsaXplKFwiRElTQ09SRElOVEVHUkFUSU9OLkNvdWxkTm90U3RyaW5naWZ5SnNvbkVycm9yXCIpKVxyXG4gICAgICAgIHNlbmRNZXNzYWdlID0gZmFsc2U7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKHNlbmRNZXNzYWdlKSB7XHJcbiAgICAgICAgYXdhaXQgJC5hamF4KHtcclxuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXHJcbiAgICAgICAgICAgIHVybDogZGlzY29yZFdlYmhvb2ssXHJcbiAgICAgICAgICAgIGNvbnRlbnRUeXBlOiBcImFwcGxpY2F0aW9uL2pzb25cIixcclxuICAgICAgICAgICAgZGF0YToganNvbk1lc3NhZ2VcclxuICAgICAgICB9KTtcclxuICAgIH1cclxufSJdfQ==
