// TODO discord-integration#34: Thrown on Hooks.on(), cause and fix unknown
/* eslint-disable @typescript-eslint/no-unsafe-call */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
let gameUsers;
let foundryGame;
// Discord user-ids are always exactly 18 digits.
const DISCORD_ID_LENGTH = 18;
function getGame() {
    return game;
}
Hooks.once("ready", function () {
    gameUsers = (game.users).contents;
});
Hooks.once("init", function () {
    foundryGame = getGame();
    // add settings option for URL of Discord Webhook
    foundryGame.settings.register("discord-integration", "discordWebhook", {
        name: foundryGame.i18n.localize("DISCORDINTEGRATION.SettingsDiscordWebhook"),
        hint: foundryGame.i18n.localize("DISCORDINTEGRATION.SettingsDiscordWebhookHint"),
        scope: "world",
        config: true,
        type: String,
        default: "",
    });
    // add settings option for pinging by on character name
    foundryGame.settings.register("discord-integration", "pingByCharacterName", {
        name: foundryGame.i18n.localize("DISCORDINTEGRATION.SettingsPingByCharacterName"),
        hint: foundryGame.i18n.localize("DISCORDINTEGRATION.SettingsPingByCharacterNameHint"),
        scope: "world",
        config: true,
        default: true,
        type: Boolean
    });
    // add settings option for pinging by user name
    foundryGame.settings.register("discord-integration", "pingByUserName", {
        name: foundryGame.i18n.localize("DISCORDINTEGRATION.SettingsPingByUserName"),
        hint: foundryGame.i18n.localize("DISCORDINTEGRATION.SettingsPingByUserNameHint"),
        scope: "world",
        config: true,
        default: true,
        type: Boolean
    });
    // add settings option for forwarding ALL messages vs. forwarding only messages with pings.
    foundryGame.settings.register("discord-integration", "forwardAllMessages", {
        name: foundryGame.i18n.localize("DISCORDINTEGRATION.SettingsForwardAllMessages"),
        hint: foundryGame.i18n.localize("DISCORDINTEGRATION.SettingsForwardAllMessagesHint"),
        scope: "world",
        config: true,
        default: false,
        type: Boolean
    });
    // add settings option for adding the player's name to the discord message
    foundryGame.settings.register("discord-integration", "prependUserName", {
        name: foundryGame.i18n.localize("DISCORDINTEGRATION.PrependUserName"),
        hint: foundryGame.i18n.localize("DISCORDINTEGRATION.PrependUserNameHint"),
        scope: "world",
        config: true,
        default: false,
        type: Boolean
    });
});
// add in the extra field for DiscordID
Hooks.on("renderUserConfig", function (config, element) {
    return __awaiter(this, void 0, void 0, function* () {
        // find the user that you're opening config for
        const foundryUser = gameUsers.filter((user) => { return user.id === (config.object).data._id; })[0];
        // get their Discord ID if it exists
        let discordUserId = yield foundryUser.getFlag('discord-integration', 'discordID');
        discordUserId = discordUserId ? discordUserId : "";
        // create the input field to configure it.
        const discordIdInput = `<input type="text" name="discord-id-config" value="${discordUserId}" data-dtype="String">`;
        const discordIDSetting = `
        <div id="discord-id-setting" class="form-group discord">
            <label>${foundryGame.i18n.localize("DISCORDINTEGRATION.UserDiscordIdLabel")}</label>
            ${discordIdInput}
        </div>`;
        // Put the input fields below the "Player Color group" field.
        const playerColorGroup = element.find('.form-group').eq(2);
        playerColorGroup.after([$(discordIDSetting)]);
        if (foundryUser.isGM) {
            /*
            // get their GM Notification status if it exists, defaulting to true.
            const sendGMNotifications: boolean = await foundryUser.getFlag('discord-integration', 'sendGMNotifications') as boolean;
    
            
            const isChecked = sendGMNotifications ? "checked" : "";
            const gmNotificationCheckbox = `<input type="checkbox" name="gm-notification-config" ${isChecked}>`
    
            const gmNotificationSetting = `
                <div>
                    <label>${game.i18n.localize("DISCORDINTEGRATION.GMNotificationsLabel") as string}</label>
                    ${gmNotificationCheckbox}
                </div>`
            */
        }
    });
});
// commit any changes to userConfig
Hooks.on("closeUserConfig", function (config, element) {
    return __awaiter(this, void 0, void 0, function* () {
        // find the user that the config was open for
        const foundryUser = gameUsers.filter(user => { return user.id === (config.object).data._id; })[0];
        const discordID = element.find("input[name = 'discord-id-config']")[0].value;
        if (discordID.length !== DISCORD_ID_LENGTH || isNaN(parseInt(discordID))) {
            ui.notifications.error(foundryGame.i18n.localize("DISCORDINTEGRATION.InvalidIdError"));
        }
        else {
            yield foundryUser.update({ 'flags.discord-integration.discordID': discordID });
        }
        /*
        const gmNotificationElement = element.find("input[name = 'gm-notification-config']");
        let gmNotifications: boolean
        if (gmNotificationElement && gmNotificationElement[0]) {
            gmNotifications = (element.find("input[name = 'gm-notification-config']")[0] as HTMLInputElement).checked;
        }
        */
        // update the flag
        //await foundryUser.update({ 'flags.discord-integration.sendGMNotifications': gmNotifications });
    });
});
/**
 * To forward a message to discord, do one of two things:
 *
 * -include "@<username>" for a user in the game, it will then look up the corresponding discordID
 * and send a message pinging them. If you @ multiple people, it will ping all of them. Will not
 * send a message unless the username matches up with an actual user.
 *
 * -include "@Discord", which will unconditionally forward the message (minus the @Discord) to the Discord Webhook.
 */
// whenever someone sends a chat message, if it is marked up properly forward it to Discord.
Hooks.on("chatMessage", function (_chatLog, message, messageData) {
    const discordTags = [];
    discordTags.push("@Discord");
    let shouldSendMessage = false;
    if (game.settings.get('discord-integration', 'forwardAllMessages')) {
        shouldSendMessage = true;
    }
    else {
        gameUsers.forEach((user) => {
            if (game.settings.get('discord-integration', 'pingByUserName')) {
                discordTags.push(`@${user.name}`);
            }
            if (game.settings.get('discord-integration', 'pingByCharacterName') && user.character) {
                discordTags.push(`@${user.character.name}`);
            }
        });
        discordTags.forEach(tag => {
            if (message.includes(tag)) {
                shouldSendMessage = true;
            }
        });
    }
    if (shouldSendMessage) {
        // If we are appending the sender's name to the message, we do so here.
        if (game.settings.get('discord-integration', 'prependUserName')) {
            const messageSenderId = messageData.user;
            const messageSender = gameUsers.find(user => user.id === messageSenderId);
            message = messageSender.name + ": " + message;
        }
        Hooks.callAll("sendDiscordMessage", message);
    }
    else {
        // TODO discord-integration#35: This exists as a way to test when a message is not sent. Figure out a way to do it without modifying the code later.
        console.log("Message not sent.");
    }
});
Hooks.on("sendDiscordMessage", function (message) {
    sendDiscordMessage(message).catch((reason) => {
        console.error(reason);
    });
});
/**
 * Sends a message through the discord webhook as configured in settings.
 *
 * Messages that ping users in Discord need to have "@<gameUserName>" and the users must have their discord IDs configured.
 *
 * @param message The message to forward to Discord
 */
function sendDiscordMessage(message) {
    return __awaiter(this, void 0, void 0, function* () {
        let sendMessage = true;
        const discordWebhook = game.settings.get('discord-integration', 'discordWebhook');
        if (!discordWebhook) {
            ui.notifications.error(foundryGame.i18n.localize("DISCORDINTEGRATION.CouldNotSendMessage")
                + foundryGame.i18n.localize("DISCORDINTEGRATION.NoDiscordWebhookError"));
            return;
        }
        const usersToChars = new Map();
        const usersToPing = [];
        gameUsers.forEach((user) => {
            if (message.indexOf(`@${user.name}`) !== -1) {
                usersToPing.push(user.name);
            }
            if (user.character) {
                usersToChars.set(user.name, (user.character.name));
            }
        });
        usersToChars.forEach((charName, userName, _map) => {
            // Ping if a user or their character's name is tagged
            if (message.indexOf(`@${charName}`) !== -1) {
                usersToPing.push(userName);
            }
        });
        // search for @Discord in the message
        const shouldPingDiscord = (message.search(`@Discord`) !== -1);
        // if it found any @<username> values, replace the values in the message with appropriate discord pings, then send discord message.
        if (usersToPing.length !== 0) {
            usersToPing.forEach((userName) => {
                const currentUser = gameUsers.filter((user) => { return user.data.name === userName; })[0];
                if (currentUser) {
                    const currentUserDiscordID = currentUser.getFlag('discord-integration', 'discordID');
                    if (!currentUserDiscordID) {
                        ui.notifications.error(foundryGame.i18n.localize("DISCORDINTEGRATION.CouldNotSendMessage")
                            + currentUser.name
                            + foundryGame.i18n.localize("DISCORDINTEGRATION.UserHasNoIdError"));
                        sendMessage = false;
                        return;
                    }
                    message = message.replace(`@${userName}`, `<@${currentUserDiscordID}>`);
                    message = message.replace(`@${usersToChars.get(userName)}`, `<@${currentUserDiscordID}>`);
                }
            });
            // else if Discord as a whole is being pinged, remove the "@Discord" part and then send the message.
        }
        else if (shouldPingDiscord) {
            message = message.replace("@Discord ", "") || "";
        }
        const messageJSON = {
            "content": message
        };
        let jsonMessage;
        try {
            jsonMessage = JSON.stringify(messageJSON);
        }
        catch (e) {
            ui.notifications.error(foundryGame.i18n.localize("DISCORDINTEGRATION.CouldNotSendMessage")
                + foundryGame.i18n.localize("DISCORDINTEGRATION.CouldNotStringifyJsonError"));
            sendMessage = false;
        }
        if (sendMessage) {
            yield $.ajax({
                method: 'POST',
                url: discordWebhook,
                contentType: "application/json",
                data: jsonMessage
            });
        }
    });
}
class ChatMessageData {
}
export {};

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9EaXNjb3JkSW50ZWdyYXRpb24udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsMkVBQTJFO0FBQzNFLHNEQUFzRDs7Ozs7Ozs7OztBQUl0RCxJQUFJLFNBQWlDLENBQUE7QUFDckMsSUFBSSxXQUFpQixDQUFDO0FBRXRCLGlEQUFpRDtBQUNqRCxNQUFNLGlCQUFpQixHQUFHLEVBQUUsQ0FBQztBQUU3QixTQUFTLE9BQU87SUFDWixPQUFPLElBQUksQ0FBQztBQUNoQixDQUFDO0FBRUQsS0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUU7SUFDaEIsU0FBUyxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUN0QyxDQUFDLENBQUMsQ0FBQztBQUVILEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO0lBQ2YsV0FBVyxHQUFHLE9BQU8sRUFBRSxDQUFDO0lBQ3hCLGlEQUFpRDtJQUNqRCxXQUFXLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxxQkFBcUIsRUFBRSxnQkFBZ0IsRUFBRTtRQUNuRSxJQUFJLEVBQUUsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsMkNBQTJDLENBQUM7UUFDNUUsSUFBSSxFQUFFLFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLCtDQUErQyxDQUFDO1FBQ2hGLEtBQUssRUFBRSxPQUFPO1FBQ2QsTUFBTSxFQUFFLElBQUk7UUFDWixJQUFJLEVBQUUsTUFBTTtRQUNaLE9BQU8sRUFBRSxFQUFFO0tBQ2QsQ0FBQyxDQUFDO0lBQ0gsdURBQXVEO0lBQ3ZELFdBQVcsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLHFCQUFxQixFQUFFLHFCQUFxQixFQUFFO1FBQ3hFLElBQUksRUFBRSxXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxnREFBZ0QsQ0FBQztRQUNqRixJQUFJLEVBQUUsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsb0RBQW9ELENBQUM7UUFDckYsS0FBSyxFQUFFLE9BQU87UUFDZCxNQUFNLEVBQUUsSUFBSTtRQUNaLE9BQU8sRUFBRSxJQUFJO1FBQ2IsSUFBSSxFQUFFLE9BQU87S0FDaEIsQ0FBQyxDQUFDO0lBQ0gsK0NBQStDO0lBQy9DLFdBQVcsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLHFCQUFxQixFQUFFLGdCQUFnQixFQUFFO1FBQ25FLElBQUksRUFBRSxXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQywyQ0FBMkMsQ0FBQztRQUM1RSxJQUFJLEVBQUUsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsK0NBQStDLENBQUM7UUFDaEYsS0FBSyxFQUFFLE9BQU87UUFDZCxNQUFNLEVBQUUsSUFBSTtRQUNaLE9BQU8sRUFBRSxJQUFJO1FBQ2IsSUFBSSxFQUFFLE9BQU87S0FDaEIsQ0FBQyxDQUFDO0lBQ0gsMkZBQTJGO0lBQzNGLFdBQVcsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLHFCQUFxQixFQUFFLG9CQUFvQixFQUFFO1FBQ3ZFLElBQUksRUFBRSxXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQywrQ0FBK0MsQ0FBQztRQUNoRixJQUFJLEVBQUUsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsbURBQW1ELENBQUM7UUFDcEYsS0FBSyxFQUFFLE9BQU87UUFDZCxNQUFNLEVBQUUsSUFBSTtRQUNaLE9BQU8sRUFBRSxLQUFLO1FBQ2QsSUFBSSxFQUFFLE9BQU87S0FDaEIsQ0FBQyxDQUFDO0lBQ0gsMEVBQTBFO0lBQzFFLFdBQVcsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLHFCQUFxQixFQUFFLGlCQUFpQixFQUFFO1FBQ3BFLElBQUksRUFBRSxXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxvQ0FBb0MsQ0FBQztRQUNyRSxJQUFJLEVBQUUsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsd0NBQXdDLENBQUM7UUFDekUsS0FBSyxFQUFFLE9BQU87UUFDZCxNQUFNLEVBQUUsSUFBSTtRQUNaLE9BQU8sRUFBRSxLQUFLO1FBQ2QsSUFBSSxFQUFFLE9BQU87S0FDaEIsQ0FBQyxDQUFDO0FBQ1AsQ0FBQyxDQUFDLENBQUM7QUFFSCx1Q0FBdUM7QUFDdkMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxrQkFBa0IsRUFBRSxVQUFnQixNQUFrQixFQUFFLE9BQWU7O1FBRTVFLCtDQUErQztRQUMvQyxNQUFNLFdBQVcsR0FBeUIsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQVUsRUFBRSxFQUFFLEdBQUcsT0FBTyxJQUFJLENBQUMsRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUUvSCxvQ0FBb0M7UUFDcEMsSUFBSSxhQUFhLEdBQVcsTUFBTSxXQUFXLENBQUMsT0FBTyxDQUFDLHFCQUFxQixFQUFFLFdBQVcsQ0FBVyxDQUFBO1FBQ25HLGFBQWEsR0FBRyxhQUFhLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFBO1FBRWxELDBDQUEwQztRQUMxQyxNQUFNLGNBQWMsR0FBRyxzREFBc0QsYUFBYSx3QkFBd0IsQ0FBQTtRQUVsSCxNQUFNLGdCQUFnQixHQUFHOztxQkFFUixXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyx1Q0FBdUMsQ0FBQztjQUN6RSxjQUFjO2VBQ2IsQ0FBQTtRQUVYLDZEQUE2RDtRQUM3RCxNQUFNLGdCQUFnQixHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzNELGdCQUFnQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUU5QyxJQUFJLFdBQVcsQ0FBQyxJQUFJLEVBQUU7WUFDbEI7Ozs7Ozs7Ozs7Ozs7Y0FhRTtTQUNMO0lBQ0wsQ0FBQztDQUFBLENBQUMsQ0FBQztBQUVILG1DQUFtQztBQUNuQyxLQUFLLENBQUMsRUFBRSxDQUFDLGlCQUFpQixFQUFFLFVBQWdCLE1BQWtCLEVBQUUsT0FBZTs7UUFDM0UsNkNBQTZDO1FBQzdDLE1BQU0sV0FBVyxHQUF5QixTQUFTLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFFLEdBQUcsT0FBTyxJQUFJLENBQUMsRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN2SCxNQUFNLFNBQVMsR0FBWSxPQUFPLENBQUMsSUFBSSxDQUFDLG1DQUFtQyxDQUFDLENBQUMsQ0FBQyxDQUFzQixDQUFDLEtBQUssQ0FBQztRQUUzRyxJQUFJLFNBQVMsQ0FBQyxNQUFNLEtBQUssaUJBQWlCLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFO1lBQ3RFLEVBQUUsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLG1DQUFtQyxDQUFDLENBQUMsQ0FBQTtTQUN6RjthQUFNO1lBQ0gsTUFBTSxXQUFXLENBQUMsTUFBTSxDQUFDLEVBQUUscUNBQXFDLEVBQUUsU0FBUyxFQUFFLENBQUMsQ0FBQztTQUNsRjtRQUNEOzs7Ozs7VUFNRTtRQUNGLGtCQUFrQjtRQUNsQixpR0FBaUc7SUFDckcsQ0FBQztDQUFBLENBQUMsQ0FBQztBQUVIOzs7Ozs7OztHQVFHO0FBRUgsNEZBQTRGO0FBQzVGLEtBQUssQ0FBQyxFQUFFLENBQUMsYUFBYSxFQUFFLFVBQVUsUUFBaUIsRUFBRSxPQUFlLEVBQUUsV0FBNEI7SUFDOUYsTUFBTSxXQUFXLEdBQWEsRUFBRSxDQUFDO0lBQ2pDLFdBQVcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7SUFFN0IsSUFBSSxpQkFBaUIsR0FBRyxLQUFLLENBQUM7SUFDOUIsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsRUFBRSxvQkFBb0IsQ0FBQyxFQUFFO1FBQ2hFLGlCQUFpQixHQUFHLElBQUksQ0FBQztLQUM1QjtTQUFNO1FBQ0gsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQVUsRUFBRSxFQUFFO1lBQzdCLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMscUJBQXFCLEVBQUUsZ0JBQWdCLENBQUMsRUFBRTtnQkFDNUQsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFBO2FBQ3BDO1lBQ0QsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsRUFBRSxxQkFBcUIsQ0FBQyxJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUU7Z0JBQ25GLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSyxJQUFJLENBQUMsU0FBdUIsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFBO2FBQzdEO1FBQ0wsQ0FBQyxDQUFDLENBQUE7UUFDRixXQUFXLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQ3RCLElBQUksT0FBTyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRTtnQkFDdkIsaUJBQWlCLEdBQUcsSUFBSSxDQUFDO2FBQzVCO1FBQ0wsQ0FBQyxDQUFDLENBQUE7S0FDTDtJQUNELElBQUksaUJBQWlCLEVBQUU7UUFDbkIsdUVBQXVFO1FBQ3ZFLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMscUJBQXFCLEVBQUUsaUJBQWlCLENBQUMsRUFBRTtZQUM3RCxNQUFNLGVBQWUsR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDO1lBQ3pDLE1BQU0sYUFBYSxHQUFHLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxLQUFLLGVBQWUsQ0FBQyxDQUFDO1lBQzFFLE9BQU8sR0FBRyxhQUFhLENBQUMsSUFBSSxHQUFHLElBQUksR0FBRyxPQUFPLENBQUM7U0FDakQ7UUFDRCxLQUFLLENBQUMsT0FBTyxDQUFDLG9CQUFvQixFQUFFLE9BQU8sQ0FBQyxDQUFDO0tBQ2hEO1NBQU07UUFDSCxvSkFBb0o7UUFDcEosT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFBO0tBQ25DO0FBRUwsQ0FBQyxDQUFDLENBQUM7QUFFSCxLQUFLLENBQUMsRUFBRSxDQUFDLG9CQUFvQixFQUFFLFVBQVUsT0FBZTtJQUNwRCxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLEVBQUUsRUFBRTtRQUN6QyxPQUFPLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQzFCLENBQUMsQ0FBQyxDQUFDO0FBQ1AsQ0FBQyxDQUFDLENBQUM7QUFFSDs7Ozs7O0dBTUc7QUFDSCxTQUFlLGtCQUFrQixDQUFDLE9BQWU7O1FBRTdDLElBQUksV0FBVyxHQUFHLElBQUksQ0FBQztRQUV2QixNQUFNLGNBQWMsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsRUFBRSxnQkFBZ0IsQ0FBVyxDQUFDO1FBQzVGLElBQUksQ0FBQyxjQUFjLEVBQUU7WUFDakIsRUFBRSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQ2xCLFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLHdDQUF3QyxDQUFDO2tCQUNqRSxXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQywwQ0FBMEMsQ0FBQyxDQUFDLENBQUE7WUFDNUUsT0FBTztTQUNWO1FBRUQsTUFBTSxZQUFZLEdBQXdCLElBQUksR0FBRyxFQUFrQixDQUFDO1FBRXBFLE1BQU0sV0FBVyxHQUFhLEVBQUUsQ0FBQztRQUVqQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBVSxFQUFFLEVBQUU7WUFDN0IsSUFBSSxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUU7Z0JBQ3pDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQy9CO1lBQ0QsSUFBSSxJQUFJLENBQUMsU0FBUyxFQUFFO2dCQUNoQixZQUFZLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBRSxJQUFJLENBQUMsU0FBdUIsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2FBQ3JFO1FBQ0wsQ0FBQyxDQUFDLENBQUE7UUFFRixZQUFZLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBZ0IsRUFBRSxRQUFnQixFQUFFLElBQUksRUFBRSxFQUFFO1lBQzlELHFEQUFxRDtZQUNyRCxJQUFJLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxRQUFRLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFO2dCQUN4QyxXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2FBQzlCO1FBQ0wsQ0FBQyxDQUFDLENBQUE7UUFFRixxQ0FBcUM7UUFDckMsTUFBTSxpQkFBaUIsR0FBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUV2RSxtSUFBbUk7UUFDbkksSUFBSSxXQUFXLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUMxQixXQUFXLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBZ0IsRUFBRSxFQUFFO2dCQUNyQyxNQUFNLFdBQVcsR0FBcUIsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQVUsRUFBRSxFQUFFLEdBQUcsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksS0FBSyxRQUFRLENBQUEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDbEgsSUFBSSxXQUFXLEVBQUU7b0JBQ2IsTUFBTSxvQkFBb0IsR0FBVyxXQUFXLENBQUMsT0FBTyxDQUFDLHFCQUFxQixFQUFFLFdBQVcsQ0FBVyxDQUFDO29CQUN2RyxJQUFJLENBQUMsb0JBQW9CLEVBQUU7d0JBQ3ZCLEVBQUUsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUNsQixXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyx3Q0FBd0MsQ0FBQzs4QkFDakUsV0FBVyxDQUFDLElBQUk7OEJBQ2hCLFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLHFDQUFxQyxDQUFDLENBQUMsQ0FBQTt3QkFDdkUsV0FBVyxHQUFHLEtBQUssQ0FBQzt3QkFDcEIsT0FBTztxQkFDVjtvQkFDRCxPQUFPLEdBQUcsT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLFFBQVEsRUFBRSxFQUFFLEtBQUssb0JBQW9CLEdBQUcsQ0FBQyxDQUFDO29CQUN4RSxPQUFPLEdBQUcsT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLFlBQVksQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEVBQUUsRUFBRSxLQUFLLG9CQUFvQixHQUFHLENBQUMsQ0FBQztpQkFDN0Y7WUFDTCxDQUFDLENBQUMsQ0FBQTtZQUNGLG9HQUFvRztTQUN2RzthQUFNLElBQUksaUJBQWlCLEVBQUU7WUFDMUIsT0FBTyxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFLEVBQUUsQ0FBQyxJQUFJLEVBQUUsQ0FBQztTQUNwRDtRQUVELE1BQU0sV0FBVyxHQUFHO1lBQ2hCLFNBQVMsRUFBRSxPQUFPO1NBQ3JCLENBQUE7UUFFRCxJQUFJLFdBQW1CLENBQUM7UUFDeEIsSUFBSTtZQUNBLFdBQVcsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1NBQzdDO1FBQUMsT0FBTyxDQUFDLEVBQUU7WUFDUixFQUFFLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FDbEIsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsd0NBQXdDLENBQUM7a0JBQ2pFLFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLCtDQUErQyxDQUFDLENBQUMsQ0FBQTtZQUNqRixXQUFXLEdBQUcsS0FBSyxDQUFDO1NBQ3ZCO1FBRUQsSUFBSSxXQUFXLEVBQUU7WUFDYixNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQ1QsTUFBTSxFQUFFLE1BQU07Z0JBQ2QsR0FBRyxFQUFFLGNBQWM7Z0JBQ25CLFdBQVcsRUFBRSxrQkFBa0I7Z0JBQy9CLElBQUksRUFBRSxXQUFXO2FBQ3BCLENBQUMsQ0FBQztTQUNOO0lBQ0wsQ0FBQztDQUFBO0FBRUQsTUFBTSxlQUFlO0NBYXBCIiwiZmlsZSI6IkRpc2NvcmRJbnRlZ3JhdGlvbi5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8vIFRPRE8gZGlzY29yZC1pbnRlZ3JhdGlvbiMzNDogVGhyb3duIG9uIEhvb2tzLm9uKCksIGNhdXNlIGFuZCBmaXggdW5rbm93blxyXG4vKiBlc2xpbnQtZGlzYWJsZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tdW5zYWZlLWNhbGwgKi9cclxuXHJcbmltcG9ydCB7IEFjdG9yRGF0YSB9IGZyb20gXCJAbGVhZ3VlLW9mLWZvdW5kcnktZGV2ZWxvcGVycy9mb3VuZHJ5LXZ0dC10eXBlcy9zcmMvZm91bmRyeS9jb21tb24vZGF0YS9kYXRhLm1qcy9hY3RvckRhdGFcIjtcclxuXHJcbmxldCBnYW1lVXNlcnM6IFN0b3JlZERvY3VtZW50PFVzZXI+W11cclxubGV0IGZvdW5kcnlHYW1lOiBHYW1lO1xyXG5cclxuLy8gRGlzY29yZCB1c2VyLWlkcyBhcmUgYWx3YXlzIGV4YWN0bHkgMTggZGlnaXRzLlxyXG5jb25zdCBESVNDT1JEX0lEX0xFTkdUSCA9IDE4O1xyXG5cclxuZnVuY3Rpb24gZ2V0R2FtZSgpOiBHYW1lIHtcclxuICAgIHJldHVybiBnYW1lO1xyXG59XHJcblxyXG5Ib29rcy5vbmNlKFwicmVhZHlcIiwgZnVuY3Rpb24gKCkge1xyXG4gICAgZ2FtZVVzZXJzID0gKGdhbWUudXNlcnMpLmNvbnRlbnRzO1xyXG59KTtcclxuXHJcbkhvb2tzLm9uY2UoXCJpbml0XCIsIGZ1bmN0aW9uICgpIHtcclxuICAgIGZvdW5kcnlHYW1lID0gZ2V0R2FtZSgpO1xyXG4gICAgLy8gYWRkIHNldHRpbmdzIG9wdGlvbiBmb3IgVVJMIG9mIERpc2NvcmQgV2ViaG9va1xyXG4gICAgZm91bmRyeUdhbWUuc2V0dGluZ3MucmVnaXN0ZXIoXCJkaXNjb3JkLWludGVncmF0aW9uXCIsIFwiZGlzY29yZFdlYmhvb2tcIiwge1xyXG4gICAgICAgIG5hbWU6IGZvdW5kcnlHYW1lLmkxOG4ubG9jYWxpemUoXCJESVNDT1JESU5URUdSQVRJT04uU2V0dGluZ3NEaXNjb3JkV2ViaG9va1wiKSxcclxuICAgICAgICBoaW50OiBmb3VuZHJ5R2FtZS5pMThuLmxvY2FsaXplKFwiRElTQ09SRElOVEVHUkFUSU9OLlNldHRpbmdzRGlzY29yZFdlYmhvb2tIaW50XCIpLFxyXG4gICAgICAgIHNjb3BlOiBcIndvcmxkXCIsXHJcbiAgICAgICAgY29uZmlnOiB0cnVlLFxyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICBkZWZhdWx0OiBcIlwiLFxyXG4gICAgfSk7XHJcbiAgICAvLyBhZGQgc2V0dGluZ3Mgb3B0aW9uIGZvciBwaW5naW5nIGJ5IG9uIGNoYXJhY3RlciBuYW1lXHJcbiAgICBmb3VuZHJ5R2FtZS5zZXR0aW5ncy5yZWdpc3RlcihcImRpc2NvcmQtaW50ZWdyYXRpb25cIiwgXCJwaW5nQnlDaGFyYWN0ZXJOYW1lXCIsIHtcclxuICAgICAgICBuYW1lOiBmb3VuZHJ5R2FtZS5pMThuLmxvY2FsaXplKFwiRElTQ09SRElOVEVHUkFUSU9OLlNldHRpbmdzUGluZ0J5Q2hhcmFjdGVyTmFtZVwiKSxcclxuICAgICAgICBoaW50OiBmb3VuZHJ5R2FtZS5pMThuLmxvY2FsaXplKFwiRElTQ09SRElOVEVHUkFUSU9OLlNldHRpbmdzUGluZ0J5Q2hhcmFjdGVyTmFtZUhpbnRcIiksXHJcbiAgICAgICAgc2NvcGU6IFwid29ybGRcIixcclxuICAgICAgICBjb25maWc6IHRydWUsXHJcbiAgICAgICAgZGVmYXVsdDogdHJ1ZSxcclxuICAgICAgICB0eXBlOiBCb29sZWFuXHJcbiAgICB9KTtcclxuICAgIC8vIGFkZCBzZXR0aW5ncyBvcHRpb24gZm9yIHBpbmdpbmcgYnkgdXNlciBuYW1lXHJcbiAgICBmb3VuZHJ5R2FtZS5zZXR0aW5ncy5yZWdpc3RlcihcImRpc2NvcmQtaW50ZWdyYXRpb25cIiwgXCJwaW5nQnlVc2VyTmFtZVwiLCB7XHJcbiAgICAgICAgbmFtZTogZm91bmRyeUdhbWUuaTE4bi5sb2NhbGl6ZShcIkRJU0NPUkRJTlRFR1JBVElPTi5TZXR0aW5nc1BpbmdCeVVzZXJOYW1lXCIpLFxyXG4gICAgICAgIGhpbnQ6IGZvdW5kcnlHYW1lLmkxOG4ubG9jYWxpemUoXCJESVNDT1JESU5URUdSQVRJT04uU2V0dGluZ3NQaW5nQnlVc2VyTmFtZUhpbnRcIiksXHJcbiAgICAgICAgc2NvcGU6IFwid29ybGRcIixcclxuICAgICAgICBjb25maWc6IHRydWUsXHJcbiAgICAgICAgZGVmYXVsdDogdHJ1ZSxcclxuICAgICAgICB0eXBlOiBCb29sZWFuXHJcbiAgICB9KTtcclxuICAgIC8vIGFkZCBzZXR0aW5ncyBvcHRpb24gZm9yIGZvcndhcmRpbmcgQUxMIG1lc3NhZ2VzIHZzLiBmb3J3YXJkaW5nIG9ubHkgbWVzc2FnZXMgd2l0aCBwaW5ncy5cclxuICAgIGZvdW5kcnlHYW1lLnNldHRpbmdzLnJlZ2lzdGVyKFwiZGlzY29yZC1pbnRlZ3JhdGlvblwiLCBcImZvcndhcmRBbGxNZXNzYWdlc1wiLCB7XHJcbiAgICAgICAgbmFtZTogZm91bmRyeUdhbWUuaTE4bi5sb2NhbGl6ZShcIkRJU0NPUkRJTlRFR1JBVElPTi5TZXR0aW5nc0ZvcndhcmRBbGxNZXNzYWdlc1wiKSxcclxuICAgICAgICBoaW50OiBmb3VuZHJ5R2FtZS5pMThuLmxvY2FsaXplKFwiRElTQ09SRElOVEVHUkFUSU9OLlNldHRpbmdzRm9yd2FyZEFsbE1lc3NhZ2VzSGludFwiKSxcclxuICAgICAgICBzY29wZTogXCJ3b3JsZFwiLFxyXG4gICAgICAgIGNvbmZpZzogdHJ1ZSxcclxuICAgICAgICBkZWZhdWx0OiBmYWxzZSxcclxuICAgICAgICB0eXBlOiBCb29sZWFuXHJcbiAgICB9KTtcclxuICAgIC8vIGFkZCBzZXR0aW5ncyBvcHRpb24gZm9yIGFkZGluZyB0aGUgcGxheWVyJ3MgbmFtZSB0byB0aGUgZGlzY29yZCBtZXNzYWdlXHJcbiAgICBmb3VuZHJ5R2FtZS5zZXR0aW5ncy5yZWdpc3RlcihcImRpc2NvcmQtaW50ZWdyYXRpb25cIiwgXCJwcmVwZW5kVXNlck5hbWVcIiwge1xyXG4gICAgICAgIG5hbWU6IGZvdW5kcnlHYW1lLmkxOG4ubG9jYWxpemUoXCJESVNDT1JESU5URUdSQVRJT04uUHJlcGVuZFVzZXJOYW1lXCIpLFxyXG4gICAgICAgIGhpbnQ6IGZvdW5kcnlHYW1lLmkxOG4ubG9jYWxpemUoXCJESVNDT1JESU5URUdSQVRJT04uUHJlcGVuZFVzZXJOYW1lSGludFwiKSxcclxuICAgICAgICBzY29wZTogXCJ3b3JsZFwiLFxyXG4gICAgICAgIGNvbmZpZzogdHJ1ZSxcclxuICAgICAgICBkZWZhdWx0OiBmYWxzZSxcclxuICAgICAgICB0eXBlOiBCb29sZWFuXHJcbiAgICB9KTtcclxufSk7XHJcblxyXG4vLyBhZGQgaW4gdGhlIGV4dHJhIGZpZWxkIGZvciBEaXNjb3JkSURcclxuSG9va3Mub24oXCJyZW5kZXJVc2VyQ29uZmlnXCIsIGFzeW5jIGZ1bmN0aW9uIChjb25maWc6IFVzZXJDb25maWcsIGVsZW1lbnQ6IEpRdWVyeSkge1xyXG5cclxuICAgIC8vIGZpbmQgdGhlIHVzZXIgdGhhdCB5b3UncmUgb3BlbmluZyBjb25maWcgZm9yXHJcbiAgICBjb25zdCBmb3VuZHJ5VXNlcjogU3RvcmVkRG9jdW1lbnQ8VXNlcj4gPSBnYW1lVXNlcnMuZmlsdGVyKCh1c2VyOiBVc2VyKSA9PiB7IHJldHVybiB1c2VyLmlkID09PSAoY29uZmlnLm9iamVjdCkuZGF0YS5faWQgfSlbMF07XHJcblxyXG4gICAgLy8gZ2V0IHRoZWlyIERpc2NvcmQgSUQgaWYgaXQgZXhpc3RzXHJcbiAgICBsZXQgZGlzY29yZFVzZXJJZDogc3RyaW5nID0gYXdhaXQgZm91bmRyeVVzZXIuZ2V0RmxhZygnZGlzY29yZC1pbnRlZ3JhdGlvbicsICdkaXNjb3JkSUQnKSBhcyBzdHJpbmdcclxuICAgIGRpc2NvcmRVc2VySWQgPSBkaXNjb3JkVXNlcklkID8gZGlzY29yZFVzZXJJZCA6IFwiXCJcclxuXHJcbiAgICAvLyBjcmVhdGUgdGhlIGlucHV0IGZpZWxkIHRvIGNvbmZpZ3VyZSBpdC5cclxuICAgIGNvbnN0IGRpc2NvcmRJZElucHV0ID0gYDxpbnB1dCB0eXBlPVwidGV4dFwiIG5hbWU9XCJkaXNjb3JkLWlkLWNvbmZpZ1wiIHZhbHVlPVwiJHtkaXNjb3JkVXNlcklkfVwiIGRhdGEtZHR5cGU9XCJTdHJpbmdcIj5gXHJcblxyXG4gICAgY29uc3QgZGlzY29yZElEU2V0dGluZyA9IGBcclxuICAgICAgICA8ZGl2IGlkPVwiZGlzY29yZC1pZC1zZXR0aW5nXCIgY2xhc3M9XCJmb3JtLWdyb3VwIGRpc2NvcmRcIj5cclxuICAgICAgICAgICAgPGxhYmVsPiR7Zm91bmRyeUdhbWUuaTE4bi5sb2NhbGl6ZShcIkRJU0NPUkRJTlRFR1JBVElPTi5Vc2VyRGlzY29yZElkTGFiZWxcIil9PC9sYWJlbD5cclxuICAgICAgICAgICAgJHtkaXNjb3JkSWRJbnB1dH1cclxuICAgICAgICA8L2Rpdj5gXHJcblxyXG4gICAgLy8gUHV0IHRoZSBpbnB1dCBmaWVsZHMgYmVsb3cgdGhlIFwiUGxheWVyIENvbG9yIGdyb3VwXCIgZmllbGQuXHJcbiAgICBjb25zdCBwbGF5ZXJDb2xvckdyb3VwID0gZWxlbWVudC5maW5kKCcuZm9ybS1ncm91cCcpLmVxKDIpO1xyXG4gICAgcGxheWVyQ29sb3JHcm91cC5hZnRlcihbJChkaXNjb3JkSURTZXR0aW5nKV0pO1xyXG5cclxuICAgIGlmIChmb3VuZHJ5VXNlci5pc0dNKSB7XHJcbiAgICAgICAgLypcclxuICAgICAgICAvLyBnZXQgdGhlaXIgR00gTm90aWZpY2F0aW9uIHN0YXR1cyBpZiBpdCBleGlzdHMsIGRlZmF1bHRpbmcgdG8gdHJ1ZS5cclxuICAgICAgICBjb25zdCBzZW5kR01Ob3RpZmljYXRpb25zOiBib29sZWFuID0gYXdhaXQgZm91bmRyeVVzZXIuZ2V0RmxhZygnZGlzY29yZC1pbnRlZ3JhdGlvbicsICdzZW5kR01Ob3RpZmljYXRpb25zJykgYXMgYm9vbGVhbjtcclxuXHJcbiAgICAgICAgXHJcbiAgICAgICAgY29uc3QgaXNDaGVja2VkID0gc2VuZEdNTm90aWZpY2F0aW9ucyA/IFwiY2hlY2tlZFwiIDogXCJcIjtcclxuICAgICAgICBjb25zdCBnbU5vdGlmaWNhdGlvbkNoZWNrYm94ID0gYDxpbnB1dCB0eXBlPVwiY2hlY2tib3hcIiBuYW1lPVwiZ20tbm90aWZpY2F0aW9uLWNvbmZpZ1wiICR7aXNDaGVja2VkfT5gXHJcblxyXG4gICAgICAgIGNvbnN0IGdtTm90aWZpY2F0aW9uU2V0dGluZyA9IGBcclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbD4ke2dhbWUuaTE4bi5sb2NhbGl6ZShcIkRJU0NPUkRJTlRFR1JBVElPTi5HTU5vdGlmaWNhdGlvbnNMYWJlbFwiKSBhcyBzdHJpbmd9PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICR7Z21Ob3RpZmljYXRpb25DaGVja2JveH1cclxuICAgICAgICAgICAgPC9kaXY+YFxyXG4gICAgICAgICovXHJcbiAgICB9XHJcbn0pO1xyXG5cclxuLy8gY29tbWl0IGFueSBjaGFuZ2VzIHRvIHVzZXJDb25maWdcclxuSG9va3Mub24oXCJjbG9zZVVzZXJDb25maWdcIiwgYXN5bmMgZnVuY3Rpb24gKGNvbmZpZzogVXNlckNvbmZpZywgZWxlbWVudDogSlF1ZXJ5KSB7XHJcbiAgICAvLyBmaW5kIHRoZSB1c2VyIHRoYXQgdGhlIGNvbmZpZyB3YXMgb3BlbiBmb3JcclxuICAgIGNvbnN0IGZvdW5kcnlVc2VyOiBTdG9yZWREb2N1bWVudDxVc2VyPiA9IGdhbWVVc2Vycy5maWx0ZXIodXNlciA9PiB7IHJldHVybiB1c2VyLmlkID09PSAoY29uZmlnLm9iamVjdCkuZGF0YS5faWQgfSlbMF07XHJcbiAgICBjb25zdCBkaXNjb3JkSUQ6IHN0cmluZyA9IChlbGVtZW50LmZpbmQoXCJpbnB1dFtuYW1lID0gJ2Rpc2NvcmQtaWQtY29uZmlnJ11cIilbMF0gYXMgSFRNTElucHV0RWxlbWVudCkudmFsdWU7XHJcblxyXG4gICAgaWYgKGRpc2NvcmRJRC5sZW5ndGggIT09IERJU0NPUkRfSURfTEVOR1RIIHx8IGlzTmFOKHBhcnNlSW50KGRpc2NvcmRJRCkpKSB7XHJcbiAgICAgICAgdWkubm90aWZpY2F0aW9ucy5lcnJvcihmb3VuZHJ5R2FtZS5pMThuLmxvY2FsaXplKFwiRElTQ09SRElOVEVHUkFUSU9OLkludmFsaWRJZEVycm9yXCIpKVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgICBhd2FpdCBmb3VuZHJ5VXNlci51cGRhdGUoeyAnZmxhZ3MuZGlzY29yZC1pbnRlZ3JhdGlvbi5kaXNjb3JkSUQnOiBkaXNjb3JkSUQgfSk7XHJcbiAgICB9XHJcbiAgICAvKlxyXG4gICAgY29uc3QgZ21Ob3RpZmljYXRpb25FbGVtZW50ID0gZWxlbWVudC5maW5kKFwiaW5wdXRbbmFtZSA9ICdnbS1ub3RpZmljYXRpb24tY29uZmlnJ11cIik7XHJcbiAgICBsZXQgZ21Ob3RpZmljYXRpb25zOiBib29sZWFuXHJcbiAgICBpZiAoZ21Ob3RpZmljYXRpb25FbGVtZW50ICYmIGdtTm90aWZpY2F0aW9uRWxlbWVudFswXSkge1xyXG4gICAgICAgIGdtTm90aWZpY2F0aW9ucyA9IChlbGVtZW50LmZpbmQoXCJpbnB1dFtuYW1lID0gJ2dtLW5vdGlmaWNhdGlvbi1jb25maWcnXVwiKVswXSBhcyBIVE1MSW5wdXRFbGVtZW50KS5jaGVja2VkO1xyXG4gICAgfVxyXG4gICAgKi9cclxuICAgIC8vIHVwZGF0ZSB0aGUgZmxhZ1xyXG4gICAgLy9hd2FpdCBmb3VuZHJ5VXNlci51cGRhdGUoeyAnZmxhZ3MuZGlzY29yZC1pbnRlZ3JhdGlvbi5zZW5kR01Ob3RpZmljYXRpb25zJzogZ21Ob3RpZmljYXRpb25zIH0pO1xyXG59KTtcclxuXHJcbi8qKlxyXG4gKiBUbyBmb3J3YXJkIGEgbWVzc2FnZSB0byBkaXNjb3JkLCBkbyBvbmUgb2YgdHdvIHRoaW5nczpcclxuICogXHJcbiAqIC1pbmNsdWRlIFwiQDx1c2VybmFtZT5cIiBmb3IgYSB1c2VyIGluIHRoZSBnYW1lLCBpdCB3aWxsIHRoZW4gbG9vayB1cCB0aGUgY29ycmVzcG9uZGluZyBkaXNjb3JkSUQgXHJcbiAqIGFuZCBzZW5kIGEgbWVzc2FnZSBwaW5naW5nIHRoZW0uIElmIHlvdSBAIG11bHRpcGxlIHBlb3BsZSwgaXQgd2lsbCBwaW5nIGFsbCBvZiB0aGVtLiBXaWxsIG5vdFxyXG4gKiBzZW5kIGEgbWVzc2FnZSB1bmxlc3MgdGhlIHVzZXJuYW1lIG1hdGNoZXMgdXAgd2l0aCBhbiBhY3R1YWwgdXNlci5cclxuICogXHJcbiAqIC1pbmNsdWRlIFwiQERpc2NvcmRcIiwgd2hpY2ggd2lsbCB1bmNvbmRpdGlvbmFsbHkgZm9yd2FyZCB0aGUgbWVzc2FnZSAobWludXMgdGhlIEBEaXNjb3JkKSB0byB0aGUgRGlzY29yZCBXZWJob29rLlxyXG4gKi9cclxuXHJcbi8vIHdoZW5ldmVyIHNvbWVvbmUgc2VuZHMgYSBjaGF0IG1lc3NhZ2UsIGlmIGl0IGlzIG1hcmtlZCB1cCBwcm9wZXJseSBmb3J3YXJkIGl0IHRvIERpc2NvcmQuXHJcbkhvb2tzLm9uKFwiY2hhdE1lc3NhZ2VcIiwgZnVuY3Rpb24gKF9jaGF0TG9nOiBDaGF0TG9nLCBtZXNzYWdlOiBzdHJpbmcsIG1lc3NhZ2VEYXRhOiBDaGF0TWVzc2FnZURhdGEpIHtcclxuICAgIGNvbnN0IGRpc2NvcmRUYWdzOiBzdHJpbmdbXSA9IFtdO1xyXG4gICAgZGlzY29yZFRhZ3MucHVzaChcIkBEaXNjb3JkXCIpO1xyXG5cclxuICAgIGxldCBzaG91bGRTZW5kTWVzc2FnZSA9IGZhbHNlO1xyXG4gICAgaWYgKGdhbWUuc2V0dGluZ3MuZ2V0KCdkaXNjb3JkLWludGVncmF0aW9uJywgJ2ZvcndhcmRBbGxNZXNzYWdlcycpKSB7XHJcbiAgICAgICAgc2hvdWxkU2VuZE1lc3NhZ2UgPSB0cnVlO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgICBnYW1lVXNlcnMuZm9yRWFjaCgodXNlcjogVXNlcikgPT4ge1xyXG4gICAgICAgICAgICBpZiAoZ2FtZS5zZXR0aW5ncy5nZXQoJ2Rpc2NvcmQtaW50ZWdyYXRpb24nLCAncGluZ0J5VXNlck5hbWUnKSkge1xyXG4gICAgICAgICAgICAgICAgZGlzY29yZFRhZ3MucHVzaChgQCR7dXNlci5uYW1lfWApXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKGdhbWUuc2V0dGluZ3MuZ2V0KCdkaXNjb3JkLWludGVncmF0aW9uJywgJ3BpbmdCeUNoYXJhY3Rlck5hbWUnKSAmJiB1c2VyLmNoYXJhY3Rlcikge1xyXG4gICAgICAgICAgICAgICAgZGlzY29yZFRhZ3MucHVzaChgQCR7KHVzZXIuY2hhcmFjdGVyIGFzIEFjdG9yRGF0YSkubmFtZX1gKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSlcclxuICAgICAgICBkaXNjb3JkVGFncy5mb3JFYWNoKHRhZyA9PiB7XHJcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLmluY2x1ZGVzKHRhZykpIHtcclxuICAgICAgICAgICAgICAgIHNob3VsZFNlbmRNZXNzYWdlID0gdHJ1ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pXHJcbiAgICB9XHJcbiAgICBpZiAoc2hvdWxkU2VuZE1lc3NhZ2UpIHtcclxuICAgICAgICAvLyBJZiB3ZSBhcmUgYXBwZW5kaW5nIHRoZSBzZW5kZXIncyBuYW1lIHRvIHRoZSBtZXNzYWdlLCB3ZSBkbyBzbyBoZXJlLlxyXG4gICAgICAgIGlmIChnYW1lLnNldHRpbmdzLmdldCgnZGlzY29yZC1pbnRlZ3JhdGlvbicsICdwcmVwZW5kVXNlck5hbWUnKSkge1xyXG4gICAgICAgICAgICBjb25zdCBtZXNzYWdlU2VuZGVySWQgPSBtZXNzYWdlRGF0YS51c2VyO1xyXG4gICAgICAgICAgICBjb25zdCBtZXNzYWdlU2VuZGVyID0gZ2FtZVVzZXJzLmZpbmQodXNlciA9PiB1c2VyLmlkID09PSBtZXNzYWdlU2VuZGVySWQpO1xyXG4gICAgICAgICAgICBtZXNzYWdlID0gbWVzc2FnZVNlbmRlci5uYW1lICsgXCI6IFwiICsgbWVzc2FnZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgSG9va3MuY2FsbEFsbChcInNlbmREaXNjb3JkTWVzc2FnZVwiLCBtZXNzYWdlKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgLy8gVE9ETyBkaXNjb3JkLWludGVncmF0aW9uIzM1OiBUaGlzIGV4aXN0cyBhcyBhIHdheSB0byB0ZXN0IHdoZW4gYSBtZXNzYWdlIGlzIG5vdCBzZW50LiBGaWd1cmUgb3V0IGEgd2F5IHRvIGRvIGl0IHdpdGhvdXQgbW9kaWZ5aW5nIHRoZSBjb2RlIGxhdGVyLlxyXG4gICAgICAgIGNvbnNvbGUubG9nKFwiTWVzc2FnZSBub3Qgc2VudC5cIilcclxuICAgIH1cclxuXHJcbn0pO1xyXG5cclxuSG9va3Mub24oXCJzZW5kRGlzY29yZE1lc3NhZ2VcIiwgZnVuY3Rpb24gKG1lc3NhZ2U6IHN0cmluZykge1xyXG4gICAgc2VuZERpc2NvcmRNZXNzYWdlKG1lc3NhZ2UpLmNhdGNoKChyZWFzb24pID0+IHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKHJlYXNvbik7XHJcbiAgICB9KTtcclxufSk7XHJcblxyXG4vKipcclxuICogU2VuZHMgYSBtZXNzYWdlIHRocm91Z2ggdGhlIGRpc2NvcmQgd2ViaG9vayBhcyBjb25maWd1cmVkIGluIHNldHRpbmdzLlxyXG4gKiBcclxuICogTWVzc2FnZXMgdGhhdCBwaW5nIHVzZXJzIGluIERpc2NvcmQgbmVlZCB0byBoYXZlIFwiQDxnYW1lVXNlck5hbWU+XCIgYW5kIHRoZSB1c2VycyBtdXN0IGhhdmUgdGhlaXIgZGlzY29yZCBJRHMgY29uZmlndXJlZC5cclxuICogXHJcbiAqIEBwYXJhbSBtZXNzYWdlIFRoZSBtZXNzYWdlIHRvIGZvcndhcmQgdG8gRGlzY29yZFxyXG4gKi9cclxuYXN5bmMgZnVuY3Rpb24gc2VuZERpc2NvcmRNZXNzYWdlKG1lc3NhZ2U6IHN0cmluZykge1xyXG5cclxuICAgIGxldCBzZW5kTWVzc2FnZSA9IHRydWU7XHJcblxyXG4gICAgY29uc3QgZGlzY29yZFdlYmhvb2sgPSBnYW1lLnNldHRpbmdzLmdldCgnZGlzY29yZC1pbnRlZ3JhdGlvbicsICdkaXNjb3JkV2ViaG9vaycpIGFzIHN0cmluZztcclxuICAgIGlmICghZGlzY29yZFdlYmhvb2spIHtcclxuICAgICAgICB1aS5ub3RpZmljYXRpb25zLmVycm9yKFxyXG4gICAgICAgICAgICBmb3VuZHJ5R2FtZS5pMThuLmxvY2FsaXplKFwiRElTQ09SRElOVEVHUkFUSU9OLkNvdWxkTm90U2VuZE1lc3NhZ2VcIilcclxuICAgICAgICAgICAgKyBmb3VuZHJ5R2FtZS5pMThuLmxvY2FsaXplKFwiRElTQ09SRElOVEVHUkFUSU9OLk5vRGlzY29yZFdlYmhvb2tFcnJvclwiKSlcclxuICAgICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgdXNlcnNUb0NoYXJzOiBNYXA8c3RyaW5nLCBzdHJpbmc+ID0gbmV3IE1hcDxzdHJpbmcsIHN0cmluZz4oKTtcclxuXHJcbiAgICBjb25zdCB1c2Vyc1RvUGluZzogc3RyaW5nW10gPSBbXTtcclxuXHJcbiAgICBnYW1lVXNlcnMuZm9yRWFjaCgodXNlcjogVXNlcikgPT4ge1xyXG4gICAgICAgIGlmIChtZXNzYWdlLmluZGV4T2YoYEAke3VzZXIubmFtZX1gKSAhPT0gLTEpIHtcclxuICAgICAgICAgICAgdXNlcnNUb1BpbmcucHVzaCh1c2VyLm5hbWUpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodXNlci5jaGFyYWN0ZXIpIHtcclxuICAgICAgICAgICAgdXNlcnNUb0NoYXJzLnNldCh1c2VyLm5hbWUsICgodXNlci5jaGFyYWN0ZXIgYXMgQWN0b3JEYXRhKS5uYW1lKSk7XHJcbiAgICAgICAgfVxyXG4gICAgfSlcclxuXHJcbiAgICB1c2Vyc1RvQ2hhcnMuZm9yRWFjaCgoY2hhck5hbWU6IHN0cmluZywgdXNlck5hbWU6IHN0cmluZywgX21hcCkgPT4ge1xyXG4gICAgICAgIC8vIFBpbmcgaWYgYSB1c2VyIG9yIHRoZWlyIGNoYXJhY3RlcidzIG5hbWUgaXMgdGFnZ2VkXHJcbiAgICAgICAgaWYgKG1lc3NhZ2UuaW5kZXhPZihgQCR7Y2hhck5hbWV9YCkgIT09IC0xKSB7XHJcbiAgICAgICAgICAgIHVzZXJzVG9QaW5nLnB1c2godXNlck5hbWUpO1xyXG4gICAgICAgIH1cclxuICAgIH0pXHJcblxyXG4gICAgLy8gc2VhcmNoIGZvciBARGlzY29yZCBpbiB0aGUgbWVzc2FnZVxyXG4gICAgY29uc3Qgc2hvdWxkUGluZ0Rpc2NvcmQ6IGJvb2xlYW4gPSAobWVzc2FnZS5zZWFyY2goYEBEaXNjb3JkYCkgIT09IC0xKTtcclxuXHJcbiAgICAvLyBpZiBpdCBmb3VuZCBhbnkgQDx1c2VybmFtZT4gdmFsdWVzLCByZXBsYWNlIHRoZSB2YWx1ZXMgaW4gdGhlIG1lc3NhZ2Ugd2l0aCBhcHByb3ByaWF0ZSBkaXNjb3JkIHBpbmdzLCB0aGVuIHNlbmQgZGlzY29yZCBtZXNzYWdlLlxyXG4gICAgaWYgKHVzZXJzVG9QaW5nLmxlbmd0aCAhPT0gMCkge1xyXG4gICAgICAgIHVzZXJzVG9QaW5nLmZvckVhY2goKHVzZXJOYW1lOiBzdHJpbmcpID0+IHtcclxuICAgICAgICAgICAgY29uc3QgY3VycmVudFVzZXI6IFVzZXIgfCB1bmRlZmluZWQgPSBnYW1lVXNlcnMuZmlsdGVyKCh1c2VyOiBVc2VyKSA9PiB7IHJldHVybiB1c2VyLmRhdGEubmFtZSA9PT0gdXNlck5hbWUgfSlbMF07XHJcbiAgICAgICAgICAgIGlmIChjdXJyZW50VXNlcikge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgY3VycmVudFVzZXJEaXNjb3JkSUQ6IHN0cmluZyA9IGN1cnJlbnRVc2VyLmdldEZsYWcoJ2Rpc2NvcmQtaW50ZWdyYXRpb24nLCAnZGlzY29yZElEJykgYXMgc3RyaW5nO1xyXG4gICAgICAgICAgICAgICAgaWYgKCFjdXJyZW50VXNlckRpc2NvcmRJRCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHVpLm5vdGlmaWNhdGlvbnMuZXJyb3IoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvdW5kcnlHYW1lLmkxOG4ubG9jYWxpemUoXCJESVNDT1JESU5URUdSQVRJT04uQ291bGROb3RTZW5kTWVzc2FnZVwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICArIGN1cnJlbnRVc2VyLm5hbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgKyBmb3VuZHJ5R2FtZS5pMThuLmxvY2FsaXplKFwiRElTQ09SRElOVEVHUkFUSU9OLlVzZXJIYXNOb0lkRXJyb3JcIikpXHJcbiAgICAgICAgICAgICAgICAgICAgc2VuZE1lc3NhZ2UgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlID0gbWVzc2FnZS5yZXBsYWNlKGBAJHt1c2VyTmFtZX1gLCBgPEAke2N1cnJlbnRVc2VyRGlzY29yZElEfT5gKTtcclxuICAgICAgICAgICAgICAgIG1lc3NhZ2UgPSBtZXNzYWdlLnJlcGxhY2UoYEAke3VzZXJzVG9DaGFycy5nZXQodXNlck5hbWUpfWAsIGA8QCR7Y3VycmVudFVzZXJEaXNjb3JkSUR9PmApO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSlcclxuICAgICAgICAvLyBlbHNlIGlmIERpc2NvcmQgYXMgYSB3aG9sZSBpcyBiZWluZyBwaW5nZWQsIHJlbW92ZSB0aGUgXCJARGlzY29yZFwiIHBhcnQgYW5kIHRoZW4gc2VuZCB0aGUgbWVzc2FnZS5cclxuICAgIH0gZWxzZSBpZiAoc2hvdWxkUGluZ0Rpc2NvcmQpIHtcclxuICAgICAgICBtZXNzYWdlID0gbWVzc2FnZS5yZXBsYWNlKFwiQERpc2NvcmQgXCIsIFwiXCIpIHx8IFwiXCI7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgbWVzc2FnZUpTT04gPSB7XHJcbiAgICAgICAgXCJjb250ZW50XCI6IG1lc3NhZ2VcclxuICAgIH1cclxuXHJcbiAgICBsZXQganNvbk1lc3NhZ2U6IHN0cmluZztcclxuICAgIHRyeSB7XHJcbiAgICAgICAganNvbk1lc3NhZ2UgPSBKU09OLnN0cmluZ2lmeShtZXNzYWdlSlNPTik7XHJcbiAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgdWkubm90aWZpY2F0aW9ucy5lcnJvcihcclxuICAgICAgICAgICAgZm91bmRyeUdhbWUuaTE4bi5sb2NhbGl6ZShcIkRJU0NPUkRJTlRFR1JBVElPTi5Db3VsZE5vdFNlbmRNZXNzYWdlXCIpXHJcbiAgICAgICAgICAgICsgZm91bmRyeUdhbWUuaTE4bi5sb2NhbGl6ZShcIkRJU0NPUkRJTlRFR1JBVElPTi5Db3VsZE5vdFN0cmluZ2lmeUpzb25FcnJvclwiKSlcclxuICAgICAgICBzZW5kTWVzc2FnZSA9IGZhbHNlO1xyXG4gICAgfVxyXG5cclxuICAgIGlmIChzZW5kTWVzc2FnZSkge1xyXG4gICAgICAgIGF3YWl0ICQuYWpheCh7XHJcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxyXG4gICAgICAgICAgICB1cmw6IGRpc2NvcmRXZWJob29rLFxyXG4gICAgICAgICAgICBjb250ZW50VHlwZTogXCJhcHBsaWNhdGlvbi9qc29uXCIsXHJcbiAgICAgICAgICAgIGRhdGE6IGpzb25NZXNzYWdlXHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcbn1cclxuXHJcbmNsYXNzIENoYXRNZXNzYWdlRGF0YSB7XHJcbiAgICBibGluZDogYm9vbGVhbjtcclxuICAgIGNvbnRlbnQ6IHN0cmluZztcclxuICAgIGVtb3RlOiBib29sZWFuO1xyXG4gICAgZmxhZ3M6IG9iamVjdDtcclxuICAgIGZsYXZvcjogYW55OyAvLyBOb3Qgc3VyZSB3aGF0IHRoZXNlIFwiYW55XCIgZmllbGRzIGFyZSBzdXBwb3NlZCB0byBiZSBmaWxsZWQgd2l0aC4gU2hvdWxkbid0IGJlIGltcG9ydGFudCBmb3IgRGlzY29yZCBJbnRlZ3JhdGlvbiBhdCB0aGUgdmVyeSBsZWFzdC5cclxuICAgIHJvbGw6IGFueTsgLy8gTm90IHN1cmUgd2hhdCB0aGVzZSBcImFueVwiIGZpZWxkcyBhcmUgc3VwcG9zZWQgdG8gYmUgZmlsbGVkIHdpdGguIFNob3VsZG4ndCBiZSBpbXBvcnRhbnQgZm9yIERpc2NvcmQgSW50ZWdyYXRpb24gYXQgdGhlIHZlcnkgbGVhc3QuXHJcbiAgICBzb3VuZDogYW55OyAvLyBOb3Qgc3VyZSB3aGF0IHRoZXNlIFwiYW55XCIgZmllbGRzIGFyZSBzdXBwb3NlZCB0byBiZSBmaWxsZWQgd2l0aC4gU2hvdWxkbid0IGJlIGltcG9ydGFudCBmb3IgRGlzY29yZCBJbnRlZ3JhdGlvbiBhdCB0aGUgdmVyeSBsZWFzdC5cclxuICAgIHNwZWFrZXI6IG9iamVjdDtcclxuICAgIHRpbWVzdGFtcDogbnVtYmVyO1xyXG4gICAgdHlwZTogbnVtYmVyO1xyXG4gICAgdXNlcjogc3RyaW5nO1xyXG4gICAgd2hpc3BlcjogYW55OyAvLyBOb3Qgc3VyZSB3aGF0IHRoZXNlIFwiYW55XCIgZmllbGRzIGFyZSBzdXBwb3NlZCB0byBiZSBmaWxsZWQgd2l0aC4gU2hvdWxkbid0IGJlIGltcG9ydGFudCBmb3IgRGlzY29yZCBJbnRlZ3JhdGlvbiBhdCB0aGUgdmVyeSBsZWFzdC5cclxufSJdfQ==
