// TODO discord-integration#34: Thrown on Hooks.on(), cause and fix unknown
/* eslint-disable @typescript-eslint/no-unsafe-call */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
let gameUsers;
let foundryGame;
// Discord user-ids are always exactly 18 digits.
const DISCORD_ID_LENGTH = 18;
function getGame() {
    return game;
}
Hooks.once("ready", function () {
    gameUsers = (game.users).contents;
});
Hooks.once("init", function () {
    foundryGame = getGame();
    // add settings option for URL of Discord Webhook
    foundryGame.settings.register("discord-integration", "discordWebhook", {
        name: foundryGame.i18n.localize("DISCORDINTEGRATION.SettingsDiscordWebhook"),
        hint: foundryGame.i18n.localize("DISCORDINTEGRATION.SettingsDiscordWebhookHint"),
        scope: "world",
        config: true,
        type: String,
        default: "",
    });
    // add settings option for pinging by on character name
    foundryGame.settings.register("discord-integration", "pingByCharacterName", {
        name: foundryGame.i18n.localize("DISCORDINTEGRATION.SettingsPingByCharacterName"),
        hint: foundryGame.i18n.localize("DISCORDINTEGRATION.SettingsPingByCharacterNameHint"),
        scope: "world",
        config: true,
        default: true,
        type: Boolean
    });
    // add settings option for pinging by user name
    foundryGame.settings.register("discord-integration", "pingByUserName", {
        name: foundryGame.i18n.localize("DISCORDINTEGRATION.SettingsPingByUserName"),
        hint: foundryGame.i18n.localize("DISCORDINTEGRATION.SettingsPingByUserNameHint"),
        scope: "world",
        config: true,
        default: true,
        type: Boolean
    });
    // add settings option for forwarding ALL messages vs. forwarding only messages with pings.
    foundryGame.settings.register("discord-integration", "forwardAllMessages", {
        name: foundryGame.i18n.localize("DISCORDINTEGRATION.SettingsForwardAllMessages"),
        hint: foundryGame.i18n.localize("DISCORDINTEGRATION.SettingsForwardAllMessagesHint"),
        scope: "world",
        config: true,
        default: false,
        type: Boolean
    });
});
// add in the extra field for DiscordID
Hooks.on("renderUserConfig", function (config, element) {
    return __awaiter(this, void 0, void 0, function* () {
        // find the user that you're opening config for
        const foundryUser = gameUsers.filter((user) => { return user.id === (config.object).data._id; })[0];
        // get their Discord ID if it exists
        let discordUserId = yield foundryUser.getFlag('discord-integration', 'discordID');
        discordUserId = discordUserId ? discordUserId : "";
        // create the input field to configure it.
        const discordIdInput = `<input type="text" name="discord-id-config" value="${discordUserId}" data-dtype="String">`;
        const discordIDSetting = `
        <div id="discord-id-setting" class="form-group discord">
            <label>${foundryGame.i18n.localize("DISCORDINTEGRATION.UserDiscordIdLabel")}</label>
            ${discordIdInput}
        </div>`;
        // Put the input fields below the "Player Color group" field.
        const playerColorGroup = element.find('.form-group').eq(2);
        playerColorGroup.after([$(discordIDSetting)]);
        if (foundryUser.isGM) {
            /*
            // get their GM Notification status if it exists, defaulting to true.
            const sendGMNotifications: boolean = await foundryUser.getFlag('discord-integration', 'sendGMNotifications') as boolean;
    
            
            const isChecked = sendGMNotifications ? "checked" : "";
            const gmNotificationCheckbox = `<input type="checkbox" name="gm-notification-config" ${isChecked}>`
    
            const gmNotificationSetting = `
                <div>
                    <label>${game.i18n.localize("DISCORDINTEGRATION.GMNotificationsLabel") as string}</label>
                    ${gmNotificationCheckbox}
                </div>`
            */
        }
    });
});
// commit any changes to userConfig
Hooks.on("closeUserConfig", function (config, element) {
    return __awaiter(this, void 0, void 0, function* () {
        // find the user that the config was open for
        const foundryUser = gameUsers.filter(user => { return user.id === (config.object).data._id; })[0];
        const discordID = element.find("input[name = 'discord-id-config']")[0].value;
        if (discordID.length !== DISCORD_ID_LENGTH || isNaN(parseInt(discordID))) {
            ui.notifications.error(foundryGame.i18n.localize("DISCORDINTEGRATION.InvalidIdError"));
        }
        else {
            yield foundryUser.update({ 'flags.discord-integration.discordID': discordID });
        }
        /*
        const gmNotificationElement = element.find("input[name = 'gm-notification-config']");
        let gmNotifications: boolean
        if (gmNotificationElement && gmNotificationElement[0]) {
            gmNotifications = (element.find("input[name = 'gm-notification-config']")[0] as HTMLInputElement).checked;
        }
        */
        // update the flag
        //await foundryUser.update({ 'flags.discord-integration.sendGMNotifications': gmNotifications });
    });
});
/**
 * To forward a message to discord, do one of two things:
 *
 * -include "@<username>" for a user in the game, it will then look up the corresponding discordID
 * and send a message pinging them. If you @ multiple people, it will ping all of them. Will not
 * send a message unless the username matches up with an actual user.
 *
 * -include "@Discord", which will unconditionally forward the message (minus the @Discord) to the Discord Webhook.
 */
// whenever someone sends a chat message, if it is marked up properly forward it to Discord.
Hooks.on("chatMessage", function (_chatLog, message) {
    const discordTags = [];
    discordTags.push("@Discord");
    let shouldSendMessage = false;
    if (game.settings.get('discord-integration', 'forwardAllMessages')) {
        shouldSendMessage = true;
    }
    else {
        gameUsers.forEach((user) => {
            if (game.settings.get('discord-integration', 'pingByUserName')) {
                discordTags.push(`@${user.name}`);
            }
            if (game.settings.get('discord-integration', 'pingByCharacterName') && user.character) {
                discordTags.push(`@${user.character.name}`);
            }
        });
        discordTags.forEach(tag => {
            if (message.includes(tag)) {
                shouldSendMessage = true;
            }
        });
    }
    if (shouldSendMessage) {
        Hooks.callAll("sendDiscordMessage", message);
    }
    else {
        // TODO discord-integration#35: This exists as a way to test when a message is not sent. Figure out a way to do it without modifying the code later.
        console.log("Message not sent.");
    }
});
Hooks.on("sendDiscordMessage", function (message) {
    sendDiscordMessage(message).catch((reason) => {
        console.error(reason);
    });
});
/**
 * Sends a message through the discord webhook as configured in settings.
 *
 * Messages that ping users in Discord need to have "@<gameUserName>" and the users must have their discord IDs configured.
 *
 * @param message The message to forward to Discord
 */
function sendDiscordMessage(message) {
    return __awaiter(this, void 0, void 0, function* () {
        let sendMessage = true;
        const discordWebhook = game.settings.get('discord-integration', 'discordWebhook');
        if (!discordWebhook) {
            ui.notifications.error(foundryGame.i18n.localize("DISCORDINTEGRATION.CouldNotSendMessage")
                + foundryGame.i18n.localize("DISCORDINTEGRATION.NoDiscordWebhookError"));
            return;
        }
        const usersToChars = new Map();
        const usersToPing = [];
        gameUsers.forEach((user) => {
            if (message.indexOf(`@${user.name}`) !== -1) {
                usersToPing.push(user.name);
            }
            if (user.character) {
                usersToChars.set(user.name, (user.character.name));
            }
        });
        usersToChars.forEach((charName, userName, _map) => {
            // Ping if a user or their character's name is tagged
            if (message.indexOf(`@${charName}`) !== -1) {
                usersToPing.push(userName);
            }
        });
        // search for @Discord in the message
        const shouldPingDiscord = (message.search(`@Discord`) !== -1);
        // if it found any @<username> values, replace the values in the message with appropriate discord pings, then send discord message.
        if (usersToPing.length !== 0) {
            usersToPing.forEach((userName) => {
                const currentUser = gameUsers.filter((user) => { return user.data.name === userName; })[0];
                if (currentUser) {
                    const currentUserDiscordID = currentUser.getFlag('discord-integration', 'discordID');
                    if (!currentUserDiscordID) {
                        ui.notifications.error(foundryGame.i18n.localize("DISCORDINTEGRATION.CouldNotSendMessage")
                            + currentUser.name
                            + foundryGame.i18n.localize("DISCORDINTEGRATION.UserHasNoIdError"));
                        sendMessage = false;
                        return;
                    }
                    message = message.replace(`@${userName}`, `<@${currentUserDiscordID}>`);
                    message = message.replace(`@${usersToChars.get(userName)}`, `<@${currentUserDiscordID}>`);
                }
            });
            // else if Discord as a whole is being pinged, remove the "@Discord" part and then send the message.
        }
        else if (shouldPingDiscord) {
            message = message.split("@Discord").pop() || "";
        }
        const messageJSON = {
            "content": message
        };
        let jsonMessage;
        try {
            jsonMessage = JSON.stringify(messageJSON);
        }
        catch (e) {
            ui.notifications.error(foundryGame.i18n.localize("DISCORDINTEGRATION.CouldNotSendMessage")
                + foundryGame.i18n.localize("DISCORDINTEGRATION.CouldNotStringifyJsonError"));
            sendMessage = false;
        }
        if (sendMessage) {
            yield $.ajax({
                method: 'POST',
                url: discordWebhook,
                contentType: "application/json",
                data: jsonMessage
            });
        }
    });
}
export {};

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9EaXNjb3JkSW50ZWdyYXRpb24udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsMkVBQTJFO0FBQzNFLHNEQUFzRDs7Ozs7Ozs7OztBQUl0RCxJQUFJLFNBQWlDLENBQUE7QUFDckMsSUFBSSxXQUFpQixDQUFDO0FBRXRCLGlEQUFpRDtBQUNqRCxNQUFNLGlCQUFpQixHQUFHLEVBQUUsQ0FBQztBQUU3QixTQUFTLE9BQU87SUFDWixPQUFPLElBQUksQ0FBQztBQUNoQixDQUFDO0FBRUQsS0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUU7SUFDaEIsU0FBUyxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUN0QyxDQUFDLENBQUMsQ0FBQztBQUVILEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO0lBQ2YsV0FBVyxHQUFHLE9BQU8sRUFBRSxDQUFDO0lBQ3hCLGlEQUFpRDtJQUNqRCxXQUFXLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxxQkFBcUIsRUFBRSxnQkFBZ0IsRUFBRTtRQUNuRSxJQUFJLEVBQUUsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsMkNBQTJDLENBQUM7UUFDNUUsSUFBSSxFQUFFLFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLCtDQUErQyxDQUFDO1FBQ2hGLEtBQUssRUFBRSxPQUFPO1FBQ2QsTUFBTSxFQUFFLElBQUk7UUFDWixJQUFJLEVBQUUsTUFBTTtRQUNaLE9BQU8sRUFBRSxFQUFFO0tBQ2QsQ0FBQyxDQUFDO0lBQ0gsdURBQXVEO0lBQ3ZELFdBQVcsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLHFCQUFxQixFQUFFLHFCQUFxQixFQUFFO1FBQ3hFLElBQUksRUFBRSxXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxnREFBZ0QsQ0FBQztRQUNqRixJQUFJLEVBQUUsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsb0RBQW9ELENBQUM7UUFDckYsS0FBSyxFQUFFLE9BQU87UUFDZCxNQUFNLEVBQUUsSUFBSTtRQUNaLE9BQU8sRUFBRSxJQUFJO1FBQ2IsSUFBSSxFQUFFLE9BQU87S0FDaEIsQ0FBQyxDQUFDO0lBQ0gsK0NBQStDO0lBQy9DLFdBQVcsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLHFCQUFxQixFQUFFLGdCQUFnQixFQUFFO1FBQ25FLElBQUksRUFBRSxXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQywyQ0FBMkMsQ0FBQztRQUM1RSxJQUFJLEVBQUUsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsK0NBQStDLENBQUM7UUFDaEYsS0FBSyxFQUFFLE9BQU87UUFDZCxNQUFNLEVBQUUsSUFBSTtRQUNaLE9BQU8sRUFBRSxJQUFJO1FBQ2IsSUFBSSxFQUFFLE9BQU87S0FDaEIsQ0FBQyxDQUFDO0lBQ0gsMkZBQTJGO0lBQzNGLFdBQVcsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLHFCQUFxQixFQUFFLG9CQUFvQixFQUFFO1FBQ3ZFLElBQUksRUFBRSxXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQywrQ0FBK0MsQ0FBQztRQUNoRixJQUFJLEVBQUUsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsbURBQW1ELENBQUM7UUFDcEYsS0FBSyxFQUFFLE9BQU87UUFDZCxNQUFNLEVBQUUsSUFBSTtRQUNaLE9BQU8sRUFBRSxLQUFLO1FBQ2QsSUFBSSxFQUFFLE9BQU87S0FDaEIsQ0FBQyxDQUFDO0FBQ1AsQ0FBQyxDQUFDLENBQUM7QUFFSCx1Q0FBdUM7QUFDdkMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxrQkFBa0IsRUFBRSxVQUFnQixNQUFrQixFQUFFLE9BQWU7O1FBRTVFLCtDQUErQztRQUMvQyxNQUFNLFdBQVcsR0FBeUIsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQVUsRUFBRSxFQUFFLEdBQUcsT0FBTyxJQUFJLENBQUMsRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUUvSCxvQ0FBb0M7UUFDcEMsSUFBSSxhQUFhLEdBQVcsTUFBTSxXQUFXLENBQUMsT0FBTyxDQUFDLHFCQUFxQixFQUFFLFdBQVcsQ0FBVyxDQUFBO1FBQ25HLGFBQWEsR0FBRyxhQUFhLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFBO1FBRWxELDBDQUEwQztRQUMxQyxNQUFNLGNBQWMsR0FBRyxzREFBc0QsYUFBYSx3QkFBd0IsQ0FBQTtRQUVsSCxNQUFNLGdCQUFnQixHQUFHOztxQkFFUixXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyx1Q0FBdUMsQ0FBQztjQUN6RSxjQUFjO2VBQ2IsQ0FBQTtRQUVYLDZEQUE2RDtRQUM3RCxNQUFNLGdCQUFnQixHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzNELGdCQUFnQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUU5QyxJQUFJLFdBQVcsQ0FBQyxJQUFJLEVBQUU7WUFDbEI7Ozs7Ozs7Ozs7Ozs7Y0FhRTtTQUNMO0lBQ0wsQ0FBQztDQUFBLENBQUMsQ0FBQztBQUVILG1DQUFtQztBQUNuQyxLQUFLLENBQUMsRUFBRSxDQUFDLGlCQUFpQixFQUFFLFVBQWdCLE1BQWtCLEVBQUUsT0FBZTs7UUFDM0UsNkNBQTZDO1FBQzdDLE1BQU0sV0FBVyxHQUF5QixTQUFTLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFFLEdBQUcsT0FBTyxJQUFJLENBQUMsRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN2SCxNQUFNLFNBQVMsR0FBWSxPQUFPLENBQUMsSUFBSSxDQUFDLG1DQUFtQyxDQUFDLENBQUMsQ0FBQyxDQUFzQixDQUFDLEtBQUssQ0FBQztRQUUzRyxJQUFJLFNBQVMsQ0FBQyxNQUFNLEtBQUssaUJBQWlCLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFO1lBQ3RFLEVBQUUsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLG1DQUFtQyxDQUFDLENBQUMsQ0FBQTtTQUN6RjthQUFNO1lBQ0gsTUFBTSxXQUFXLENBQUMsTUFBTSxDQUFDLEVBQUUscUNBQXFDLEVBQUUsU0FBUyxFQUFFLENBQUMsQ0FBQztTQUNsRjtRQUNEOzs7Ozs7VUFNRTtRQUNGLGtCQUFrQjtRQUNsQixpR0FBaUc7SUFDckcsQ0FBQztDQUFBLENBQUMsQ0FBQztBQUVIOzs7Ozs7OztHQVFHO0FBRUgsNEZBQTRGO0FBQzVGLEtBQUssQ0FBQyxFQUFFLENBQUMsYUFBYSxFQUFFLFVBQVUsUUFBaUIsRUFBRSxPQUFlO0lBQ2hFLE1BQU0sV0FBVyxHQUFhLEVBQUUsQ0FBQztJQUNqQyxXQUFXLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBRTdCLElBQUksaUJBQWlCLEdBQUcsS0FBSyxDQUFDO0lBQzlCLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMscUJBQXFCLEVBQUUsb0JBQW9CLENBQUMsRUFBRTtRQUNoRSxpQkFBaUIsR0FBRyxJQUFJLENBQUM7S0FDNUI7U0FBTTtRQUNILFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFVLEVBQUUsRUFBRTtZQUM3QixJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLHFCQUFxQixFQUFFLGdCQUFnQixDQUFDLEVBQUU7Z0JBQzVELFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQTthQUNwQztZQUNELElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMscUJBQXFCLEVBQUUscUJBQXFCLENBQUMsSUFBSSxJQUFJLENBQUMsU0FBUyxFQUFFO2dCQUNuRixXQUFXLENBQUMsSUFBSSxDQUFDLElBQUssSUFBSSxDQUFDLFNBQXVCLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQTthQUM3RDtRQUNMLENBQUMsQ0FBQyxDQUFBO1FBQ0YsV0FBVyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUN0QixJQUFJLE9BQU8sQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQ3ZCLGlCQUFpQixHQUFHLElBQUksQ0FBQzthQUM1QjtRQUNMLENBQUMsQ0FBQyxDQUFBO0tBQ0w7SUFDRCxJQUFJLGlCQUFpQixFQUFFO1FBQ25CLEtBQUssQ0FBQyxPQUFPLENBQUMsb0JBQW9CLEVBQUUsT0FBTyxDQUFDLENBQUM7S0FDaEQ7U0FBTTtRQUNILG9KQUFvSjtRQUNwSixPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixDQUFDLENBQUE7S0FDbkM7QUFFTCxDQUFDLENBQUMsQ0FBQztBQUVILEtBQUssQ0FBQyxFQUFFLENBQUMsb0JBQW9CLEVBQUUsVUFBVSxPQUFlO0lBQ3BELGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sRUFBRSxFQUFFO1FBQ3pDLE9BQU8sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDMUIsQ0FBQyxDQUFDLENBQUM7QUFDUCxDQUFDLENBQUMsQ0FBQztBQUVIOzs7Ozs7R0FNRztBQUNILFNBQWUsa0JBQWtCLENBQUMsT0FBZTs7UUFFN0MsSUFBSSxXQUFXLEdBQUcsSUFBSSxDQUFDO1FBRXZCLE1BQU0sY0FBYyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLHFCQUFxQixFQUFFLGdCQUFnQixDQUFXLENBQUM7UUFDNUYsSUFBSSxDQUFDLGNBQWMsRUFBRTtZQUNqQixFQUFFLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FDbEIsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsd0NBQXdDLENBQUM7a0JBQ2pFLFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLDBDQUEwQyxDQUFDLENBQUMsQ0FBQTtZQUM1RSxPQUFPO1NBQ1Y7UUFFRCxNQUFNLFlBQVksR0FBd0IsSUFBSSxHQUFHLEVBQWtCLENBQUM7UUFFcEUsTUFBTSxXQUFXLEdBQWEsRUFBRSxDQUFDO1FBRWpDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFVLEVBQUUsRUFBRTtZQUM3QixJQUFJLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRTtnQkFDekMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDL0I7WUFDRCxJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUU7Z0JBQ2hCLFlBQVksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFFLElBQUksQ0FBQyxTQUF1QixDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7YUFDckU7UUFDTCxDQUFDLENBQUMsQ0FBQTtRQUVGLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFnQixFQUFFLFFBQWdCLEVBQUUsSUFBSSxFQUFFLEVBQUU7WUFDOUQscURBQXFEO1lBQ3JELElBQUksT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLFFBQVEsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUU7Z0JBQ3hDLFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7YUFDOUI7UUFDTCxDQUFDLENBQUMsQ0FBQTtRQUVGLHFDQUFxQztRQUNyQyxNQUFNLGlCQUFpQixHQUFZLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRXZFLG1JQUFtSTtRQUNuSSxJQUFJLFdBQVcsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO1lBQzFCLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFnQixFQUFFLEVBQUU7Z0JBQ3JDLE1BQU0sV0FBVyxHQUFxQixTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBVSxFQUFFLEVBQUUsR0FBRyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxLQUFLLFFBQVEsQ0FBQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNsSCxJQUFJLFdBQVcsRUFBRTtvQkFDYixNQUFNLG9CQUFvQixHQUFXLFdBQVcsQ0FBQyxPQUFPLENBQUMscUJBQXFCLEVBQUUsV0FBVyxDQUFXLENBQUM7b0JBQ3ZHLElBQUksQ0FBQyxvQkFBb0IsRUFBRTt3QkFDdkIsRUFBRSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQ2xCLFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLHdDQUF3QyxDQUFDOzhCQUNqRSxXQUFXLENBQUMsSUFBSTs4QkFDaEIsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMscUNBQXFDLENBQUMsQ0FBQyxDQUFBO3dCQUN2RSxXQUFXLEdBQUcsS0FBSyxDQUFDO3dCQUNwQixPQUFPO3FCQUNWO29CQUNELE9BQU8sR0FBRyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksUUFBUSxFQUFFLEVBQUUsS0FBSyxvQkFBb0IsR0FBRyxDQUFDLENBQUM7b0JBQ3hFLE9BQU8sR0FBRyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksWUFBWSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLEtBQUssb0JBQW9CLEdBQUcsQ0FBQyxDQUFDO2lCQUM3RjtZQUNMLENBQUMsQ0FBQyxDQUFBO1lBQ0Ysb0dBQW9HO1NBQ3ZHO2FBQU0sSUFBSSxpQkFBaUIsRUFBRTtZQUMxQixPQUFPLEdBQUcsT0FBTyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxFQUFFLENBQUM7U0FDbkQ7UUFFRCxNQUFNLFdBQVcsR0FBRztZQUNoQixTQUFTLEVBQUUsT0FBTztTQUNyQixDQUFBO1FBRUQsSUFBSSxXQUFtQixDQUFDO1FBQ3hCLElBQUk7WUFDQSxXQUFXLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQztTQUM3QztRQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQ1IsRUFBRSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQ2xCLFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLHdDQUF3QyxDQUFDO2tCQUNqRSxXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQywrQ0FBK0MsQ0FBQyxDQUFDLENBQUE7WUFDakYsV0FBVyxHQUFHLEtBQUssQ0FBQztTQUN2QjtRQUVELElBQUksV0FBVyxFQUFFO1lBQ2IsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUNULE1BQU0sRUFBRSxNQUFNO2dCQUNkLEdBQUcsRUFBRSxjQUFjO2dCQUNuQixXQUFXLEVBQUUsa0JBQWtCO2dCQUMvQixJQUFJLEVBQUUsV0FBVzthQUNwQixDQUFDLENBQUM7U0FDTjtJQUNMLENBQUM7Q0FBQSIsImZpbGUiOiJEaXNjb3JkSW50ZWdyYXRpb24uanMiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUT0RPIGRpc2NvcmQtaW50ZWdyYXRpb24jMzQ6IFRocm93biBvbiBIb29rcy5vbigpLCBjYXVzZSBhbmQgZml4IHVua25vd25cclxuLyogZXNsaW50LWRpc2FibGUgQHR5cGVzY3JpcHQtZXNsaW50L25vLXVuc2FmZS1jYWxsICovXHJcblxyXG5pbXBvcnQgeyBBY3RvckRhdGEgfSBmcm9tIFwiQGxlYWd1ZS1vZi1mb3VuZHJ5LWRldmVsb3BlcnMvZm91bmRyeS12dHQtdHlwZXMvc3JjL2ZvdW5kcnkvY29tbW9uL2RhdGEvZGF0YS5tanMvYWN0b3JEYXRhXCI7XHJcblxyXG5sZXQgZ2FtZVVzZXJzOiBTdG9yZWREb2N1bWVudDxVc2VyPltdXHJcbmxldCBmb3VuZHJ5R2FtZTogR2FtZTtcclxuXHJcbi8vIERpc2NvcmQgdXNlci1pZHMgYXJlIGFsd2F5cyBleGFjdGx5IDE4IGRpZ2l0cy5cclxuY29uc3QgRElTQ09SRF9JRF9MRU5HVEggPSAxODtcclxuXHJcbmZ1bmN0aW9uIGdldEdhbWUoKTogR2FtZSB7XHJcbiAgICByZXR1cm4gZ2FtZTtcclxufVxyXG5cclxuSG9va3Mub25jZShcInJlYWR5XCIsIGZ1bmN0aW9uICgpIHtcclxuICAgIGdhbWVVc2VycyA9IChnYW1lLnVzZXJzKS5jb250ZW50cztcclxufSk7XHJcblxyXG5Ib29rcy5vbmNlKFwiaW5pdFwiLCBmdW5jdGlvbiAoKSB7XHJcbiAgICBmb3VuZHJ5R2FtZSA9IGdldEdhbWUoKTtcclxuICAgIC8vIGFkZCBzZXR0aW5ncyBvcHRpb24gZm9yIFVSTCBvZiBEaXNjb3JkIFdlYmhvb2tcclxuICAgIGZvdW5kcnlHYW1lLnNldHRpbmdzLnJlZ2lzdGVyKFwiZGlzY29yZC1pbnRlZ3JhdGlvblwiLCBcImRpc2NvcmRXZWJob29rXCIsIHtcclxuICAgICAgICBuYW1lOiBmb3VuZHJ5R2FtZS5pMThuLmxvY2FsaXplKFwiRElTQ09SRElOVEVHUkFUSU9OLlNldHRpbmdzRGlzY29yZFdlYmhvb2tcIiksXHJcbiAgICAgICAgaGludDogZm91bmRyeUdhbWUuaTE4bi5sb2NhbGl6ZShcIkRJU0NPUkRJTlRFR1JBVElPTi5TZXR0aW5nc0Rpc2NvcmRXZWJob29rSGludFwiKSxcclxuICAgICAgICBzY29wZTogXCJ3b3JsZFwiLFxyXG4gICAgICAgIGNvbmZpZzogdHJ1ZSxcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgZGVmYXVsdDogXCJcIixcclxuICAgIH0pO1xyXG4gICAgLy8gYWRkIHNldHRpbmdzIG9wdGlvbiBmb3IgcGluZ2luZyBieSBvbiBjaGFyYWN0ZXIgbmFtZVxyXG4gICAgZm91bmRyeUdhbWUuc2V0dGluZ3MucmVnaXN0ZXIoXCJkaXNjb3JkLWludGVncmF0aW9uXCIsIFwicGluZ0J5Q2hhcmFjdGVyTmFtZVwiLCB7XHJcbiAgICAgICAgbmFtZTogZm91bmRyeUdhbWUuaTE4bi5sb2NhbGl6ZShcIkRJU0NPUkRJTlRFR1JBVElPTi5TZXR0aW5nc1BpbmdCeUNoYXJhY3Rlck5hbWVcIiksXHJcbiAgICAgICAgaGludDogZm91bmRyeUdhbWUuaTE4bi5sb2NhbGl6ZShcIkRJU0NPUkRJTlRFR1JBVElPTi5TZXR0aW5nc1BpbmdCeUNoYXJhY3Rlck5hbWVIaW50XCIpLFxyXG4gICAgICAgIHNjb3BlOiBcIndvcmxkXCIsXHJcbiAgICAgICAgY29uZmlnOiB0cnVlLFxyXG4gICAgICAgIGRlZmF1bHQ6IHRydWUsXHJcbiAgICAgICAgdHlwZTogQm9vbGVhblxyXG4gICAgfSk7XHJcbiAgICAvLyBhZGQgc2V0dGluZ3Mgb3B0aW9uIGZvciBwaW5naW5nIGJ5IHVzZXIgbmFtZVxyXG4gICAgZm91bmRyeUdhbWUuc2V0dGluZ3MucmVnaXN0ZXIoXCJkaXNjb3JkLWludGVncmF0aW9uXCIsIFwicGluZ0J5VXNlck5hbWVcIiwge1xyXG4gICAgICAgIG5hbWU6IGZvdW5kcnlHYW1lLmkxOG4ubG9jYWxpemUoXCJESVNDT1JESU5URUdSQVRJT04uU2V0dGluZ3NQaW5nQnlVc2VyTmFtZVwiKSxcclxuICAgICAgICBoaW50OiBmb3VuZHJ5R2FtZS5pMThuLmxvY2FsaXplKFwiRElTQ09SRElOVEVHUkFUSU9OLlNldHRpbmdzUGluZ0J5VXNlck5hbWVIaW50XCIpLFxyXG4gICAgICAgIHNjb3BlOiBcIndvcmxkXCIsXHJcbiAgICAgICAgY29uZmlnOiB0cnVlLFxyXG4gICAgICAgIGRlZmF1bHQ6IHRydWUsXHJcbiAgICAgICAgdHlwZTogQm9vbGVhblxyXG4gICAgfSk7XHJcbiAgICAvLyBhZGQgc2V0dGluZ3Mgb3B0aW9uIGZvciBmb3J3YXJkaW5nIEFMTCBtZXNzYWdlcyB2cy4gZm9yd2FyZGluZyBvbmx5IG1lc3NhZ2VzIHdpdGggcGluZ3MuXHJcbiAgICBmb3VuZHJ5R2FtZS5zZXR0aW5ncy5yZWdpc3RlcihcImRpc2NvcmQtaW50ZWdyYXRpb25cIiwgXCJmb3J3YXJkQWxsTWVzc2FnZXNcIiwge1xyXG4gICAgICAgIG5hbWU6IGZvdW5kcnlHYW1lLmkxOG4ubG9jYWxpemUoXCJESVNDT1JESU5URUdSQVRJT04uU2V0dGluZ3NGb3J3YXJkQWxsTWVzc2FnZXNcIiksXHJcbiAgICAgICAgaGludDogZm91bmRyeUdhbWUuaTE4bi5sb2NhbGl6ZShcIkRJU0NPUkRJTlRFR1JBVElPTi5TZXR0aW5nc0ZvcndhcmRBbGxNZXNzYWdlc0hpbnRcIiksXHJcbiAgICAgICAgc2NvcGU6IFwid29ybGRcIixcclxuICAgICAgICBjb25maWc6IHRydWUsXHJcbiAgICAgICAgZGVmYXVsdDogZmFsc2UsXHJcbiAgICAgICAgdHlwZTogQm9vbGVhblxyXG4gICAgfSk7XHJcbn0pO1xyXG5cclxuLy8gYWRkIGluIHRoZSBleHRyYSBmaWVsZCBmb3IgRGlzY29yZElEXHJcbkhvb2tzLm9uKFwicmVuZGVyVXNlckNvbmZpZ1wiLCBhc3luYyBmdW5jdGlvbiAoY29uZmlnOiBVc2VyQ29uZmlnLCBlbGVtZW50OiBKUXVlcnkpIHtcclxuXHJcbiAgICAvLyBmaW5kIHRoZSB1c2VyIHRoYXQgeW91J3JlIG9wZW5pbmcgY29uZmlnIGZvclxyXG4gICAgY29uc3QgZm91bmRyeVVzZXI6IFN0b3JlZERvY3VtZW50PFVzZXI+ID0gZ2FtZVVzZXJzLmZpbHRlcigodXNlcjogVXNlcikgPT4geyByZXR1cm4gdXNlci5pZCA9PT0gKGNvbmZpZy5vYmplY3QpLmRhdGEuX2lkIH0pWzBdO1xyXG5cclxuICAgIC8vIGdldCB0aGVpciBEaXNjb3JkIElEIGlmIGl0IGV4aXN0c1xyXG4gICAgbGV0IGRpc2NvcmRVc2VySWQ6IHN0cmluZyA9IGF3YWl0IGZvdW5kcnlVc2VyLmdldEZsYWcoJ2Rpc2NvcmQtaW50ZWdyYXRpb24nLCAnZGlzY29yZElEJykgYXMgc3RyaW5nXHJcbiAgICBkaXNjb3JkVXNlcklkID0gZGlzY29yZFVzZXJJZCA/IGRpc2NvcmRVc2VySWQgOiBcIlwiXHJcblxyXG4gICAgLy8gY3JlYXRlIHRoZSBpbnB1dCBmaWVsZCB0byBjb25maWd1cmUgaXQuXHJcbiAgICBjb25zdCBkaXNjb3JkSWRJbnB1dCA9IGA8aW5wdXQgdHlwZT1cInRleHRcIiBuYW1lPVwiZGlzY29yZC1pZC1jb25maWdcIiB2YWx1ZT1cIiR7ZGlzY29yZFVzZXJJZH1cIiBkYXRhLWR0eXBlPVwiU3RyaW5nXCI+YFxyXG5cclxuICAgIGNvbnN0IGRpc2NvcmRJRFNldHRpbmcgPSBgXHJcbiAgICAgICAgPGRpdiBpZD1cImRpc2NvcmQtaWQtc2V0dGluZ1wiIGNsYXNzPVwiZm9ybS1ncm91cCBkaXNjb3JkXCI+XHJcbiAgICAgICAgICAgIDxsYWJlbD4ke2ZvdW5kcnlHYW1lLmkxOG4ubG9jYWxpemUoXCJESVNDT1JESU5URUdSQVRJT04uVXNlckRpc2NvcmRJZExhYmVsXCIpfTwvbGFiZWw+XHJcbiAgICAgICAgICAgICR7ZGlzY29yZElkSW5wdXR9XHJcbiAgICAgICAgPC9kaXY+YFxyXG5cclxuICAgIC8vIFB1dCB0aGUgaW5wdXQgZmllbGRzIGJlbG93IHRoZSBcIlBsYXllciBDb2xvciBncm91cFwiIGZpZWxkLlxyXG4gICAgY29uc3QgcGxheWVyQ29sb3JHcm91cCA9IGVsZW1lbnQuZmluZCgnLmZvcm0tZ3JvdXAnKS5lcSgyKTtcclxuICAgIHBsYXllckNvbG9yR3JvdXAuYWZ0ZXIoWyQoZGlzY29yZElEU2V0dGluZyldKTtcclxuXHJcbiAgICBpZiAoZm91bmRyeVVzZXIuaXNHTSkge1xyXG4gICAgICAgIC8qXHJcbiAgICAgICAgLy8gZ2V0IHRoZWlyIEdNIE5vdGlmaWNhdGlvbiBzdGF0dXMgaWYgaXQgZXhpc3RzLCBkZWZhdWx0aW5nIHRvIHRydWUuXHJcbiAgICAgICAgY29uc3Qgc2VuZEdNTm90aWZpY2F0aW9uczogYm9vbGVhbiA9IGF3YWl0IGZvdW5kcnlVc2VyLmdldEZsYWcoJ2Rpc2NvcmQtaW50ZWdyYXRpb24nLCAnc2VuZEdNTm90aWZpY2F0aW9ucycpIGFzIGJvb2xlYW47XHJcblxyXG4gICAgICAgIFxyXG4gICAgICAgIGNvbnN0IGlzQ2hlY2tlZCA9IHNlbmRHTU5vdGlmaWNhdGlvbnMgPyBcImNoZWNrZWRcIiA6IFwiXCI7XHJcbiAgICAgICAgY29uc3QgZ21Ob3RpZmljYXRpb25DaGVja2JveCA9IGA8aW5wdXQgdHlwZT1cImNoZWNrYm94XCIgbmFtZT1cImdtLW5vdGlmaWNhdGlvbi1jb25maWdcIiAke2lzQ2hlY2tlZH0+YFxyXG5cclxuICAgICAgICBjb25zdCBnbU5vdGlmaWNhdGlvblNldHRpbmcgPSBgXHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWw+JHtnYW1lLmkxOG4ubG9jYWxpemUoXCJESVNDT1JESU5URUdSQVRJT04uR01Ob3RpZmljYXRpb25zTGFiZWxcIikgYXMgc3RyaW5nfTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAke2dtTm90aWZpY2F0aW9uQ2hlY2tib3h9XHJcbiAgICAgICAgICAgIDwvZGl2PmBcclxuICAgICAgICAqL1xyXG4gICAgfVxyXG59KTtcclxuXHJcbi8vIGNvbW1pdCBhbnkgY2hhbmdlcyB0byB1c2VyQ29uZmlnXHJcbkhvb2tzLm9uKFwiY2xvc2VVc2VyQ29uZmlnXCIsIGFzeW5jIGZ1bmN0aW9uIChjb25maWc6IFVzZXJDb25maWcsIGVsZW1lbnQ6IEpRdWVyeSkge1xyXG4gICAgLy8gZmluZCB0aGUgdXNlciB0aGF0IHRoZSBjb25maWcgd2FzIG9wZW4gZm9yXHJcbiAgICBjb25zdCBmb3VuZHJ5VXNlcjogU3RvcmVkRG9jdW1lbnQ8VXNlcj4gPSBnYW1lVXNlcnMuZmlsdGVyKHVzZXIgPT4geyByZXR1cm4gdXNlci5pZCA9PT0gKGNvbmZpZy5vYmplY3QpLmRhdGEuX2lkIH0pWzBdO1xyXG4gICAgY29uc3QgZGlzY29yZElEOiBzdHJpbmcgPSAoZWxlbWVudC5maW5kKFwiaW5wdXRbbmFtZSA9ICdkaXNjb3JkLWlkLWNvbmZpZyddXCIpWzBdIGFzIEhUTUxJbnB1dEVsZW1lbnQpLnZhbHVlO1xyXG5cclxuICAgIGlmIChkaXNjb3JkSUQubGVuZ3RoICE9PSBESVNDT1JEX0lEX0xFTkdUSCB8fCBpc05hTihwYXJzZUludChkaXNjb3JkSUQpKSkge1xyXG4gICAgICAgIHVpLm5vdGlmaWNhdGlvbnMuZXJyb3IoZm91bmRyeUdhbWUuaTE4bi5sb2NhbGl6ZShcIkRJU0NPUkRJTlRFR1JBVElPTi5JbnZhbGlkSWRFcnJvclwiKSlcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgYXdhaXQgZm91bmRyeVVzZXIudXBkYXRlKHsgJ2ZsYWdzLmRpc2NvcmQtaW50ZWdyYXRpb24uZGlzY29yZElEJzogZGlzY29yZElEIH0pO1xyXG4gICAgfVxyXG4gICAgLypcclxuICAgIGNvbnN0IGdtTm90aWZpY2F0aW9uRWxlbWVudCA9IGVsZW1lbnQuZmluZChcImlucHV0W25hbWUgPSAnZ20tbm90aWZpY2F0aW9uLWNvbmZpZyddXCIpO1xyXG4gICAgbGV0IGdtTm90aWZpY2F0aW9uczogYm9vbGVhblxyXG4gICAgaWYgKGdtTm90aWZpY2F0aW9uRWxlbWVudCAmJiBnbU5vdGlmaWNhdGlvbkVsZW1lbnRbMF0pIHtcclxuICAgICAgICBnbU5vdGlmaWNhdGlvbnMgPSAoZWxlbWVudC5maW5kKFwiaW5wdXRbbmFtZSA9ICdnbS1ub3RpZmljYXRpb24tY29uZmlnJ11cIilbMF0gYXMgSFRNTElucHV0RWxlbWVudCkuY2hlY2tlZDtcclxuICAgIH1cclxuICAgICovXHJcbiAgICAvLyB1cGRhdGUgdGhlIGZsYWdcclxuICAgIC8vYXdhaXQgZm91bmRyeVVzZXIudXBkYXRlKHsgJ2ZsYWdzLmRpc2NvcmQtaW50ZWdyYXRpb24uc2VuZEdNTm90aWZpY2F0aW9ucyc6IGdtTm90aWZpY2F0aW9ucyB9KTtcclxufSk7XHJcblxyXG4vKipcclxuICogVG8gZm9yd2FyZCBhIG1lc3NhZ2UgdG8gZGlzY29yZCwgZG8gb25lIG9mIHR3byB0aGluZ3M6XHJcbiAqIFxyXG4gKiAtaW5jbHVkZSBcIkA8dXNlcm5hbWU+XCIgZm9yIGEgdXNlciBpbiB0aGUgZ2FtZSwgaXQgd2lsbCB0aGVuIGxvb2sgdXAgdGhlIGNvcnJlc3BvbmRpbmcgZGlzY29yZElEIFxyXG4gKiBhbmQgc2VuZCBhIG1lc3NhZ2UgcGluZ2luZyB0aGVtLiBJZiB5b3UgQCBtdWx0aXBsZSBwZW9wbGUsIGl0IHdpbGwgcGluZyBhbGwgb2YgdGhlbS4gV2lsbCBub3RcclxuICogc2VuZCBhIG1lc3NhZ2UgdW5sZXNzIHRoZSB1c2VybmFtZSBtYXRjaGVzIHVwIHdpdGggYW4gYWN0dWFsIHVzZXIuXHJcbiAqIFxyXG4gKiAtaW5jbHVkZSBcIkBEaXNjb3JkXCIsIHdoaWNoIHdpbGwgdW5jb25kaXRpb25hbGx5IGZvcndhcmQgdGhlIG1lc3NhZ2UgKG1pbnVzIHRoZSBARGlzY29yZCkgdG8gdGhlIERpc2NvcmQgV2ViaG9vay5cclxuICovXHJcblxyXG4vLyB3aGVuZXZlciBzb21lb25lIHNlbmRzIGEgY2hhdCBtZXNzYWdlLCBpZiBpdCBpcyBtYXJrZWQgdXAgcHJvcGVybHkgZm9yd2FyZCBpdCB0byBEaXNjb3JkLlxyXG5Ib29rcy5vbihcImNoYXRNZXNzYWdlXCIsIGZ1bmN0aW9uIChfY2hhdExvZzogQ2hhdExvZywgbWVzc2FnZTogc3RyaW5nKSB7XHJcbiAgICBjb25zdCBkaXNjb3JkVGFnczogc3RyaW5nW10gPSBbXTtcclxuICAgIGRpc2NvcmRUYWdzLnB1c2goXCJARGlzY29yZFwiKTtcclxuXHJcbiAgICBsZXQgc2hvdWxkU2VuZE1lc3NhZ2UgPSBmYWxzZTtcclxuICAgIGlmIChnYW1lLnNldHRpbmdzLmdldCgnZGlzY29yZC1pbnRlZ3JhdGlvbicsICdmb3J3YXJkQWxsTWVzc2FnZXMnKSkge1xyXG4gICAgICAgIHNob3VsZFNlbmRNZXNzYWdlID0gdHJ1ZTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgZ2FtZVVzZXJzLmZvckVhY2goKHVzZXI6IFVzZXIpID0+IHtcclxuICAgICAgICAgICAgaWYgKGdhbWUuc2V0dGluZ3MuZ2V0KCdkaXNjb3JkLWludGVncmF0aW9uJywgJ3BpbmdCeVVzZXJOYW1lJykpIHtcclxuICAgICAgICAgICAgICAgIGRpc2NvcmRUYWdzLnB1c2goYEAke3VzZXIubmFtZX1gKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChnYW1lLnNldHRpbmdzLmdldCgnZGlzY29yZC1pbnRlZ3JhdGlvbicsICdwaW5nQnlDaGFyYWN0ZXJOYW1lJykgJiYgdXNlci5jaGFyYWN0ZXIpIHtcclxuICAgICAgICAgICAgICAgIGRpc2NvcmRUYWdzLnB1c2goYEAkeyh1c2VyLmNoYXJhY3RlciBhcyBBY3RvckRhdGEpLm5hbWV9YClcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pXHJcbiAgICAgICAgZGlzY29yZFRhZ3MuZm9yRWFjaCh0YWcgPT4ge1xyXG4gICAgICAgICAgICBpZiAobWVzc2FnZS5pbmNsdWRlcyh0YWcpKSB7XHJcbiAgICAgICAgICAgICAgICBzaG91bGRTZW5kTWVzc2FnZSA9IHRydWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KVxyXG4gICAgfVxyXG4gICAgaWYgKHNob3VsZFNlbmRNZXNzYWdlKSB7XHJcbiAgICAgICAgSG9va3MuY2FsbEFsbChcInNlbmREaXNjb3JkTWVzc2FnZVwiLCBtZXNzYWdlKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgLy8gVE9ETyBkaXNjb3JkLWludGVncmF0aW9uIzM1OiBUaGlzIGV4aXN0cyBhcyBhIHdheSB0byB0ZXN0IHdoZW4gYSBtZXNzYWdlIGlzIG5vdCBzZW50LiBGaWd1cmUgb3V0IGEgd2F5IHRvIGRvIGl0IHdpdGhvdXQgbW9kaWZ5aW5nIHRoZSBjb2RlIGxhdGVyLlxyXG4gICAgICAgIGNvbnNvbGUubG9nKFwiTWVzc2FnZSBub3Qgc2VudC5cIilcclxuICAgIH1cclxuXHJcbn0pO1xyXG5cclxuSG9va3Mub24oXCJzZW5kRGlzY29yZE1lc3NhZ2VcIiwgZnVuY3Rpb24gKG1lc3NhZ2U6IHN0cmluZykge1xyXG4gICAgc2VuZERpc2NvcmRNZXNzYWdlKG1lc3NhZ2UpLmNhdGNoKChyZWFzb24pID0+IHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKHJlYXNvbik7XHJcbiAgICB9KTtcclxufSk7XHJcblxyXG4vKipcclxuICogU2VuZHMgYSBtZXNzYWdlIHRocm91Z2ggdGhlIGRpc2NvcmQgd2ViaG9vayBhcyBjb25maWd1cmVkIGluIHNldHRpbmdzLlxyXG4gKiBcclxuICogTWVzc2FnZXMgdGhhdCBwaW5nIHVzZXJzIGluIERpc2NvcmQgbmVlZCB0byBoYXZlIFwiQDxnYW1lVXNlck5hbWU+XCIgYW5kIHRoZSB1c2VycyBtdXN0IGhhdmUgdGhlaXIgZGlzY29yZCBJRHMgY29uZmlndXJlZC5cclxuICogXHJcbiAqIEBwYXJhbSBtZXNzYWdlIFRoZSBtZXNzYWdlIHRvIGZvcndhcmQgdG8gRGlzY29yZFxyXG4gKi9cclxuYXN5bmMgZnVuY3Rpb24gc2VuZERpc2NvcmRNZXNzYWdlKG1lc3NhZ2U6IHN0cmluZykge1xyXG5cclxuICAgIGxldCBzZW5kTWVzc2FnZSA9IHRydWU7XHJcblxyXG4gICAgY29uc3QgZGlzY29yZFdlYmhvb2sgPSBnYW1lLnNldHRpbmdzLmdldCgnZGlzY29yZC1pbnRlZ3JhdGlvbicsICdkaXNjb3JkV2ViaG9vaycpIGFzIHN0cmluZztcclxuICAgIGlmICghZGlzY29yZFdlYmhvb2spIHtcclxuICAgICAgICB1aS5ub3RpZmljYXRpb25zLmVycm9yKFxyXG4gICAgICAgICAgICBmb3VuZHJ5R2FtZS5pMThuLmxvY2FsaXplKFwiRElTQ09SRElOVEVHUkFUSU9OLkNvdWxkTm90U2VuZE1lc3NhZ2VcIilcclxuICAgICAgICAgICAgKyBmb3VuZHJ5R2FtZS5pMThuLmxvY2FsaXplKFwiRElTQ09SRElOVEVHUkFUSU9OLk5vRGlzY29yZFdlYmhvb2tFcnJvclwiKSlcclxuICAgICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgdXNlcnNUb0NoYXJzOiBNYXA8c3RyaW5nLCBzdHJpbmc+ID0gbmV3IE1hcDxzdHJpbmcsIHN0cmluZz4oKTtcclxuXHJcbiAgICBjb25zdCB1c2Vyc1RvUGluZzogc3RyaW5nW10gPSBbXTtcclxuXHJcbiAgICBnYW1lVXNlcnMuZm9yRWFjaCgodXNlcjogVXNlcikgPT4ge1xyXG4gICAgICAgIGlmIChtZXNzYWdlLmluZGV4T2YoYEAke3VzZXIubmFtZX1gKSAhPT0gLTEpIHtcclxuICAgICAgICAgICAgdXNlcnNUb1BpbmcucHVzaCh1c2VyLm5hbWUpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodXNlci5jaGFyYWN0ZXIpIHtcclxuICAgICAgICAgICAgdXNlcnNUb0NoYXJzLnNldCh1c2VyLm5hbWUsICgodXNlci5jaGFyYWN0ZXIgYXMgQWN0b3JEYXRhKS5uYW1lKSk7XHJcbiAgICAgICAgfVxyXG4gICAgfSlcclxuXHJcbiAgICB1c2Vyc1RvQ2hhcnMuZm9yRWFjaCgoY2hhck5hbWU6IHN0cmluZywgdXNlck5hbWU6IHN0cmluZywgX21hcCkgPT4ge1xyXG4gICAgICAgIC8vIFBpbmcgaWYgYSB1c2VyIG9yIHRoZWlyIGNoYXJhY3RlcidzIG5hbWUgaXMgdGFnZ2VkXHJcbiAgICAgICAgaWYgKG1lc3NhZ2UuaW5kZXhPZihgQCR7Y2hhck5hbWV9YCkgIT09IC0xKSB7XHJcbiAgICAgICAgICAgIHVzZXJzVG9QaW5nLnB1c2godXNlck5hbWUpO1xyXG4gICAgICAgIH1cclxuICAgIH0pXHJcblxyXG4gICAgLy8gc2VhcmNoIGZvciBARGlzY29yZCBpbiB0aGUgbWVzc2FnZVxyXG4gICAgY29uc3Qgc2hvdWxkUGluZ0Rpc2NvcmQ6IGJvb2xlYW4gPSAobWVzc2FnZS5zZWFyY2goYEBEaXNjb3JkYCkgIT09IC0xKTtcclxuXHJcbiAgICAvLyBpZiBpdCBmb3VuZCBhbnkgQDx1c2VybmFtZT4gdmFsdWVzLCByZXBsYWNlIHRoZSB2YWx1ZXMgaW4gdGhlIG1lc3NhZ2Ugd2l0aCBhcHByb3ByaWF0ZSBkaXNjb3JkIHBpbmdzLCB0aGVuIHNlbmQgZGlzY29yZCBtZXNzYWdlLlxyXG4gICAgaWYgKHVzZXJzVG9QaW5nLmxlbmd0aCAhPT0gMCkge1xyXG4gICAgICAgIHVzZXJzVG9QaW5nLmZvckVhY2goKHVzZXJOYW1lOiBzdHJpbmcpID0+IHtcclxuICAgICAgICAgICAgY29uc3QgY3VycmVudFVzZXI6IFVzZXIgfCB1bmRlZmluZWQgPSBnYW1lVXNlcnMuZmlsdGVyKCh1c2VyOiBVc2VyKSA9PiB7IHJldHVybiB1c2VyLmRhdGEubmFtZSA9PT0gdXNlck5hbWUgfSlbMF07XHJcbiAgICAgICAgICAgIGlmIChjdXJyZW50VXNlcikge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgY3VycmVudFVzZXJEaXNjb3JkSUQ6IHN0cmluZyA9IGN1cnJlbnRVc2VyLmdldEZsYWcoJ2Rpc2NvcmQtaW50ZWdyYXRpb24nLCAnZGlzY29yZElEJykgYXMgc3RyaW5nO1xyXG4gICAgICAgICAgICAgICAgaWYgKCFjdXJyZW50VXNlckRpc2NvcmRJRCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHVpLm5vdGlmaWNhdGlvbnMuZXJyb3IoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvdW5kcnlHYW1lLmkxOG4ubG9jYWxpemUoXCJESVNDT1JESU5URUdSQVRJT04uQ291bGROb3RTZW5kTWVzc2FnZVwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICArIGN1cnJlbnRVc2VyLm5hbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgKyBmb3VuZHJ5R2FtZS5pMThuLmxvY2FsaXplKFwiRElTQ09SRElOVEVHUkFUSU9OLlVzZXJIYXNOb0lkRXJyb3JcIikpXHJcbiAgICAgICAgICAgICAgICAgICAgc2VuZE1lc3NhZ2UgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlID0gbWVzc2FnZS5yZXBsYWNlKGBAJHt1c2VyTmFtZX1gLCBgPEAke2N1cnJlbnRVc2VyRGlzY29yZElEfT5gKTtcclxuICAgICAgICAgICAgICAgIG1lc3NhZ2UgPSBtZXNzYWdlLnJlcGxhY2UoYEAke3VzZXJzVG9DaGFycy5nZXQodXNlck5hbWUpfWAsIGA8QCR7Y3VycmVudFVzZXJEaXNjb3JkSUR9PmApO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSlcclxuICAgICAgICAvLyBlbHNlIGlmIERpc2NvcmQgYXMgYSB3aG9sZSBpcyBiZWluZyBwaW5nZWQsIHJlbW92ZSB0aGUgXCJARGlzY29yZFwiIHBhcnQgYW5kIHRoZW4gc2VuZCB0aGUgbWVzc2FnZS5cclxuICAgIH0gZWxzZSBpZiAoc2hvdWxkUGluZ0Rpc2NvcmQpIHtcclxuICAgICAgICBtZXNzYWdlID0gbWVzc2FnZS5zcGxpdChcIkBEaXNjb3JkXCIpLnBvcCgpIHx8IFwiXCI7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgbWVzc2FnZUpTT04gPSB7XHJcbiAgICAgICAgXCJjb250ZW50XCI6IG1lc3NhZ2VcclxuICAgIH1cclxuXHJcbiAgICBsZXQganNvbk1lc3NhZ2U6IHN0cmluZztcclxuICAgIHRyeSB7XHJcbiAgICAgICAganNvbk1lc3NhZ2UgPSBKU09OLnN0cmluZ2lmeShtZXNzYWdlSlNPTik7XHJcbiAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgdWkubm90aWZpY2F0aW9ucy5lcnJvcihcclxuICAgICAgICAgICAgZm91bmRyeUdhbWUuaTE4bi5sb2NhbGl6ZShcIkRJU0NPUkRJTlRFR1JBVElPTi5Db3VsZE5vdFNlbmRNZXNzYWdlXCIpXHJcbiAgICAgICAgICAgICsgZm91bmRyeUdhbWUuaTE4bi5sb2NhbGl6ZShcIkRJU0NPUkRJTlRFR1JBVElPTi5Db3VsZE5vdFN0cmluZ2lmeUpzb25FcnJvclwiKSlcclxuICAgICAgICBzZW5kTWVzc2FnZSA9IGZhbHNlO1xyXG4gICAgfVxyXG5cclxuICAgIGlmIChzZW5kTWVzc2FnZSkge1xyXG4gICAgICAgIGF3YWl0ICQuYWpheCh7XHJcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxyXG4gICAgICAgICAgICB1cmw6IGRpc2NvcmRXZWJob29rLFxyXG4gICAgICAgICAgICBjb250ZW50VHlwZTogXCJhcHBsaWNhdGlvbi9qc29uXCIsXHJcbiAgICAgICAgICAgIGRhdGE6IGpzb25NZXNzYWdlXHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcbn0iXX0=
