// TODO discord-integration#34: Thrown on Hooks.on(), cause and fix unknown
/* eslint-disable @typescript-eslint/no-unsafe-call */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
let gameUsers;
let foundryGame;
// Discord user-ids are either 17 or 18 digits.
const DISCORD_MAX_ID_LENGTH = 18;
const DISCORD_MIN_ID_LENGTH = 17;
// Element IDs
const TOKEN_CONTROLS_TOGGLE_BUTTON = '#controls > ol.sub-controls.app.control-tools.flexcol.active > li[data-tool="discord-integration-toggle"]';
/**
 * Returns the game object.
 */
function getGame() {
    return game;
}
Hooks.once("ready", function () {
    gameUsers = (game.users).contents;
});
Hooks.once("init", function () {
    foundryGame = getGame();
    // Add settings option for URL of Discord Webhook
    foundryGame.settings.register("discord-integration", "discordWebhook", {
        name: foundryGame.i18n.localize("DISCORDINTEGRATION.SettingsDiscordWebhook"),
        hint: foundryGame.i18n.localize("DISCORDINTEGRATION.SettingsDiscordWebhookHint"),
        scope: "world",
        config: true,
        type: String,
        default: ""
    });
    // Add settings option for pinging by on character name
    foundryGame.settings.register("discord-integration", "pingByCharacterName", {
        name: foundryGame.i18n.localize("DISCORDINTEGRATION.SettingsPingByCharacterName"),
        hint: foundryGame.i18n.localize("DISCORDINTEGRATION.SettingsPingByCharacterNameHint"),
        scope: "world",
        config: true,
        default: true,
        type: Boolean
    });
    // Add settings option for pinging by user name
    foundryGame.settings.register("discord-integration", "pingByUserName", {
        name: foundryGame.i18n.localize("DISCORDINTEGRATION.SettingsPingByUserName"),
        hint: foundryGame.i18n.localize("DISCORDINTEGRATION.SettingsPingByUserNameHint"),
        scope: "world",
        config: true,
        default: true,
        type: Boolean
    });
    // Add settings option for forwarding ALL messages vs. forwarding only messages with pings.
    foundryGame.settings.register("discord-integration", "forwardAllMessages", {
        name: foundryGame.i18n.localize("DISCORDINTEGRATION.SettingsForwardAllMessages"),
        hint: foundryGame.i18n.localize("DISCORDINTEGRATION.SettingsForwardAllMessagesHint"),
        scope: "world",
        config: true,
        default: false,
        type: Boolean
    });
    // Add settings option for adding the player's name to the discord message
    foundryGame.settings.register("discord-integration", "prependUserName", {
        name: foundryGame.i18n.localize("DISCORDINTEGRATION.PrependUserName"),
        hint: foundryGame.i18n.localize("DISCORDINTEGRATION.PrependUserNameHint"),
        scope: "world",
        config: true,
        default: false,
        type: Boolean
    });
    // Add settings option to show/hide toggle button in tokencontrols
    foundryGame.settings.register("discord-integration", "tokenControlsButton", {
        name: foundryGame.i18n.localize("DISCORDINTEGRATION.TokenControlsButton"),
        hint: foundryGame.i18n.localize("DISCORDINTEGRATION.TokenControlsButtonHint"),
        scope: "world",
        config: true,
        default: false,
        type: Boolean
    });
    /**
     * Property manipulated by the token controls button to turn the mod's functionality on/off without disabling the
     * entire mod.
     */
    foundryGame.settings.register("discord-integration", "tokenControlsEnabled", {
        scope: "world",
        config: false,
        default: true,
        type: Boolean
    });
});
// Add button to to the token submenu in Scene controls to enable/disable the mod.
Hooks.on("getSceneControlButtons", function (controls) {
    // Just like the module settings, only the GM should be able to toggle the mod on/off.
    if (game.user.isGM && game.settings.get("discord-integration", "tokenControlsButton")) {
        controls.forEach((control) => {
            if (control.name === "token") {
                const tokenControlsButton = {
                    name: "discord-integration-toggle",
                    title: foundryGame.i18n.localize("DISCORDINTEGRATION.TokenControlsButtonTooltip"),
                    icon: "fab fa-discord",
                    toggle: true,
                    active: game.settings.get("discord-integration", "tokenControlsEnabled"),
                    onClick: toggleForwarding
                };
                control.tools.push(tokenControlsButton);
            }
            console.log(control.name);
        });
    }
});
// Add in the extra field for DiscordID
Hooks.on("renderUserConfig", function (config, element) {
    return __awaiter(this, void 0, void 0, function* () {
        // Find the user that you're opening config for
        // @ts-ignore Awaiting foundry-vtt-types update to use correct data schema
        const foundryUser = gameUsers.filter((user) => {
            // @ts-ignore
            return user.id === (config.object)._id;
        })[0];
        // Get their Discord ID if it exists
        let discordUserId = yield foundryUser.getFlag("discord-integration", "discordID");
        discordUserId = discordUserId ? discordUserId : "";
        // Create the input field to configure it.
        const discordIdInput = `<input type="text" name='discord-id-config' value="${discordUserId}" data-dtype="String">`;
        const discordIDSetting = `
        <div id="discord-id-setting" class="form-group discord">
            <label>${foundryGame.i18n.localize("DISCORDINTEGRATION.UserDiscordIdLabel")}</label>
            ${discordIdInput}
        </div>`;
        // Put the input fields below the "Player Color group" field.
        const playerColorGroup = element.find(".form-group").eq(2);
        playerColorGroup.after([$(discordIDSetting)]);
        if (foundryUser.isGM) {
            /*
                // get their GM Notification status if it exists, defaulting to true.
                const sendGMNotifications: boolean = await foundryUser.getFlag('discord-integration', 'sendGMNotifications')
                  as boolean;
        
                const isChecked = sendGMNotifications ? "checked" : "";
                const gmNotificationCheckbox = `<input type="checkbox" name="gm-notification-config" ${isChecked}>`
        
                const gmNotificationSetting = `
                    <div>
                        <label>${game.i18n.localize("DISCORDINTEGRATION.GMNotificationsLabel") as string}</label>
                        ${gmNotificationCheckbox}
                    </div>`
                */
        }
    });
});
// Commit any changes to userConfig
Hooks.on("closeUserConfig", function (config, element) {
    return __awaiter(this, void 0, void 0, function* () {
        // Find the user that the config was open for
        // @ts-ignore Awaiting foundry-vtt-types update to use correct data schema
        const foundryUser = gameUsers.filter(user => { return user.id === (config.object)._id; })[0];
        const discordID = element.find("input[name = 'discord-id-config']")[0].value;
        if (discordID.length > DISCORD_MAX_ID_LENGTH
            || discordID.length < DISCORD_MIN_ID_LENGTH
            || isNaN(parseInt(discordID))) {
            ui.notifications.error(foundryGame.i18n.localize("DISCORDINTEGRATION.InvalidIdError"));
        }
        else {
            yield foundryUser.update({ "flags.discord-integration.discordID": discordID });
        }
        /*
          Const gmNotificationElement = element.find("input[name = 'gm-notification-config']");
          let gmNotifications: boolean
          if (gmNotificationElement && gmNotificationElement[0]) {
              gmNotifications = (element.find("input[name = 'gm-notification-config']")[0] as HTMLInputElement).checked;
          }
          */
        // update the flag
        // await foundryUser.update({ 'flags.discord-integration.sendGMNotifications': gmNotifications });
    });
});
/**
 * To forward a message to discord, do one of two things:
 *
 * -include "@<username>" for a user in the game, it will then look up the corresponding discordID
 * and send a message pinging them. If you @ multiple people, it will ping all of them. Will not
 * send a message unless the username matches up with an actual user.
 *
 * -include "@Discord", which will unconditionally forward the message (minus the @Discord) to the Discord Webhook.
 */
// whenever someone sends a chat message, if it is marked up properly forward it to Discord.
Hooks.on("chatMessage", function (_chatLog, message, messageData) {
    const discordTags = [];
    discordTags.push("@Discord");
    let shouldSendMessage = false;
    // If the toggle button is turned off, we ignore the value of tokenControlsEnabled.
    // This is to avoid a situation where the last setting of the button was to "disabled" and the button is disabled,
    // making it unclear why messages will not send.
    if (game.settings.get("discord-integration", "tokenControlsButton") && !game.settings.get("discord-integration", "tokenControlsEnabled")) {
        shouldSendMessage = false;
    }
    else if (game.settings.get("discord-integration", "forwardAllMessages")) {
        shouldSendMessage = true;
    }
    else {
        gameUsers.forEach((user) => {
            if (game.settings.get("discord-integration", "pingByUserName")) {
                discordTags.push(`@${user.name}`);
            }
            if (game.settings.get("discord-integration", "pingByCharacterName") && user.character) {
                discordTags.push(`@${user.character.name}`);
            }
        });
        discordTags.forEach(tag => {
            if (message.includes(tag)) {
                shouldSendMessage = true;
            }
        });
    }
    if (shouldSendMessage) {
        // If we are appending the sender's name to the message, we do so here.
        if (game.settings.get("discord-integration", "prependUserName")) {
            const messageSenderId = messageData.user;
            const messageSender = gameUsers.find(user => user.id === messageSenderId);
            message = `${messageSender.name}: ${message}`;
        }
        Hooks.callAll("sendDiscordMessage", message);
    }
    else {
        /**
         * TODO discord-integration#35: This exists as a way to test when a message is not sent.
         * Figure out a way to do it without modifying the code later.
         */
        console.log("Message not sent.");
    }
});
Hooks.on("sendDiscordMessage", function (message) {
    sendDiscordMessage(message).catch(reason => {
        console.error(reason);
    });
});
/**
 * Listener function for the button in the Token Settings menu to toggle forwarding of messages to Discord.
 */
function toggleForwarding() {
    return __awaiter(this, void 0, void 0, function* () {
        const newSettingValue = !game.settings.get("discord-integration", "tokenControlsEnabled");
        yield game.settings.set("discord-integration", "tokenControlsEnabled", newSettingValue);
        newSettingValue ? $(TOKEN_CONTROLS_TOGGLE_BUTTON).addClass("active") : $(TOKEN_CONTROLS_TOGGLE_BUTTON).removeClass("active");
    });
}
/**
 * Sends a message through the discord webhook as configured in settings.
 *
 * Messages that ping users in Discord need to have "@<gameUserName>"
 * and the users must have their discord IDs configured.
 *
 * @param message The message to forward to Discord
 */
function sendDiscordMessage(message) {
    return __awaiter(this, void 0, void 0, function* () {
        let sendMessage = true;
        const discordWebhook = game.settings.get("discord-integration", "discordWebhook");
        if (!discordWebhook) {
            ui.notifications.error(foundryGame.i18n.localize("DISCORDINTEGRATION.CouldNotSendMessage")
                + foundryGame.i18n.localize("DISCORDINTEGRATION.NoDiscordWebhookError"));
            return;
        }
        const usersToChars = new Map();
        const usersToPing = [];
        gameUsers.forEach((user) => {
            if (message.indexOf(`@${user.name}`) !== -1) {
                usersToPing.push(user.name);
            }
            if (user.character) {
                usersToChars.set(user.name, (user.character.name));
            }
        });
        usersToChars.forEach((charName, userName, _map) => {
            // Ping if a user or their character's name is tagged
            if (message.indexOf(`@${charName}`) !== -1) {
                usersToPing.push(userName);
            }
        });
        // Search for @Discord in the message
        const shouldPingDiscord = (message.search("@Discord") !== -1);
        /**
         * If it found any @<username> values, replace the values in the message with appropriate discord pings,
         * then send discord message.
         */
        if (usersToPing.length !== 0) {
            usersToPing.forEach((userName) => {
                const currentUser = gameUsers.filter((user) => {
                    return user.data.name === userName;
                })[0];
                if (currentUser) {
                    const currentUserDiscordID = currentUser.getFlag("discord-integration", "discordID");
                    if (!currentUserDiscordID) {
                        ui.notifications.error(foundryGame.i18n.localize("DISCORDINTEGRATION.CouldNotSendMessage")
                            + currentUser.name
                            + foundryGame.i18n.localize("DISCORDINTEGRATION.UserHasNoIdError"));
                        sendMessage = false;
                        return;
                    }
                    message = message.replace(`@${userName}`, `<@${currentUserDiscordID}>`);
                    message = message.replace(`@${usersToChars.get(userName)}`, `<@${currentUserDiscordID}>`);
                }
            });
            // Else if Discord as a whole is being pinged, remove the "@Discord" part and then send the message.
        }
        else if (shouldPingDiscord) {
            message = message.replace("@Discord ", "") || "";
        }
        const messageJSON = {
            content: message
        };
        let jsonMessage;
        try {
            jsonMessage = JSON.stringify(messageJSON);
        }
        catch (e) {
            ui.notifications.error(foundryGame.i18n.localize("DISCORDINTEGRATION.CouldNotSendMessage")
                + foundryGame.i18n.localize("DISCORDINTEGRATION.CouldNotStringifyJsonError"));
            sendMessage = false;
        }
        if (sendMessage) {
            yield $.ajax({
                method: "POST",
                url: discordWebhook,
                contentType: "application/json",
                data: jsonMessage
            });
        }
    });
}
class ChatMessageData {
}
export {};

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9EaXNjb3JkSW50ZWdyYXRpb24udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsMkVBQTJFO0FBQzNFLHNEQUFzRDs7Ozs7Ozs7OztBQUl0RCxJQUFJLFNBQWlDLENBQUM7QUFDdEMsSUFBSSxXQUFpQixDQUFDO0FBRXRCLCtDQUErQztBQUMvQyxNQUFNLHFCQUFxQixHQUFHLEVBQUUsQ0FBQztBQUNqQyxNQUFNLHFCQUFxQixHQUFHLEVBQUUsQ0FBQztBQUVqQyxjQUFjO0FBQ2QsTUFBTSw0QkFBNEIsR0FBRywyR0FBMkcsQ0FBQztBQUVqSjs7R0FFRztBQUNILFNBQVMsT0FBTztJQUNkLE9BQU8sSUFBSSxDQUFDO0FBQ2QsQ0FBQztBQUVELEtBQUssQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFO0lBQ2xCLFNBQVMsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDcEMsQ0FBQyxDQUFDLENBQUM7QUFFSCxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRTtJQUNqQixXQUFXLEdBQUcsT0FBTyxFQUFFLENBQUM7SUFDeEIsaURBQWlEO0lBQ2pELFdBQVcsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLHFCQUFxQixFQUFFLGdCQUFnQixFQUFFO1FBQ3JFLElBQUksRUFBRSxXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQywyQ0FBMkMsQ0FBQztRQUM1RSxJQUFJLEVBQUUsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsK0NBQStDLENBQUM7UUFDaEYsS0FBSyxFQUFFLE9BQU87UUFDZCxNQUFNLEVBQUUsSUFBSTtRQUNaLElBQUksRUFBRSxNQUFNO1FBQ1osT0FBTyxFQUFFLEVBQUU7S0FDWixDQUFDLENBQUM7SUFDSCx1REFBdUQ7SUFDdkQsV0FBVyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMscUJBQXFCLEVBQUUscUJBQXFCLEVBQUU7UUFDMUUsSUFBSSxFQUFFLFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGdEQUFnRCxDQUFDO1FBQ2pGLElBQUksRUFBRSxXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxvREFBb0QsQ0FBQztRQUNyRixLQUFLLEVBQUUsT0FBTztRQUNkLE1BQU0sRUFBRSxJQUFJO1FBQ1osT0FBTyxFQUFFLElBQUk7UUFDYixJQUFJLEVBQUUsT0FBTztLQUNkLENBQUMsQ0FBQztJQUNILCtDQUErQztJQUMvQyxXQUFXLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxxQkFBcUIsRUFBRSxnQkFBZ0IsRUFBRTtRQUNyRSxJQUFJLEVBQUUsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsMkNBQTJDLENBQUM7UUFDNUUsSUFBSSxFQUFFLFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLCtDQUErQyxDQUFDO1FBQ2hGLEtBQUssRUFBRSxPQUFPO1FBQ2QsTUFBTSxFQUFFLElBQUk7UUFDWixPQUFPLEVBQUUsSUFBSTtRQUNiLElBQUksRUFBRSxPQUFPO0tBRWQsQ0FBQyxDQUFDO0lBQ0gsMkZBQTJGO0lBQzNGLFdBQVcsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLHFCQUFxQixFQUFFLG9CQUFvQixFQUFFO1FBQ3pFLElBQUksRUFBRSxXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQywrQ0FBK0MsQ0FBQztRQUNoRixJQUFJLEVBQUUsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsbURBQW1ELENBQUM7UUFDcEYsS0FBSyxFQUFFLE9BQU87UUFDZCxNQUFNLEVBQUUsSUFBSTtRQUNaLE9BQU8sRUFBRSxLQUFLO1FBQ2QsSUFBSSxFQUFFLE9BQU87S0FDZCxDQUFDLENBQUM7SUFDSCwwRUFBMEU7SUFDMUUsV0FBVyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMscUJBQXFCLEVBQUUsaUJBQWlCLEVBQUU7UUFDdEUsSUFBSSxFQUFFLFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLG9DQUFvQyxDQUFDO1FBQ3JFLElBQUksRUFBRSxXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyx3Q0FBd0MsQ0FBQztRQUN6RSxLQUFLLEVBQUUsT0FBTztRQUNkLE1BQU0sRUFBRSxJQUFJO1FBQ1osT0FBTyxFQUFFLEtBQUs7UUFDZCxJQUFJLEVBQUUsT0FBTztLQUNkLENBQUMsQ0FBQztJQUNILGtFQUFrRTtJQUNsRSxXQUFXLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxxQkFBcUIsRUFBRSxxQkFBcUIsRUFBRTtRQUMxRSxJQUFJLEVBQUUsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsd0NBQXdDLENBQUM7UUFDekUsSUFBSSxFQUFFLFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLDRDQUE0QyxDQUFDO1FBQzdFLEtBQUssRUFBRSxPQUFPO1FBQ2QsTUFBTSxFQUFFLElBQUk7UUFDWixPQUFPLEVBQUUsS0FBSztRQUNkLElBQUksRUFBRSxPQUFPO0tBQ2QsQ0FBQyxDQUFDO0lBQ0g7OztPQUdHO0lBQ0gsV0FBVyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMscUJBQXFCLEVBQUUsc0JBQXNCLEVBQUU7UUFDM0UsS0FBSyxFQUFFLE9BQU87UUFDZCxNQUFNLEVBQUUsS0FBSztRQUNiLE9BQU8sRUFBRSxJQUFJO1FBQ2IsSUFBSSxFQUFFLE9BQU87S0FDZCxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQztBQUVILGtGQUFrRjtBQUNsRixLQUFLLENBQUMsRUFBRSxDQUFDLHdCQUF3QixFQUFFLFVBQVMsUUFBd0I7SUFDbEUsc0ZBQXNGO0lBQ3RGLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMscUJBQXFCLEVBQUUscUJBQXFCLENBQUMsRUFBRTtRQUNyRixRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBcUIsRUFBRSxFQUFFO1lBQ3pDLElBQUksT0FBTyxDQUFDLElBQUksS0FBSyxPQUFPLEVBQUU7Z0JBQzVCLE1BQU0sbUJBQW1CLEdBQUc7b0JBQzFCLElBQUksRUFBRSw0QkFBNEI7b0JBQ2xDLEtBQUssRUFBRSxXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQywrQ0FBK0MsQ0FBQztvQkFDakYsSUFBSSxFQUFFLGdCQUFnQjtvQkFDdEIsTUFBTSxFQUFFLElBQUk7b0JBQ1osTUFBTSxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLHFCQUFxQixFQUFFLHNCQUFzQixDQUFZO29CQUNuRixPQUFPLEVBQUUsZ0JBQWdCO2lCQUMxQixDQUFDO2dCQUNGLE9BQU8sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLENBQUM7YUFDekM7WUFDRCxPQUFPLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUM1QixDQUFDLENBQUMsQ0FBQztLQUNKO0FBQ0gsQ0FBQyxDQUFDLENBQUM7QUFFSCx1Q0FBdUM7QUFDdkMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxrQkFBa0IsRUFBRSxVQUFlLE1BQWtCLEVBQUUsT0FBZTs7UUFFN0UsK0NBQStDO1FBQy9DLDBFQUEwRTtRQUMxRSxNQUFNLFdBQVcsR0FBeUIsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQVUsRUFBRSxFQUFFO1lBQ3hFLGFBQWE7WUFDYixPQUFPLElBQUksQ0FBQyxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDO1FBQ3pDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRU4sb0NBQW9DO1FBQ3BDLElBQUksYUFBYSxHQUFXLE1BQU0sV0FBVyxDQUFDLE9BQU8sQ0FBQyxxQkFBcUIsRUFBRSxXQUFXLENBQVcsQ0FBQztRQUNwRyxhQUFhLEdBQUcsYUFBYSxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztRQUVuRCwwQ0FBMEM7UUFDMUMsTUFBTSxjQUFjLEdBQUcsc0RBQXNELGFBQWEsd0JBQXdCLENBQUM7UUFFbkgsTUFBTSxnQkFBZ0IsR0FBRzs7cUJBRU4sV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsdUNBQXVDLENBQUM7Y0FDekUsY0FBYztlQUNiLENBQUM7UUFFZCw2REFBNkQ7UUFDN0QsTUFBTSxnQkFBZ0IsR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUMzRCxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFOUMsSUFBSSxXQUFXLENBQUMsSUFBSSxFQUFFO1lBQ3BCOzs7Ozs7Ozs7Ozs7O2tCQWFNO1NBQ1A7SUFDSCxDQUFDO0NBQUEsQ0FBQyxDQUFDO0FBRUgsbUNBQW1DO0FBQ25DLEtBQUssQ0FBQyxFQUFFLENBQUMsaUJBQWlCLEVBQUUsVUFBZSxNQUFrQixFQUFFLE9BQWU7O1FBQzVFLDZDQUE2QztRQUM3QywwRUFBMEU7UUFDMUUsTUFBTSxXQUFXLEdBQXlCLFNBQVMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEVBQUUsR0FBRyxPQUFPLElBQUksQ0FBQyxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDbkgsTUFBTSxTQUFTLEdBQVksT0FBTyxDQUFDLElBQUksQ0FBQyxtQ0FBbUMsQ0FBQyxDQUFDLENBQUMsQ0FBc0IsQ0FBQyxLQUFLLENBQUM7UUFFM0csSUFBSSxTQUFTLENBQUMsTUFBTSxHQUFHLHFCQUFxQjtlQUN2QyxTQUFTLENBQUMsTUFBTSxHQUFHLHFCQUFxQjtlQUN4QyxLQUFLLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQy9CO1lBQ0UsRUFBRSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsbUNBQW1DLENBQUMsQ0FBQyxDQUFDO1NBQ3hGO2FBQU07WUFDTCxNQUFNLFdBQVcsQ0FBQyxNQUFNLENBQUMsRUFBRSxxQ0FBcUMsRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFDO1NBQ2hGO1FBQ0Q7Ozs7OztZQU1JO1FBQ0osa0JBQWtCO1FBQ2xCLGtHQUFrRztJQUNwRyxDQUFDO0NBQUEsQ0FBQyxDQUFDO0FBRUg7Ozs7Ozs7O0dBUUc7QUFFSCw0RkFBNEY7QUFDNUYsS0FBSyxDQUFDLEVBQUUsQ0FBQyxhQUFhLEVBQUUsVUFBUyxRQUFpQixFQUFFLE9BQWUsRUFBRSxXQUE0QjtJQUMvRixNQUFNLFdBQVcsR0FBYSxFQUFFLENBQUM7SUFDakMsV0FBVyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUU3QixJQUFJLGlCQUFpQixHQUFHLEtBQUssQ0FBQztJQUM5QixtRkFBbUY7SUFDbkYsa0hBQWtIO0lBQ2xILGdEQUFnRDtJQUNoRCxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLHFCQUFxQixFQUFFLHFCQUFxQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsRUFBRSxzQkFBc0IsQ0FBQyxFQUFFO1FBQ3hJLGlCQUFpQixHQUFHLEtBQUssQ0FBQztLQUMzQjtTQUFNLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMscUJBQXFCLEVBQUUsb0JBQW9CLENBQUMsRUFBRTtRQUN6RSxpQkFBaUIsR0FBRyxJQUFJLENBQUM7S0FDMUI7U0FBTTtRQUNMLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFVLEVBQUUsRUFBRTtZQUMvQixJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLHFCQUFxQixFQUFFLGdCQUFnQixDQUFDLEVBQUU7Z0JBQzlELFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQzthQUNuQztZQUNELElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMscUJBQXFCLEVBQUUscUJBQXFCLENBQUMsSUFBSSxJQUFJLENBQUMsU0FBUyxFQUFFO2dCQUNyRixXQUFXLENBQUMsSUFBSSxDQUFDLElBQUssSUFBSSxDQUFDLFNBQXVCLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQzthQUM1RDtRQUNILENBQUMsQ0FBQyxDQUFDO1FBQ0gsV0FBVyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUN4QixJQUFJLE9BQU8sQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQ3pCLGlCQUFpQixHQUFHLElBQUksQ0FBQzthQUMxQjtRQUNILENBQUMsQ0FBQyxDQUFDO0tBQ0o7SUFDRCxJQUFJLGlCQUFpQixFQUFFO1FBQ3JCLHVFQUF1RTtRQUN2RSxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLHFCQUFxQixFQUFFLGlCQUFpQixDQUFDLEVBQUU7WUFDL0QsTUFBTSxlQUFlLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQztZQUN6QyxNQUFNLGFBQWEsR0FBRyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsS0FBSyxlQUFlLENBQUMsQ0FBQztZQUMxRSxPQUFPLEdBQUcsR0FBRyxhQUFhLENBQUMsSUFBSSxLQUFLLE9BQU8sRUFBRSxDQUFDO1NBQy9DO1FBQ0QsS0FBSyxDQUFDLE9BQU8sQ0FBQyxvQkFBb0IsRUFBRSxPQUFPLENBQUMsQ0FBQztLQUM5QztTQUFNO1FBQ0w7OztXQUdHO1FBQ0gsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO0tBQ2xDO0FBRUgsQ0FBQyxDQUFDLENBQUM7QUFFSCxLQUFLLENBQUMsRUFBRSxDQUFDLG9CQUFvQixFQUFFLFVBQVMsT0FBZTtJQUNyRCxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEVBQUU7UUFDekMsT0FBTyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUN4QixDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDO0FBRUg7O0dBRUc7QUFDSCxTQUFlLGdCQUFnQjs7UUFDN0IsTUFBTSxlQUFlLEdBQUcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsRUFBRSxzQkFBc0IsQ0FBQyxDQUFDO1FBQzFGLE1BQU0sSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMscUJBQXFCLEVBQUUsc0JBQXNCLEVBQUUsZUFBZSxDQUFDLENBQUM7UUFDeEYsZUFBZSxDQUFBLENBQUMsQ0FBQyxDQUFDLENBQUMsNEJBQTRCLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUM5SCxDQUFDO0NBQUE7QUFFRDs7Ozs7OztHQU9HO0FBQ0gsU0FBZSxrQkFBa0IsQ0FBQyxPQUFlOztRQUUvQyxJQUFJLFdBQVcsR0FBRyxJQUFJLENBQUM7UUFFdkIsTUFBTSxjQUFjLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMscUJBQXFCLEVBQUUsZ0JBQWdCLENBQVcsQ0FBQztRQUM1RixJQUFJLENBQUMsY0FBYyxFQUFFO1lBQ25CLEVBQUUsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUNwQixXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyx3Q0FBd0MsQ0FBQztrQkFDM0QsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsMENBQTBDLENBQUMsQ0FBQyxDQUFDO1lBQ2pGLE9BQU87U0FDUjtRQUVELE1BQU0sWUFBWSxHQUF3QixJQUFJLEdBQUcsRUFBa0IsQ0FBQztRQUVwRSxNQUFNLFdBQVcsR0FBYSxFQUFFLENBQUM7UUFFakMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQVUsRUFBRSxFQUFFO1lBQy9CLElBQUksT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFO2dCQUMzQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUM3QjtZQUNELElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRTtnQkFDbEIsWUFBWSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUUsSUFBSSxDQUFDLFNBQXVCLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQzthQUNuRTtRQUNILENBQUMsQ0FBQyxDQUFDO1FBRUgsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQWdCLEVBQUUsUUFBZ0IsRUFBRSxJQUFJLEVBQUUsRUFBRTtZQUNoRSxxREFBcUQ7WUFDckQsSUFBSSxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksUUFBUSxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRTtnQkFDMUMsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQzthQUM1QjtRQUNILENBQUMsQ0FBQyxDQUFDO1FBRUgscUNBQXFDO1FBQ3JDLE1BQU0saUJBQWlCLEdBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFdkU7OztXQUdHO1FBQ0gsSUFBSSxXQUFXLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUM1QixXQUFXLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBZ0IsRUFBRSxFQUFFO2dCQUN2QyxNQUFNLFdBQVcsR0FBcUIsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQVUsRUFBRSxFQUFFO29CQUNwRSxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxLQUFLLFFBQVEsQ0FBQztnQkFDckMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ04sSUFBSSxXQUFXLEVBQUU7b0JBQ2YsTUFBTSxvQkFBb0IsR0FBVyxXQUFXLENBQUMsT0FBTyxDQUFDLHFCQUFxQixFQUFFLFdBQVcsQ0FBVyxDQUFDO29CQUN2RyxJQUFJLENBQUMsb0JBQW9CLEVBQUU7d0JBQ3pCLEVBQUUsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUNwQixXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyx3Q0FBd0MsQ0FBQzs4QkFDckQsV0FBVyxDQUFDLElBQUk7OEJBQ2hCLFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLHFDQUFxQyxDQUFDLENBQUMsQ0FBQzt3QkFDbEYsV0FBVyxHQUFHLEtBQUssQ0FBQzt3QkFDcEIsT0FBTztxQkFDUjtvQkFDRCxPQUFPLEdBQUcsT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLFFBQVEsRUFBRSxFQUFFLEtBQUssb0JBQW9CLEdBQUcsQ0FBQyxDQUFDO29CQUN4RSxPQUFPLEdBQUcsT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLFlBQVksQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEVBQUUsRUFBRSxLQUFLLG9CQUFvQixHQUFHLENBQUMsQ0FBQztpQkFDM0Y7WUFDSCxDQUFDLENBQUMsQ0FBQztZQUNILG9HQUFvRztTQUNyRzthQUFNLElBQUksaUJBQWlCLEVBQUU7WUFDNUIsT0FBTyxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFLEVBQUUsQ0FBQyxJQUFJLEVBQUUsQ0FBQztTQUNsRDtRQUVELE1BQU0sV0FBVyxHQUFHO1lBQ2xCLE9BQU8sRUFBRSxPQUFPO1NBQ2pCLENBQUM7UUFFRixJQUFJLFdBQW1CLENBQUM7UUFDeEIsSUFBSTtZQUNGLFdBQVcsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1NBQzNDO1FBQUMsT0FBTSxDQUFDLEVBQUU7WUFDVCxFQUFFLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FDcEIsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsd0NBQXdDLENBQUM7a0JBQzNELFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLCtDQUErQyxDQUFDLENBQUMsQ0FBQztZQUN0RixXQUFXLEdBQUcsS0FBSyxDQUFDO1NBQ3JCO1FBRUQsSUFBSSxXQUFXLEVBQUU7WUFDZixNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQ1gsTUFBTSxFQUFFLE1BQU07Z0JBQ2QsR0FBRyxFQUFFLGNBQWM7Z0JBQ25CLFdBQVcsRUFBRSxrQkFBa0I7Z0JBQy9CLElBQUksRUFBRSxXQUFXO2FBQ2xCLENBQUMsQ0FBQztTQUNKO0lBQ0gsQ0FBQztDQUFBO0FBRUQsTUFBTSxlQUFlO0NBd0JwQiIsImZpbGUiOiJEaXNjb3JkSW50ZWdyYXRpb24uanMiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUT0RPIGRpc2NvcmQtaW50ZWdyYXRpb24jMzQ6IFRocm93biBvbiBIb29rcy5vbigpLCBjYXVzZSBhbmQgZml4IHVua25vd25cclxuLyogZXNsaW50LWRpc2FibGUgQHR5cGVzY3JpcHQtZXNsaW50L25vLXVuc2FmZS1jYWxsICovXHJcblxyXG5pbXBvcnQgeyBBY3RvckRhdGEgfSBmcm9tIFwiQGxlYWd1ZS1vZi1mb3VuZHJ5LWRldmVsb3BlcnMvZm91bmRyeS12dHQtdHlwZXMvc3JjL2ZvdW5kcnkvY29tbW9uL2RhdGEvZGF0YS5tanMvYWN0b3JEYXRhXCI7XHJcblxyXG5sZXQgZ2FtZVVzZXJzOiBTdG9yZWREb2N1bWVudDxVc2VyPltdO1xyXG5sZXQgZm91bmRyeUdhbWU6IEdhbWU7XHJcblxyXG4vLyBEaXNjb3JkIHVzZXItaWRzIGFyZSBlaXRoZXIgMTcgb3IgMTggZGlnaXRzLlxyXG5jb25zdCBESVNDT1JEX01BWF9JRF9MRU5HVEggPSAxODtcclxuY29uc3QgRElTQ09SRF9NSU5fSURfTEVOR1RIID0gMTc7XHJcblxyXG4vLyBFbGVtZW50IElEc1xyXG5jb25zdCBUT0tFTl9DT05UUk9MU19UT0dHTEVfQlVUVE9OID0gJyNjb250cm9scyA+IG9sLnN1Yi1jb250cm9scy5hcHAuY29udHJvbC10b29scy5mbGV4Y29sLmFjdGl2ZSA+IGxpW2RhdGEtdG9vbD1cImRpc2NvcmQtaW50ZWdyYXRpb24tdG9nZ2xlXCJdJztcclxuXHJcbi8qKlxyXG4gKiBSZXR1cm5zIHRoZSBnYW1lIG9iamVjdC5cclxuICovXHJcbmZ1bmN0aW9uIGdldEdhbWUoKTogR2FtZSB7XHJcbiAgcmV0dXJuIGdhbWU7XHJcbn1cclxuXHJcbkhvb2tzLm9uY2UoXCJyZWFkeVwiLCBmdW5jdGlvbigpIHtcclxuICBnYW1lVXNlcnMgPSAoZ2FtZS51c2VycykuY29udGVudHM7XHJcbn0pO1xyXG5cclxuSG9va3Mub25jZShcImluaXRcIiwgZnVuY3Rpb24oKSB7XHJcbiAgZm91bmRyeUdhbWUgPSBnZXRHYW1lKCk7XHJcbiAgLy8gQWRkIHNldHRpbmdzIG9wdGlvbiBmb3IgVVJMIG9mIERpc2NvcmQgV2ViaG9va1xyXG4gIGZvdW5kcnlHYW1lLnNldHRpbmdzLnJlZ2lzdGVyKFwiZGlzY29yZC1pbnRlZ3JhdGlvblwiLCBcImRpc2NvcmRXZWJob29rXCIsIHtcclxuICAgIG5hbWU6IGZvdW5kcnlHYW1lLmkxOG4ubG9jYWxpemUoXCJESVNDT1JESU5URUdSQVRJT04uU2V0dGluZ3NEaXNjb3JkV2ViaG9va1wiKSxcclxuICAgIGhpbnQ6IGZvdW5kcnlHYW1lLmkxOG4ubG9jYWxpemUoXCJESVNDT1JESU5URUdSQVRJT04uU2V0dGluZ3NEaXNjb3JkV2ViaG9va0hpbnRcIiksXHJcbiAgICBzY29wZTogXCJ3b3JsZFwiLFxyXG4gICAgY29uZmlnOiB0cnVlLFxyXG4gICAgdHlwZTogU3RyaW5nLFxyXG4gICAgZGVmYXVsdDogXCJcIlxyXG4gIH0pO1xyXG4gIC8vIEFkZCBzZXR0aW5ncyBvcHRpb24gZm9yIHBpbmdpbmcgYnkgb24gY2hhcmFjdGVyIG5hbWVcclxuICBmb3VuZHJ5R2FtZS5zZXR0aW5ncy5yZWdpc3RlcihcImRpc2NvcmQtaW50ZWdyYXRpb25cIiwgXCJwaW5nQnlDaGFyYWN0ZXJOYW1lXCIsIHtcclxuICAgIG5hbWU6IGZvdW5kcnlHYW1lLmkxOG4ubG9jYWxpemUoXCJESVNDT1JESU5URUdSQVRJT04uU2V0dGluZ3NQaW5nQnlDaGFyYWN0ZXJOYW1lXCIpLFxyXG4gICAgaGludDogZm91bmRyeUdhbWUuaTE4bi5sb2NhbGl6ZShcIkRJU0NPUkRJTlRFR1JBVElPTi5TZXR0aW5nc1BpbmdCeUNoYXJhY3Rlck5hbWVIaW50XCIpLFxyXG4gICAgc2NvcGU6IFwid29ybGRcIixcclxuICAgIGNvbmZpZzogdHJ1ZSxcclxuICAgIGRlZmF1bHQ6IHRydWUsXHJcbiAgICB0eXBlOiBCb29sZWFuXHJcbiAgfSk7XHJcbiAgLy8gQWRkIHNldHRpbmdzIG9wdGlvbiBmb3IgcGluZ2luZyBieSB1c2VyIG5hbWVcclxuICBmb3VuZHJ5R2FtZS5zZXR0aW5ncy5yZWdpc3RlcihcImRpc2NvcmQtaW50ZWdyYXRpb25cIiwgXCJwaW5nQnlVc2VyTmFtZVwiLCB7XHJcbiAgICBuYW1lOiBmb3VuZHJ5R2FtZS5pMThuLmxvY2FsaXplKFwiRElTQ09SRElOVEVHUkFUSU9OLlNldHRpbmdzUGluZ0J5VXNlck5hbWVcIiksXHJcbiAgICBoaW50OiBmb3VuZHJ5R2FtZS5pMThuLmxvY2FsaXplKFwiRElTQ09SRElOVEVHUkFUSU9OLlNldHRpbmdzUGluZ0J5VXNlck5hbWVIaW50XCIpLFxyXG4gICAgc2NvcGU6IFwid29ybGRcIixcclxuICAgIGNvbmZpZzogdHJ1ZSxcclxuICAgIGRlZmF1bHQ6IHRydWUsXHJcbiAgICB0eXBlOiBCb29sZWFuXHJcblxyXG4gIH0pO1xyXG4gIC8vIEFkZCBzZXR0aW5ncyBvcHRpb24gZm9yIGZvcndhcmRpbmcgQUxMIG1lc3NhZ2VzIHZzLiBmb3J3YXJkaW5nIG9ubHkgbWVzc2FnZXMgd2l0aCBwaW5ncy5cclxuICBmb3VuZHJ5R2FtZS5zZXR0aW5ncy5yZWdpc3RlcihcImRpc2NvcmQtaW50ZWdyYXRpb25cIiwgXCJmb3J3YXJkQWxsTWVzc2FnZXNcIiwge1xyXG4gICAgbmFtZTogZm91bmRyeUdhbWUuaTE4bi5sb2NhbGl6ZShcIkRJU0NPUkRJTlRFR1JBVElPTi5TZXR0aW5nc0ZvcndhcmRBbGxNZXNzYWdlc1wiKSxcclxuICAgIGhpbnQ6IGZvdW5kcnlHYW1lLmkxOG4ubG9jYWxpemUoXCJESVNDT1JESU5URUdSQVRJT04uU2V0dGluZ3NGb3J3YXJkQWxsTWVzc2FnZXNIaW50XCIpLFxyXG4gICAgc2NvcGU6IFwid29ybGRcIixcclxuICAgIGNvbmZpZzogdHJ1ZSxcclxuICAgIGRlZmF1bHQ6IGZhbHNlLFxyXG4gICAgdHlwZTogQm9vbGVhblxyXG4gIH0pO1xyXG4gIC8vIEFkZCBzZXR0aW5ncyBvcHRpb24gZm9yIGFkZGluZyB0aGUgcGxheWVyJ3MgbmFtZSB0byB0aGUgZGlzY29yZCBtZXNzYWdlXHJcbiAgZm91bmRyeUdhbWUuc2V0dGluZ3MucmVnaXN0ZXIoXCJkaXNjb3JkLWludGVncmF0aW9uXCIsIFwicHJlcGVuZFVzZXJOYW1lXCIsIHtcclxuICAgIG5hbWU6IGZvdW5kcnlHYW1lLmkxOG4ubG9jYWxpemUoXCJESVNDT1JESU5URUdSQVRJT04uUHJlcGVuZFVzZXJOYW1lXCIpLFxyXG4gICAgaGludDogZm91bmRyeUdhbWUuaTE4bi5sb2NhbGl6ZShcIkRJU0NPUkRJTlRFR1JBVElPTi5QcmVwZW5kVXNlck5hbWVIaW50XCIpLFxyXG4gICAgc2NvcGU6IFwid29ybGRcIixcclxuICAgIGNvbmZpZzogdHJ1ZSxcclxuICAgIGRlZmF1bHQ6IGZhbHNlLFxyXG4gICAgdHlwZTogQm9vbGVhblxyXG4gIH0pO1xyXG4gIC8vIEFkZCBzZXR0aW5ncyBvcHRpb24gdG8gc2hvdy9oaWRlIHRvZ2dsZSBidXR0b24gaW4gdG9rZW5jb250cm9sc1xyXG4gIGZvdW5kcnlHYW1lLnNldHRpbmdzLnJlZ2lzdGVyKFwiZGlzY29yZC1pbnRlZ3JhdGlvblwiLCBcInRva2VuQ29udHJvbHNCdXR0b25cIiwge1xyXG4gICAgbmFtZTogZm91bmRyeUdhbWUuaTE4bi5sb2NhbGl6ZShcIkRJU0NPUkRJTlRFR1JBVElPTi5Ub2tlbkNvbnRyb2xzQnV0dG9uXCIpLFxyXG4gICAgaGludDogZm91bmRyeUdhbWUuaTE4bi5sb2NhbGl6ZShcIkRJU0NPUkRJTlRFR1JBVElPTi5Ub2tlbkNvbnRyb2xzQnV0dG9uSGludFwiKSxcclxuICAgIHNjb3BlOiBcIndvcmxkXCIsXHJcbiAgICBjb25maWc6IHRydWUsXHJcbiAgICBkZWZhdWx0OiBmYWxzZSxcclxuICAgIHR5cGU6IEJvb2xlYW5cclxuICB9KTtcclxuICAvKipcclxuICAgKiBQcm9wZXJ0eSBtYW5pcHVsYXRlZCBieSB0aGUgdG9rZW4gY29udHJvbHMgYnV0dG9uIHRvIHR1cm4gdGhlIG1vZCdzIGZ1bmN0aW9uYWxpdHkgb24vb2ZmIHdpdGhvdXQgZGlzYWJsaW5nIHRoZVxyXG4gICAqIGVudGlyZSBtb2QuXHJcbiAgICovXHJcbiAgZm91bmRyeUdhbWUuc2V0dGluZ3MucmVnaXN0ZXIoXCJkaXNjb3JkLWludGVncmF0aW9uXCIsIFwidG9rZW5Db250cm9sc0VuYWJsZWRcIiwge1xyXG4gICAgc2NvcGU6IFwid29ybGRcIixcclxuICAgIGNvbmZpZzogZmFsc2UsXHJcbiAgICBkZWZhdWx0OiB0cnVlLFxyXG4gICAgdHlwZTogQm9vbGVhblxyXG4gIH0pO1xyXG59KTtcclxuXHJcbi8vIEFkZCBidXR0b24gdG8gdG8gdGhlIHRva2VuIHN1Ym1lbnUgaW4gU2NlbmUgY29udHJvbHMgdG8gZW5hYmxlL2Rpc2FibGUgdGhlIG1vZC5cclxuSG9va3Mub24oXCJnZXRTY2VuZUNvbnRyb2xCdXR0b25zXCIsIGZ1bmN0aW9uKGNvbnRyb2xzOiBTY2VuZUNvbnRyb2xbXSkge1xyXG4gIC8vIEp1c3QgbGlrZSB0aGUgbW9kdWxlIHNldHRpbmdzLCBvbmx5IHRoZSBHTSBzaG91bGQgYmUgYWJsZSB0byB0b2dnbGUgdGhlIG1vZCBvbi9vZmYuXHJcbiAgaWYgKGdhbWUudXNlci5pc0dNICYmIGdhbWUuc2V0dGluZ3MuZ2V0KFwiZGlzY29yZC1pbnRlZ3JhdGlvblwiLCBcInRva2VuQ29udHJvbHNCdXR0b25cIikpIHtcclxuICAgIGNvbnRyb2xzLmZvckVhY2goKGNvbnRyb2w6IFNjZW5lQ29udHJvbCkgPT4ge1xyXG4gICAgICBpZiAoY29udHJvbC5uYW1lID09PSBcInRva2VuXCIpIHtcclxuICAgICAgICBjb25zdCB0b2tlbkNvbnRyb2xzQnV0dG9uID0ge1xyXG4gICAgICAgICAgbmFtZTogXCJkaXNjb3JkLWludGVncmF0aW9uLXRvZ2dsZVwiLFxyXG4gICAgICAgICAgdGl0bGU6IGZvdW5kcnlHYW1lLmkxOG4ubG9jYWxpemUoXCJESVNDT1JESU5URUdSQVRJT04uVG9rZW5Db250cm9sc0J1dHRvblRvb2x0aXBcIiksXHJcbiAgICAgICAgICBpY29uOiBcImZhYiBmYS1kaXNjb3JkXCIsXHJcbiAgICAgICAgICB0b2dnbGU6IHRydWUsXHJcbiAgICAgICAgICBhY3RpdmU6IGdhbWUuc2V0dGluZ3MuZ2V0KFwiZGlzY29yZC1pbnRlZ3JhdGlvblwiLCBcInRva2VuQ29udHJvbHNFbmFibGVkXCIpIGFzIGJvb2xlYW4sXHJcbiAgICAgICAgICBvbkNsaWNrOiB0b2dnbGVGb3J3YXJkaW5nXHJcbiAgICAgICAgfTtcclxuICAgICAgICBjb250cm9sLnRvb2xzLnB1c2godG9rZW5Db250cm9sc0J1dHRvbik7XHJcbiAgICAgIH1cclxuICAgICAgY29uc29sZS5sb2coY29udHJvbC5uYW1lKTtcclxuICAgIH0pO1xyXG4gIH1cclxufSk7XHJcblxyXG4vLyBBZGQgaW4gdGhlIGV4dHJhIGZpZWxkIGZvciBEaXNjb3JkSURcclxuSG9va3Mub24oXCJyZW5kZXJVc2VyQ29uZmlnXCIsIGFzeW5jIGZ1bmN0aW9uKGNvbmZpZzogVXNlckNvbmZpZywgZWxlbWVudDogSlF1ZXJ5KSB7XHJcblxyXG4gIC8vIEZpbmQgdGhlIHVzZXIgdGhhdCB5b3UncmUgb3BlbmluZyBjb25maWcgZm9yXHJcbiAgLy8gQHRzLWlnbm9yZSBBd2FpdGluZyBmb3VuZHJ5LXZ0dC10eXBlcyB1cGRhdGUgdG8gdXNlIGNvcnJlY3QgZGF0YSBzY2hlbWFcclxuICBjb25zdCBmb3VuZHJ5VXNlcjogU3RvcmVkRG9jdW1lbnQ8VXNlcj4gPSBnYW1lVXNlcnMuZmlsdGVyKCh1c2VyOiBVc2VyKSA9PiB7XHJcbiAgICAvLyBAdHMtaWdub3JlXHJcbiAgICByZXR1cm4gdXNlci5pZCA9PT0gKGNvbmZpZy5vYmplY3QpLl9pZDtcclxuICB9KVswXTtcclxuXHJcbiAgLy8gR2V0IHRoZWlyIERpc2NvcmQgSUQgaWYgaXQgZXhpc3RzXHJcbiAgbGV0IGRpc2NvcmRVc2VySWQ6IHN0cmluZyA9IGF3YWl0IGZvdW5kcnlVc2VyLmdldEZsYWcoXCJkaXNjb3JkLWludGVncmF0aW9uXCIsIFwiZGlzY29yZElEXCIpIGFzIHN0cmluZztcclxuICBkaXNjb3JkVXNlcklkID0gZGlzY29yZFVzZXJJZCA/IGRpc2NvcmRVc2VySWQgOiBcIlwiO1xyXG5cclxuICAvLyBDcmVhdGUgdGhlIGlucHV0IGZpZWxkIHRvIGNvbmZpZ3VyZSBpdC5cclxuICBjb25zdCBkaXNjb3JkSWRJbnB1dCA9IGA8aW5wdXQgdHlwZT1cInRleHRcIiBuYW1lPSdkaXNjb3JkLWlkLWNvbmZpZycgdmFsdWU9XCIke2Rpc2NvcmRVc2VySWR9XCIgZGF0YS1kdHlwZT1cIlN0cmluZ1wiPmA7XHJcblxyXG4gIGNvbnN0IGRpc2NvcmRJRFNldHRpbmcgPSBgXHJcbiAgICAgICAgPGRpdiBpZD1cImRpc2NvcmQtaWQtc2V0dGluZ1wiIGNsYXNzPVwiZm9ybS1ncm91cCBkaXNjb3JkXCI+XHJcbiAgICAgICAgICAgIDxsYWJlbD4ke2ZvdW5kcnlHYW1lLmkxOG4ubG9jYWxpemUoXCJESVNDT1JESU5URUdSQVRJT04uVXNlckRpc2NvcmRJZExhYmVsXCIpfTwvbGFiZWw+XHJcbiAgICAgICAgICAgICR7ZGlzY29yZElkSW5wdXR9XHJcbiAgICAgICAgPC9kaXY+YDtcclxuXHJcbiAgLy8gUHV0IHRoZSBpbnB1dCBmaWVsZHMgYmVsb3cgdGhlIFwiUGxheWVyIENvbG9yIGdyb3VwXCIgZmllbGQuXHJcbiAgY29uc3QgcGxheWVyQ29sb3JHcm91cCA9IGVsZW1lbnQuZmluZChcIi5mb3JtLWdyb3VwXCIpLmVxKDIpO1xyXG4gIHBsYXllckNvbG9yR3JvdXAuYWZ0ZXIoWyQoZGlzY29yZElEU2V0dGluZyldKTtcclxuXHJcbiAgaWYgKGZvdW5kcnlVc2VyLmlzR00pIHtcclxuICAgIC8qXHJcbiAgICAgICAgLy8gZ2V0IHRoZWlyIEdNIE5vdGlmaWNhdGlvbiBzdGF0dXMgaWYgaXQgZXhpc3RzLCBkZWZhdWx0aW5nIHRvIHRydWUuXHJcbiAgICAgICAgY29uc3Qgc2VuZEdNTm90aWZpY2F0aW9uczogYm9vbGVhbiA9IGF3YWl0IGZvdW5kcnlVc2VyLmdldEZsYWcoJ2Rpc2NvcmQtaW50ZWdyYXRpb24nLCAnc2VuZEdNTm90aWZpY2F0aW9ucycpXHJcbiAgICAgICAgICBhcyBib29sZWFuO1xyXG5cclxuICAgICAgICBjb25zdCBpc0NoZWNrZWQgPSBzZW5kR01Ob3RpZmljYXRpb25zID8gXCJjaGVja2VkXCIgOiBcIlwiO1xyXG4gICAgICAgIGNvbnN0IGdtTm90aWZpY2F0aW9uQ2hlY2tib3ggPSBgPGlucHV0IHR5cGU9XCJjaGVja2JveFwiIG5hbWU9XCJnbS1ub3RpZmljYXRpb24tY29uZmlnXCIgJHtpc0NoZWNrZWR9PmBcclxuXHJcbiAgICAgICAgY29uc3QgZ21Ob3RpZmljYXRpb25TZXR0aW5nID0gYFxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsPiR7Z2FtZS5pMThuLmxvY2FsaXplKFwiRElTQ09SRElOVEVHUkFUSU9OLkdNTm90aWZpY2F0aW9uc0xhYmVsXCIpIGFzIHN0cmluZ308L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgJHtnbU5vdGlmaWNhdGlvbkNoZWNrYm94fVxyXG4gICAgICAgICAgICA8L2Rpdj5gXHJcbiAgICAgICAgKi9cclxuICB9XHJcbn0pO1xyXG5cclxuLy8gQ29tbWl0IGFueSBjaGFuZ2VzIHRvIHVzZXJDb25maWdcclxuSG9va3Mub24oXCJjbG9zZVVzZXJDb25maWdcIiwgYXN5bmMgZnVuY3Rpb24oY29uZmlnOiBVc2VyQ29uZmlnLCBlbGVtZW50OiBKUXVlcnkpIHtcclxuICAvLyBGaW5kIHRoZSB1c2VyIHRoYXQgdGhlIGNvbmZpZyB3YXMgb3BlbiBmb3JcclxuICAvLyBAdHMtaWdub3JlIEF3YWl0aW5nIGZvdW5kcnktdnR0LXR5cGVzIHVwZGF0ZSB0byB1c2UgY29ycmVjdCBkYXRhIHNjaGVtYVxyXG4gIGNvbnN0IGZvdW5kcnlVc2VyOiBTdG9yZWREb2N1bWVudDxVc2VyPiA9IGdhbWVVc2Vycy5maWx0ZXIodXNlciA9PiB7IHJldHVybiB1c2VyLmlkID09PSAoY29uZmlnLm9iamVjdCkuX2lkOyB9KVswXTtcclxuICBjb25zdCBkaXNjb3JkSUQ6IHN0cmluZyA9IChlbGVtZW50LmZpbmQoXCJpbnB1dFtuYW1lID0gJ2Rpc2NvcmQtaWQtY29uZmlnJ11cIilbMF0gYXMgSFRNTElucHV0RWxlbWVudCkudmFsdWU7XHJcblxyXG4gIGlmIChkaXNjb3JkSUQubGVuZ3RoID4gRElTQ09SRF9NQVhfSURfTEVOR1RIXHJcbiAgICB8fCBkaXNjb3JkSUQubGVuZ3RoIDwgRElTQ09SRF9NSU5fSURfTEVOR1RIXHJcbiAgICB8fCBpc05hTihwYXJzZUludChkaXNjb3JkSUQpKSlcclxuICB7XHJcbiAgICB1aS5ub3RpZmljYXRpb25zLmVycm9yKGZvdW5kcnlHYW1lLmkxOG4ubG9jYWxpemUoXCJESVNDT1JESU5URUdSQVRJT04uSW52YWxpZElkRXJyb3JcIikpO1xyXG4gIH0gZWxzZSB7XHJcbiAgICBhd2FpdCBmb3VuZHJ5VXNlci51cGRhdGUoeyBcImZsYWdzLmRpc2NvcmQtaW50ZWdyYXRpb24uZGlzY29yZElEXCI6IGRpc2NvcmRJRCB9KTtcclxuICB9XHJcbiAgLypcclxuICAgIENvbnN0IGdtTm90aWZpY2F0aW9uRWxlbWVudCA9IGVsZW1lbnQuZmluZChcImlucHV0W25hbWUgPSAnZ20tbm90aWZpY2F0aW9uLWNvbmZpZyddXCIpO1xyXG4gICAgbGV0IGdtTm90aWZpY2F0aW9uczogYm9vbGVhblxyXG4gICAgaWYgKGdtTm90aWZpY2F0aW9uRWxlbWVudCAmJiBnbU5vdGlmaWNhdGlvbkVsZW1lbnRbMF0pIHtcclxuICAgICAgICBnbU5vdGlmaWNhdGlvbnMgPSAoZWxlbWVudC5maW5kKFwiaW5wdXRbbmFtZSA9ICdnbS1ub3RpZmljYXRpb24tY29uZmlnJ11cIilbMF0gYXMgSFRNTElucHV0RWxlbWVudCkuY2hlY2tlZDtcclxuICAgIH1cclxuICAgICovXHJcbiAgLy8gdXBkYXRlIHRoZSBmbGFnXHJcbiAgLy8gYXdhaXQgZm91bmRyeVVzZXIudXBkYXRlKHsgJ2ZsYWdzLmRpc2NvcmQtaW50ZWdyYXRpb24uc2VuZEdNTm90aWZpY2F0aW9ucyc6IGdtTm90aWZpY2F0aW9ucyB9KTtcclxufSk7XHJcblxyXG4vKipcclxuICogVG8gZm9yd2FyZCBhIG1lc3NhZ2UgdG8gZGlzY29yZCwgZG8gb25lIG9mIHR3byB0aGluZ3M6XHJcbiAqXHJcbiAqIC1pbmNsdWRlIFwiQDx1c2VybmFtZT5cIiBmb3IgYSB1c2VyIGluIHRoZSBnYW1lLCBpdCB3aWxsIHRoZW4gbG9vayB1cCB0aGUgY29ycmVzcG9uZGluZyBkaXNjb3JkSURcclxuICogYW5kIHNlbmQgYSBtZXNzYWdlIHBpbmdpbmcgdGhlbS4gSWYgeW91IEAgbXVsdGlwbGUgcGVvcGxlLCBpdCB3aWxsIHBpbmcgYWxsIG9mIHRoZW0uIFdpbGwgbm90XHJcbiAqIHNlbmQgYSBtZXNzYWdlIHVubGVzcyB0aGUgdXNlcm5hbWUgbWF0Y2hlcyB1cCB3aXRoIGFuIGFjdHVhbCB1c2VyLlxyXG4gKlxyXG4gKiAtaW5jbHVkZSBcIkBEaXNjb3JkXCIsIHdoaWNoIHdpbGwgdW5jb25kaXRpb25hbGx5IGZvcndhcmQgdGhlIG1lc3NhZ2UgKG1pbnVzIHRoZSBARGlzY29yZCkgdG8gdGhlIERpc2NvcmQgV2ViaG9vay5cclxuICovXHJcblxyXG4vLyB3aGVuZXZlciBzb21lb25lIHNlbmRzIGEgY2hhdCBtZXNzYWdlLCBpZiBpdCBpcyBtYXJrZWQgdXAgcHJvcGVybHkgZm9yd2FyZCBpdCB0byBEaXNjb3JkLlxyXG5Ib29rcy5vbihcImNoYXRNZXNzYWdlXCIsIGZ1bmN0aW9uKF9jaGF0TG9nOiBDaGF0TG9nLCBtZXNzYWdlOiBzdHJpbmcsIG1lc3NhZ2VEYXRhOiBDaGF0TWVzc2FnZURhdGEpIHtcclxuICBjb25zdCBkaXNjb3JkVGFnczogc3RyaW5nW10gPSBbXTtcclxuICBkaXNjb3JkVGFncy5wdXNoKFwiQERpc2NvcmRcIik7XHJcblxyXG4gIGxldCBzaG91bGRTZW5kTWVzc2FnZSA9IGZhbHNlO1xyXG4gIC8vIElmIHRoZSB0b2dnbGUgYnV0dG9uIGlzIHR1cm5lZCBvZmYsIHdlIGlnbm9yZSB0aGUgdmFsdWUgb2YgdG9rZW5Db250cm9sc0VuYWJsZWQuXHJcbiAgLy8gVGhpcyBpcyB0byBhdm9pZCBhIHNpdHVhdGlvbiB3aGVyZSB0aGUgbGFzdCBzZXR0aW5nIG9mIHRoZSBidXR0b24gd2FzIHRvIFwiZGlzYWJsZWRcIiBhbmQgdGhlIGJ1dHRvbiBpcyBkaXNhYmxlZCxcclxuICAvLyBtYWtpbmcgaXQgdW5jbGVhciB3aHkgbWVzc2FnZXMgd2lsbCBub3Qgc2VuZC5cclxuICBpZiAoZ2FtZS5zZXR0aW5ncy5nZXQoXCJkaXNjb3JkLWludGVncmF0aW9uXCIsIFwidG9rZW5Db250cm9sc0J1dHRvblwiKSAmJiAhZ2FtZS5zZXR0aW5ncy5nZXQoXCJkaXNjb3JkLWludGVncmF0aW9uXCIsIFwidG9rZW5Db250cm9sc0VuYWJsZWRcIikpIHtcclxuICAgIHNob3VsZFNlbmRNZXNzYWdlID0gZmFsc2U7XHJcbiAgfSBlbHNlIGlmIChnYW1lLnNldHRpbmdzLmdldChcImRpc2NvcmQtaW50ZWdyYXRpb25cIiwgXCJmb3J3YXJkQWxsTWVzc2FnZXNcIikpIHtcclxuICAgIHNob3VsZFNlbmRNZXNzYWdlID0gdHJ1ZTtcclxuICB9IGVsc2Uge1xyXG4gICAgZ2FtZVVzZXJzLmZvckVhY2goKHVzZXI6IFVzZXIpID0+IHtcclxuICAgICAgaWYgKGdhbWUuc2V0dGluZ3MuZ2V0KFwiZGlzY29yZC1pbnRlZ3JhdGlvblwiLCBcInBpbmdCeVVzZXJOYW1lXCIpKSB7XHJcbiAgICAgICAgZGlzY29yZFRhZ3MucHVzaChgQCR7dXNlci5uYW1lfWApO1xyXG4gICAgICB9XHJcbiAgICAgIGlmIChnYW1lLnNldHRpbmdzLmdldChcImRpc2NvcmQtaW50ZWdyYXRpb25cIiwgXCJwaW5nQnlDaGFyYWN0ZXJOYW1lXCIpICYmIHVzZXIuY2hhcmFjdGVyKSB7XHJcbiAgICAgICAgZGlzY29yZFRhZ3MucHVzaChgQCR7KHVzZXIuY2hhcmFjdGVyIGFzIEFjdG9yRGF0YSkubmFtZX1gKTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgICBkaXNjb3JkVGFncy5mb3JFYWNoKHRhZyA9PiB7XHJcbiAgICAgIGlmIChtZXNzYWdlLmluY2x1ZGVzKHRhZykpIHtcclxuICAgICAgICBzaG91bGRTZW5kTWVzc2FnZSA9IHRydWU7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gIH1cclxuICBpZiAoc2hvdWxkU2VuZE1lc3NhZ2UpIHtcclxuICAgIC8vIElmIHdlIGFyZSBhcHBlbmRpbmcgdGhlIHNlbmRlcidzIG5hbWUgdG8gdGhlIG1lc3NhZ2UsIHdlIGRvIHNvIGhlcmUuXHJcbiAgICBpZiAoZ2FtZS5zZXR0aW5ncy5nZXQoXCJkaXNjb3JkLWludGVncmF0aW9uXCIsIFwicHJlcGVuZFVzZXJOYW1lXCIpKSB7XHJcbiAgICAgIGNvbnN0IG1lc3NhZ2VTZW5kZXJJZCA9IG1lc3NhZ2VEYXRhLnVzZXI7XHJcbiAgICAgIGNvbnN0IG1lc3NhZ2VTZW5kZXIgPSBnYW1lVXNlcnMuZmluZCh1c2VyID0+IHVzZXIuaWQgPT09IG1lc3NhZ2VTZW5kZXJJZCk7XHJcbiAgICAgIG1lc3NhZ2UgPSBgJHttZXNzYWdlU2VuZGVyLm5hbWV9OiAke21lc3NhZ2V9YDtcclxuICAgIH1cclxuICAgIEhvb2tzLmNhbGxBbGwoXCJzZW5kRGlzY29yZE1lc3NhZ2VcIiwgbWVzc2FnZSk7XHJcbiAgfSBlbHNlIHtcclxuICAgIC8qKlxyXG4gICAgICogVE9ETyBkaXNjb3JkLWludGVncmF0aW9uIzM1OiBUaGlzIGV4aXN0cyBhcyBhIHdheSB0byB0ZXN0IHdoZW4gYSBtZXNzYWdlIGlzIG5vdCBzZW50LlxyXG4gICAgICogRmlndXJlIG91dCBhIHdheSB0byBkbyBpdCB3aXRob3V0IG1vZGlmeWluZyB0aGUgY29kZSBsYXRlci5cclxuICAgICAqL1xyXG4gICAgY29uc29sZS5sb2coXCJNZXNzYWdlIG5vdCBzZW50LlwiKTtcclxuICB9XHJcblxyXG59KTtcclxuXHJcbkhvb2tzLm9uKFwic2VuZERpc2NvcmRNZXNzYWdlXCIsIGZ1bmN0aW9uKG1lc3NhZ2U6IHN0cmluZykge1xyXG4gIHNlbmREaXNjb3JkTWVzc2FnZShtZXNzYWdlKS5jYXRjaChyZWFzb24gPT4ge1xyXG4gICAgY29uc29sZS5lcnJvcihyZWFzb24pO1xyXG4gIH0pO1xyXG59KTtcclxuXHJcbi8qKlxyXG4gKiBMaXN0ZW5lciBmdW5jdGlvbiBmb3IgdGhlIGJ1dHRvbiBpbiB0aGUgVG9rZW4gU2V0dGluZ3MgbWVudSB0byB0b2dnbGUgZm9yd2FyZGluZyBvZiBtZXNzYWdlcyB0byBEaXNjb3JkLlxyXG4gKi9cclxuYXN5bmMgZnVuY3Rpb24gdG9nZ2xlRm9yd2FyZGluZygpIHtcclxuICBjb25zdCBuZXdTZXR0aW5nVmFsdWUgPSAhZ2FtZS5zZXR0aW5ncy5nZXQoXCJkaXNjb3JkLWludGVncmF0aW9uXCIsIFwidG9rZW5Db250cm9sc0VuYWJsZWRcIik7XHJcbiAgYXdhaXQgZ2FtZS5zZXR0aW5ncy5zZXQoXCJkaXNjb3JkLWludGVncmF0aW9uXCIsIFwidG9rZW5Db250cm9sc0VuYWJsZWRcIiwgbmV3U2V0dGluZ1ZhbHVlKTtcclxuICBuZXdTZXR0aW5nVmFsdWU/ICQoVE9LRU5fQ09OVFJPTFNfVE9HR0xFX0JVVFRPTikuYWRkQ2xhc3MoXCJhY3RpdmVcIikgOiAkKFRPS0VOX0NPTlRST0xTX1RPR0dMRV9CVVRUT04pLnJlbW92ZUNsYXNzKFwiYWN0aXZlXCIpO1xyXG59XHJcblxyXG4vKipcclxuICogU2VuZHMgYSBtZXNzYWdlIHRocm91Z2ggdGhlIGRpc2NvcmQgd2ViaG9vayBhcyBjb25maWd1cmVkIGluIHNldHRpbmdzLlxyXG4gKlxyXG4gKiBNZXNzYWdlcyB0aGF0IHBpbmcgdXNlcnMgaW4gRGlzY29yZCBuZWVkIHRvIGhhdmUgXCJAPGdhbWVVc2VyTmFtZT5cIlxyXG4gKiBhbmQgdGhlIHVzZXJzIG11c3QgaGF2ZSB0aGVpciBkaXNjb3JkIElEcyBjb25maWd1cmVkLlxyXG4gKlxyXG4gKiBAcGFyYW0gbWVzc2FnZSBUaGUgbWVzc2FnZSB0byBmb3J3YXJkIHRvIERpc2NvcmRcclxuICovXHJcbmFzeW5jIGZ1bmN0aW9uIHNlbmREaXNjb3JkTWVzc2FnZShtZXNzYWdlOiBzdHJpbmcpIHtcclxuXHJcbiAgbGV0IHNlbmRNZXNzYWdlID0gdHJ1ZTtcclxuXHJcbiAgY29uc3QgZGlzY29yZFdlYmhvb2sgPSBnYW1lLnNldHRpbmdzLmdldChcImRpc2NvcmQtaW50ZWdyYXRpb25cIiwgXCJkaXNjb3JkV2ViaG9va1wiKSBhcyBzdHJpbmc7XHJcbiAgaWYgKCFkaXNjb3JkV2ViaG9vaykge1xyXG4gICAgdWkubm90aWZpY2F0aW9ucy5lcnJvcihcclxuICAgICAgZm91bmRyeUdhbWUuaTE4bi5sb2NhbGl6ZShcIkRJU0NPUkRJTlRFR1JBVElPTi5Db3VsZE5vdFNlbmRNZXNzYWdlXCIpXHJcbiAgICAgICAgICAgICsgZm91bmRyeUdhbWUuaTE4bi5sb2NhbGl6ZShcIkRJU0NPUkRJTlRFR1JBVElPTi5Ob0Rpc2NvcmRXZWJob29rRXJyb3JcIikpO1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuXHJcbiAgY29uc3QgdXNlcnNUb0NoYXJzOiBNYXA8c3RyaW5nLCBzdHJpbmc+ID0gbmV3IE1hcDxzdHJpbmcsIHN0cmluZz4oKTtcclxuXHJcbiAgY29uc3QgdXNlcnNUb1Bpbmc6IHN0cmluZ1tdID0gW107XHJcblxyXG4gIGdhbWVVc2Vycy5mb3JFYWNoKCh1c2VyOiBVc2VyKSA9PiB7XHJcbiAgICBpZiAobWVzc2FnZS5pbmRleE9mKGBAJHt1c2VyLm5hbWV9YCkgIT09IC0xKSB7XHJcbiAgICAgIHVzZXJzVG9QaW5nLnB1c2godXNlci5uYW1lKTtcclxuICAgIH1cclxuICAgIGlmICh1c2VyLmNoYXJhY3Rlcikge1xyXG4gICAgICB1c2Vyc1RvQ2hhcnMuc2V0KHVzZXIubmFtZSwgKCh1c2VyLmNoYXJhY3RlciBhcyBBY3RvckRhdGEpLm5hbWUpKTtcclxuICAgIH1cclxuICB9KTtcclxuXHJcbiAgdXNlcnNUb0NoYXJzLmZvckVhY2goKGNoYXJOYW1lOiBzdHJpbmcsIHVzZXJOYW1lOiBzdHJpbmcsIF9tYXApID0+IHtcclxuICAgIC8vIFBpbmcgaWYgYSB1c2VyIG9yIHRoZWlyIGNoYXJhY3RlcidzIG5hbWUgaXMgdGFnZ2VkXHJcbiAgICBpZiAobWVzc2FnZS5pbmRleE9mKGBAJHtjaGFyTmFtZX1gKSAhPT0gLTEpIHtcclxuICAgICAgdXNlcnNUb1BpbmcucHVzaCh1c2VyTmFtZSk7XHJcbiAgICB9XHJcbiAgfSk7XHJcblxyXG4gIC8vIFNlYXJjaCBmb3IgQERpc2NvcmQgaW4gdGhlIG1lc3NhZ2VcclxuICBjb25zdCBzaG91bGRQaW5nRGlzY29yZDogYm9vbGVhbiA9IChtZXNzYWdlLnNlYXJjaChcIkBEaXNjb3JkXCIpICE9PSAtMSk7XHJcblxyXG4gIC8qKlxyXG4gICAqIElmIGl0IGZvdW5kIGFueSBAPHVzZXJuYW1lPiB2YWx1ZXMsIHJlcGxhY2UgdGhlIHZhbHVlcyBpbiB0aGUgbWVzc2FnZSB3aXRoIGFwcHJvcHJpYXRlIGRpc2NvcmQgcGluZ3MsXHJcbiAgICogdGhlbiBzZW5kIGRpc2NvcmQgbWVzc2FnZS5cclxuICAgKi9cclxuICBpZiAodXNlcnNUb1BpbmcubGVuZ3RoICE9PSAwKSB7XHJcbiAgICB1c2Vyc1RvUGluZy5mb3JFYWNoKCh1c2VyTmFtZTogc3RyaW5nKSA9PiB7XHJcbiAgICAgIGNvbnN0IGN1cnJlbnRVc2VyOiBVc2VyIHwgdW5kZWZpbmVkID0gZ2FtZVVzZXJzLmZpbHRlcigodXNlcjogVXNlcikgPT4ge1xyXG4gICAgICAgIHJldHVybiB1c2VyLmRhdGEubmFtZSA9PT0gdXNlck5hbWU7XHJcbiAgICAgIH0pWzBdO1xyXG4gICAgICBpZiAoY3VycmVudFVzZXIpIHtcclxuICAgICAgICBjb25zdCBjdXJyZW50VXNlckRpc2NvcmRJRDogc3RyaW5nID0gY3VycmVudFVzZXIuZ2V0RmxhZyhcImRpc2NvcmQtaW50ZWdyYXRpb25cIiwgXCJkaXNjb3JkSURcIikgYXMgc3RyaW5nO1xyXG4gICAgICAgIGlmICghY3VycmVudFVzZXJEaXNjb3JkSUQpIHtcclxuICAgICAgICAgIHVpLm5vdGlmaWNhdGlvbnMuZXJyb3IoXHJcbiAgICAgICAgICAgIGZvdW5kcnlHYW1lLmkxOG4ubG9jYWxpemUoXCJESVNDT1JESU5URUdSQVRJT04uQ291bGROb3RTZW5kTWVzc2FnZVwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICArIGN1cnJlbnRVc2VyLm5hbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgKyBmb3VuZHJ5R2FtZS5pMThuLmxvY2FsaXplKFwiRElTQ09SRElOVEVHUkFUSU9OLlVzZXJIYXNOb0lkRXJyb3JcIikpO1xyXG4gICAgICAgICAgc2VuZE1lc3NhZ2UgPSBmYWxzZTtcclxuICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgbWVzc2FnZSA9IG1lc3NhZ2UucmVwbGFjZShgQCR7dXNlck5hbWV9YCwgYDxAJHtjdXJyZW50VXNlckRpc2NvcmRJRH0+YCk7XHJcbiAgICAgICAgbWVzc2FnZSA9IG1lc3NhZ2UucmVwbGFjZShgQCR7dXNlcnNUb0NoYXJzLmdldCh1c2VyTmFtZSl9YCwgYDxAJHtjdXJyZW50VXNlckRpc2NvcmRJRH0+YCk7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gICAgLy8gRWxzZSBpZiBEaXNjb3JkIGFzIGEgd2hvbGUgaXMgYmVpbmcgcGluZ2VkLCByZW1vdmUgdGhlIFwiQERpc2NvcmRcIiBwYXJ0IGFuZCB0aGVuIHNlbmQgdGhlIG1lc3NhZ2UuXHJcbiAgfSBlbHNlIGlmIChzaG91bGRQaW5nRGlzY29yZCkge1xyXG4gICAgbWVzc2FnZSA9IG1lc3NhZ2UucmVwbGFjZShcIkBEaXNjb3JkIFwiLCBcIlwiKSB8fCBcIlwiO1xyXG4gIH1cclxuXHJcbiAgY29uc3QgbWVzc2FnZUpTT04gPSB7XHJcbiAgICBjb250ZW50OiBtZXNzYWdlXHJcbiAgfTtcclxuXHJcbiAgbGV0IGpzb25NZXNzYWdlOiBzdHJpbmc7XHJcbiAgdHJ5IHtcclxuICAgIGpzb25NZXNzYWdlID0gSlNPTi5zdHJpbmdpZnkobWVzc2FnZUpTT04pO1xyXG4gIH0gY2F0Y2goZSkge1xyXG4gICAgdWkubm90aWZpY2F0aW9ucy5lcnJvcihcclxuICAgICAgZm91bmRyeUdhbWUuaTE4bi5sb2NhbGl6ZShcIkRJU0NPUkRJTlRFR1JBVElPTi5Db3VsZE5vdFNlbmRNZXNzYWdlXCIpXHJcbiAgICAgICAgICAgICsgZm91bmRyeUdhbWUuaTE4bi5sb2NhbGl6ZShcIkRJU0NPUkRJTlRFR1JBVElPTi5Db3VsZE5vdFN0cmluZ2lmeUpzb25FcnJvclwiKSk7XHJcbiAgICBzZW5kTWVzc2FnZSA9IGZhbHNlO1xyXG4gIH1cclxuXHJcbiAgaWYgKHNlbmRNZXNzYWdlKSB7XHJcbiAgICBhd2FpdCAkLmFqYXgoe1xyXG4gICAgICBtZXRob2Q6IFwiUE9TVFwiLFxyXG4gICAgICB1cmw6IGRpc2NvcmRXZWJob29rLFxyXG4gICAgICBjb250ZW50VHlwZTogXCJhcHBsaWNhdGlvbi9qc29uXCIsXHJcbiAgICAgIGRhdGE6IGpzb25NZXNzYWdlXHJcbiAgICB9KTtcclxuICB9XHJcbn1cclxuXHJcbmNsYXNzIENoYXRNZXNzYWdlRGF0YSB7XHJcbiAgICBibGluZDogYm9vbGVhbjtcclxuXHJcbiAgICBjb250ZW50OiBzdHJpbmc7XHJcblxyXG4gICAgZW1vdGU6IGJvb2xlYW47XHJcblxyXG4gICAgZmxhZ3M6IG9iamVjdDtcclxuXHJcbiAgICBmbGF2b3I6IGFueTsgLy8gTm90IHN1cmUgd2hhdCB0aGVzZSBcImFueVwiIGZpZWxkcyBhcmUgc3VwcG9zZWQgdG8gYmUgZmlsbGVkIHdpdGguIFNob3VsZG4ndCBiZSBpbXBvcnRhbnQgZm9yIERpc2NvcmQgSW50ZWdyYXRpb24gYXQgdGhlIHZlcnkgbGVhc3QuXHJcblxyXG4gICAgcm9sbDogYW55OyAvLyBOb3Qgc3VyZSB3aGF0IHRoZXNlIFwiYW55XCIgZmllbGRzIGFyZSBzdXBwb3NlZCB0byBiZSBmaWxsZWQgd2l0aC4gU2hvdWxkbid0IGJlIGltcG9ydGFudCBmb3IgRGlzY29yZCBJbnRlZ3JhdGlvbiBhdCB0aGUgdmVyeSBsZWFzdC5cclxuXHJcbiAgICBzb3VuZDogYW55OyAvLyBOb3Qgc3VyZSB3aGF0IHRoZXNlIFwiYW55XCIgZmllbGRzIGFyZSBzdXBwb3NlZCB0byBiZSBmaWxsZWQgd2l0aC4gU2hvdWxkbid0IGJlIGltcG9ydGFudCBmb3IgRGlzY29yZCBJbnRlZ3JhdGlvbiBhdCB0aGUgdmVyeSBsZWFzdC5cclxuXHJcbiAgICBzcGVha2VyOiBvYmplY3Q7XHJcblxyXG4gICAgdGltZXN0YW1wOiBudW1iZXI7XHJcblxyXG4gICAgdHlwZTogbnVtYmVyO1xyXG5cclxuICAgIHVzZXI6IHN0cmluZztcclxuXHJcbiAgICB3aGlzcGVyOiBhbnk7IC8vIE5vdCBzdXJlIHdoYXQgdGhlc2UgXCJhbnlcIiBmaWVsZHMgYXJlIHN1cHBvc2VkIHRvIGJlIGZpbGxlZCB3aXRoLiBTaG91bGRuJ3QgYmUgaW1wb3J0YW50IGZvciBEaXNjb3JkIEludGVncmF0aW9uIGF0IHRoZSB2ZXJ5IGxlYXN0LlxyXG59XHJcbiJdfQ==
