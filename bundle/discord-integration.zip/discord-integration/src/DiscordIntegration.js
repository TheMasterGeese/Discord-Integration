// TODO discord-integration#34: Thrown on Hooks.on(), cause and fix unknown
/* eslint-disable @typescript-eslint/no-unsafe-call */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
let gameUsers;
let foundryGame;
// Discord user-ids are always exactly 18 digits.
const DISCORD_ID_LENGTH = 18;
function getGame() {
    return game;
}
Hooks.once("ready", function () {
    gameUsers = (game.users).contents;
});
Hooks.once("init", function () {
    foundryGame = getGame();
    // add settings option for URL of Discord Webhook
    foundryGame.settings.register("discord-integration", "discordWebhook", {
        name: foundryGame.i18n.localize("DISCORDINTEGRATION.SettingsDiscordWebhook"),
        hint: foundryGame.i18n.localize("DISCORDINTEGRATION.SettingsDiscordWebhookHint"),
        scope: "world",
        config: true,
        type: String,
        default: "",
    });
    // add settings option for pinging by on character name
    foundryGame.settings.register("discord-integration", "pingByCharacterName", {
        name: foundryGame.i18n.localize("DISCORDINTEGRATION.SettingsPingByCharacterName"),
        hint: foundryGame.i18n.localize("DISCORDINTEGRATION.SettingsPingByCharacterNameHint"),
        scope: "world",
        config: true,
        default: true,
        type: Boolean
    });
    // add settings option for pinging by user name
    foundryGame.settings.register("discord-integration", "pingByUserName", {
        name: foundryGame.i18n.localize("DISCORDINTEGRATION.SettingsPingByUserName"),
        hint: foundryGame.i18n.localize("DISCORDINTEGRATION.SettingsPingByUserNameHint"),
        scope: "world",
        config: true,
        default: true,
        type: Boolean
    });
});
// add in the extra field for DiscordID
Hooks.on("renderUserConfig", function (config, element) {
    return __awaiter(this, void 0, void 0, function* () {
        // find the user that you're opening config for
        const foundryUser = foundryGame.users.contents.filter((user) => { return user.id === (config.object).data._id; })[0];
        // get their Discord ID if it exists
        let discordUserId = yield foundryUser.getFlag('discord-integration', 'discordID');
        discordUserId = discordUserId ? discordUserId : "";
        // create the input field to configure it.
        const discordIdInput = `<input type="text" name="discord-id-config" value="${discordUserId}" data-dtype="String">`;
        const discordIDSetting = `
        <div id="discord-id-setting" class="form-group discord">
            <label>${foundryGame.i18n.localize("DISCORDINTEGRATION.UserDiscordIdLabel")}</label>
            ${discordIdInput}
        </div>`;
        // Put the input fields below the "Player Color group" field.
        const playerColorGroup = element.find('.form-group').eq(2);
        playerColorGroup.after([$(discordIDSetting)]);
        if (foundryUser.isGM) {
            /*
            // get their GM Notification status if it exists, defaulting to true.
            const sendGMNotifications: boolean = await foundryUser.getFlag('discord-integration', 'sendGMNotifications') as boolean;
    
            
            const isChecked = sendGMNotifications ? "checked" : "";
            const gmNotificationCheckbox = `<input type="checkbox" name="gm-notification-config" ${isChecked}>`
    
            const gmNotificationSetting = `
                <div>
                    <label>${game.i18n.localize("DISCORDINTEGRATION.GMNotificationsLabel") as string}</label>
                    ${gmNotificationCheckbox}
                </div>`
            */
        }
    });
});
// commit any changes to userConfig
Hooks.on("closeUserConfig", function (config, element) {
    return __awaiter(this, void 0, void 0, function* () {
        // find the user that the config was open for
        const foundryUser = gameUsers.filter(user => { return user.id === (config.object).data._id; })[0];
        const discordID = element.find("input[name = 'discord-id-config']")[0].value;
        if (discordID.length !== DISCORD_ID_LENGTH || isNaN(parseInt(discordID))) {
            ui.notifications.error(foundryGame.i18n.localize("DISCORDINTEGRATION.InvalidIdError"));
        }
        else {
            yield foundryUser.update({ 'flags.discord-integration.discordID': discordID });
        }
        /*
        const gmNotificationElement = element.find("input[name = 'gm-notification-config']");
        let gmNotifications: boolean
        if (gmNotificationElement && gmNotificationElement[0]) {
            gmNotifications = (element.find("input[name = 'gm-notification-config']")[0] as HTMLInputElement).checked;
        }
        */
        // update the flag
        //await foundryUser.update({ 'flags.discord-integration.sendGMNotifications': gmNotifications });
    });
});
/**
 * To forward a message to discord, do one of two things:
 *
 * -include "@<username>" for a user in the game, it will then look up the corresponding discordID
 * and send a message pinging them. If you @ multiple people, it will ping all of them. Will not
 * send a message unless the username matches up with an actual user.
 *
 * -include "@Discord", which will unconditionally forward the message (minus the @Discord) to the Discord Webhook.
 */
// whenever someone sends a chat message, if it is marked up properly forward it to Discord.
Hooks.on("chatMessage", function (_chatLog, message) {
    const discordTags = [];
    discordTags.push("@Discord");
    foundryGame.users.forEach(user => {
        discordTags.push(`@${user.name}`);
        if (user.character) {
            discordTags.push(`@${user.character.name}`);
        }
    });
    let shouldSendMessage = false;
    discordTags.forEach(tag => {
        if (message.includes(tag)) {
            shouldSendMessage = true;
        }
    });
    if (shouldSendMessage) {
        Hooks.callAll("sendDiscordMessage", message);
    }
    else {
        // TODO discord-integration#35: This exists as a way to test when a message is not sent. Figure out a way to do it without modifying the code later.
        console.log("Message not sent.");
    }
});
Hooks.on("sendDiscordMessage", function (message) {
    sendDiscordMessage(message).catch((reason) => {
        console.error(reason);
    });
});
/**
 * Sends a message through the discord webhook as configured in settings.
 *
 * Messages that ping users in Discord need to have "@<gameUserName>" and the users must have their discord IDs configured.
 *
 * @param message The message to forward to Discord
 */
function sendDiscordMessage(message) {
    return __awaiter(this, void 0, void 0, function* () {
        let sendMessage = true;
        const discordWebhook = game.settings.get('discord-integration', 'discordWebhook');
        if (!discordWebhook) {
            ui.notifications.error(foundryGame.i18n.localize("DISCORDINTEGRATION.CouldNotSendMessage")
                + foundryGame.i18n.localize("DISCORDINTEGRATION.NoDiscordWebhookError"));
            return;
        }
        const usersToChars = new Map();
        const usersToPing = [];
        gameUsers.forEach((user) => {
            if (message.indexOf(`@${user.name}`) !== -1) {
                usersToPing.push(user.name);
            }
            if (user.character) {
                usersToChars.set(user.name, (user.character.name));
            }
        });
        usersToChars.forEach((charName, userName, _map) => {
            // Ping if a user or their character's name is tagged
            if (message.indexOf(`@${charName}`) !== -1) {
                usersToPing.push(userName);
            }
        });
        // search for @Discord in the message
        const shouldPingDiscord = (message.search(`@Discord`) !== -1);
        // if it found any @<username> values, replace the values in the message with appropriate discord pings, then send discord message.
        if (usersToPing.length !== 0) {
            usersToPing.forEach((userName) => {
                const currentUser = gameUsers.filter((user) => { return user.data.name === userName; })[0];
                if (currentUser) {
                    const currentUserDiscordID = currentUser.getFlag('discord-integration', 'discordID');
                    if (!currentUserDiscordID) {
                        ui.notifications.error(foundryGame.i18n.localize("DISCORDINTEGRATION.CouldNotSendMessage")
                            + currentUser.name
                            + foundryGame.i18n.localize("DISCORDINTEGRATION.UserHasNoIdError"));
                        sendMessage = false;
                        return;
                    }
                    console.log(message);
                    message = message.replace(`@${userName}`, `<@${currentUserDiscordID}>`);
                    message = message.replace(`@${usersToChars.get(userName)}`, `<@${currentUserDiscordID}>`);
                }
            });
            // else if Discord as a whole is being pinged, remove the "@Discord" part and then send the message.
        }
        else if (shouldPingDiscord) {
            message = message.split("@Discord").pop() || "";
        }
        const messageJSON = {
            "content": message
        };
        let jsonMessage;
        try {
            jsonMessage = JSON.stringify(messageJSON);
        }
        catch (e) {
            ui.notifications.error(foundryGame.i18n.localize("DISCORDINTEGRATION.CouldNotSendMessage")
                + foundryGame.i18n.localize("DISCORDINTEGRATION.CouldNotStringifyJsonError"));
            sendMessage = false;
        }
        if (sendMessage) {
            yield $.ajax({
                method: 'POST',
                url: discordWebhook,
                contentType: "application/json",
                data: jsonMessage
            });
        }
    });
}
export {};

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9EaXNjb3JkSW50ZWdyYXRpb24udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsMkVBQTJFO0FBQzNFLHNEQUFzRDs7Ozs7Ozs7OztBQUl0RCxJQUFJLFNBQWlDLENBQUE7QUFDckMsSUFBSSxXQUFpQixDQUFDO0FBRXRCLGlEQUFpRDtBQUNqRCxNQUFNLGlCQUFpQixHQUFHLEVBQUUsQ0FBQztBQUU3QixTQUFTLE9BQU87SUFDWixPQUFPLElBQUksQ0FBQztBQUNoQixDQUFDO0FBRUQsS0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUU7SUFDaEIsU0FBUyxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUN0QyxDQUFDLENBQUMsQ0FBQztBQUVILEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO0lBQ2YsV0FBVyxHQUFHLE9BQU8sRUFBRSxDQUFDO0lBQ3hCLGlEQUFpRDtJQUNqRCxXQUFXLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxxQkFBcUIsRUFBRSxnQkFBZ0IsRUFBRTtRQUNuRSxJQUFJLEVBQUUsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsMkNBQTJDLENBQUM7UUFDNUUsSUFBSSxFQUFFLFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLCtDQUErQyxDQUFDO1FBQ2hGLEtBQUssRUFBRSxPQUFPO1FBQ2QsTUFBTSxFQUFFLElBQUk7UUFDWixJQUFJLEVBQUUsTUFBTTtRQUNaLE9BQU8sRUFBRSxFQUFFO0tBQ2QsQ0FBQyxDQUFDO0lBQ0gsdURBQXVEO0lBQ3ZELFdBQVcsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLHFCQUFxQixFQUFFLHFCQUFxQixFQUFFO1FBQ3hFLElBQUksRUFBRSxXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxnREFBZ0QsQ0FBQztRQUNqRixJQUFJLEVBQUUsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsb0RBQW9ELENBQUM7UUFDckYsS0FBSyxFQUFFLE9BQU87UUFDZCxNQUFNLEVBQUUsSUFBSTtRQUNaLE9BQU8sRUFBRSxJQUFJO1FBQ2IsSUFBSSxFQUFFLE9BQU87S0FFaEIsQ0FBQyxDQUFDO0lBQ0gsK0NBQStDO0lBQy9DLFdBQVcsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLHFCQUFxQixFQUFFLGdCQUFnQixFQUFFO1FBQ25FLElBQUksRUFBRSxXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQywyQ0FBMkMsQ0FBQztRQUM1RSxJQUFJLEVBQUUsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsK0NBQStDLENBQUM7UUFDaEYsS0FBSyxFQUFFLE9BQU87UUFDZCxNQUFNLEVBQUUsSUFBSTtRQUNaLE9BQU8sRUFBRSxJQUFJO1FBQ2IsSUFBSSxFQUFFLE9BQU87S0FDaEIsQ0FBQyxDQUFDO0FBQ1AsQ0FBQyxDQUFDLENBQUM7QUFFSCx1Q0FBdUM7QUFDdkMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxrQkFBa0IsRUFBRSxVQUFnQixNQUFrQixFQUFFLE9BQWU7O1FBRTVFLCtDQUErQztRQUMvQyxNQUFNLFdBQVcsR0FBeUIsV0FBVyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBVSxFQUFFLEVBQUUsR0FBRyxPQUFPLElBQUksQ0FBQyxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRWhKLG9DQUFvQztRQUNwQyxJQUFJLGFBQWEsR0FBVyxNQUFNLFdBQVcsQ0FBQyxPQUFPLENBQUMscUJBQXFCLEVBQUUsV0FBVyxDQUFXLENBQUE7UUFDbkcsYUFBYSxHQUFHLGFBQWEsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUE7UUFFbEQsMENBQTBDO1FBQzFDLE1BQU0sY0FBYyxHQUFHLHNEQUFzRCxhQUFhLHdCQUF3QixDQUFBO1FBRWxILE1BQU0sZ0JBQWdCLEdBQUc7O3FCQUVSLFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLHVDQUF1QyxDQUFDO2NBQ3pFLGNBQWM7ZUFDYixDQUFBO1FBRVgsNkRBQTZEO1FBQzdELE1BQU0sZ0JBQWdCLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDM0QsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRTlDLElBQUksV0FBVyxDQUFDLElBQUksRUFBRTtZQUNsQjs7Ozs7Ozs7Ozs7OztjQWFFO1NBQ0w7SUFDTCxDQUFDO0NBQUEsQ0FBQyxDQUFDO0FBRUgsbUNBQW1DO0FBQ25DLEtBQUssQ0FBQyxFQUFFLENBQUMsaUJBQWlCLEVBQUUsVUFBZ0IsTUFBa0IsRUFBRSxPQUFlOztRQUMzRSw2Q0FBNkM7UUFDN0MsTUFBTSxXQUFXLEdBQXlCLFNBQVMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEVBQUUsR0FBRyxPQUFPLElBQUksQ0FBQyxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3ZILE1BQU0sU0FBUyxHQUFZLE9BQU8sQ0FBQyxJQUFJLENBQUMsbUNBQW1DLENBQUMsQ0FBQyxDQUFDLENBQXNCLENBQUMsS0FBSyxDQUFDO1FBRTNHLElBQUksU0FBUyxDQUFDLE1BQU0sS0FBSyxpQkFBaUIsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUU7WUFDdEUsRUFBRSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsbUNBQW1DLENBQUMsQ0FBQyxDQUFBO1NBQ3pGO2FBQU07WUFDSCxNQUFNLFdBQVcsQ0FBQyxNQUFNLENBQUMsRUFBRSxxQ0FBcUMsRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFDO1NBQ2xGO1FBQ0Q7Ozs7OztVQU1FO1FBQ0Ysa0JBQWtCO1FBQ2xCLGlHQUFpRztJQUNyRyxDQUFDO0NBQUEsQ0FBQyxDQUFDO0FBRUg7Ozs7Ozs7O0dBUUc7QUFFSCw0RkFBNEY7QUFDNUYsS0FBSyxDQUFDLEVBQUUsQ0FBQyxhQUFhLEVBQUUsVUFBVSxRQUFpQixFQUFFLE9BQWU7SUFDaEUsTUFBTSxXQUFXLEdBQWEsRUFBRSxDQUFDO0lBQ2pDLFdBQVcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7SUFFN0IsV0FBVyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUU7UUFDN0IsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFBO1FBQ2pDLElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNoQixXQUFXLENBQUMsSUFBSSxDQUFDLElBQUssSUFBSSxDQUFDLFNBQXVCLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQTtTQUM3RDtJQUNMLENBQUMsQ0FBQyxDQUFBO0lBRUYsSUFBSSxpQkFBaUIsR0FBRyxLQUFLLENBQUM7SUFDOUIsV0FBVyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRTtRQUN0QixJQUFJLE9BQU8sQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDdkIsaUJBQWlCLEdBQUcsSUFBSSxDQUFDO1NBQzVCO0lBQ0wsQ0FBQyxDQUFDLENBQUE7SUFFRixJQUFJLGlCQUFpQixFQUFFO1FBQ25CLEtBQUssQ0FBQyxPQUFPLENBQUMsb0JBQW9CLEVBQUUsT0FBTyxDQUFDLENBQUM7S0FDaEQ7U0FBTTtRQUNILG9KQUFvSjtRQUNwSixPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixDQUFDLENBQUE7S0FDbkM7QUFDTCxDQUFDLENBQUMsQ0FBQztBQUVILEtBQUssQ0FBQyxFQUFFLENBQUMsb0JBQW9CLEVBQUUsVUFBVSxPQUFlO0lBQ3BELGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sRUFBRSxFQUFFO1FBQ3pDLE9BQU8sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDMUIsQ0FBQyxDQUFDLENBQUM7QUFDUCxDQUFDLENBQUMsQ0FBQztBQUVIOzs7Ozs7R0FNRztBQUNILFNBQWUsa0JBQWtCLENBQUMsT0FBZTs7UUFFN0MsSUFBSSxXQUFXLEdBQUcsSUFBSSxDQUFDO1FBRXZCLE1BQU0sY0FBYyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLHFCQUFxQixFQUFFLGdCQUFnQixDQUFXLENBQUM7UUFDNUYsSUFBSSxDQUFDLGNBQWMsRUFBRTtZQUNqQixFQUFFLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FDbEIsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsd0NBQXdDLENBQUM7a0JBQ2pFLFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLDBDQUEwQyxDQUFDLENBQUMsQ0FBQTtZQUM1RSxPQUFPO1NBQ1Y7UUFFRCxNQUFNLFlBQVksR0FBd0IsSUFBSSxHQUFHLEVBQWtCLENBQUM7UUFFcEUsTUFBTSxXQUFXLEdBQWEsRUFBRSxDQUFDO1FBRWpDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFVLEVBQUUsRUFBRTtZQUM3QixJQUFJLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRTtnQkFDekMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDL0I7WUFDRCxJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUU7Z0JBQ2hCLFlBQVksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFFLElBQUksQ0FBQyxTQUF1QixDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7YUFDckU7UUFDTCxDQUFDLENBQUMsQ0FBQTtRQUVGLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFpQixFQUFFLFFBQWlCLEVBQUUsSUFBSSxFQUFFLEVBQUU7WUFDaEUscURBQXFEO1lBQ3JELElBQUksT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLFFBQVEsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUU7Z0JBQ3hDLFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7YUFDOUI7UUFDTCxDQUFDLENBQUMsQ0FBQTtRQUVGLHFDQUFxQztRQUNyQyxNQUFNLGlCQUFpQixHQUFZLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRXZFLG1JQUFtSTtRQUNuSSxJQUFJLFdBQVcsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO1lBQzFCLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFnQixFQUFFLEVBQUU7Z0JBQ3JDLE1BQU0sV0FBVyxHQUFxQixTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBVSxFQUFFLEVBQUUsR0FBRyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxLQUFLLFFBQVEsQ0FBQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNsSCxJQUFJLFdBQVcsRUFBRTtvQkFDYixNQUFNLG9CQUFvQixHQUFXLFdBQVcsQ0FBQyxPQUFPLENBQUMscUJBQXFCLEVBQUUsV0FBVyxDQUFXLENBQUM7b0JBQ3ZHLElBQUksQ0FBQyxvQkFBb0IsRUFBRTt3QkFDdkIsRUFBRSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQ2xCLFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLHdDQUF3QyxDQUFDOzhCQUNqRSxXQUFXLENBQUMsSUFBSTs4QkFDaEIsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMscUNBQXFDLENBQUMsQ0FBQyxDQUFBO3dCQUN2RSxXQUFXLEdBQUcsS0FBSyxDQUFDO3dCQUNwQixPQUFPO3FCQUNWO29CQUNELE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUM7b0JBQ3JCLE9BQU8sR0FBRyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksUUFBUSxFQUFFLEVBQUUsS0FBSyxvQkFBb0IsR0FBRyxDQUFDLENBQUM7b0JBQ3hFLE9BQU8sR0FBRyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksWUFBWSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLEtBQUssb0JBQW9CLEdBQUcsQ0FBQyxDQUFDO2lCQUM3RjtZQUNMLENBQUMsQ0FBQyxDQUFBO1lBQ0Ysb0dBQW9HO1NBQ3ZHO2FBQU0sSUFBSSxpQkFBaUIsRUFBRTtZQUMxQixPQUFPLEdBQUcsT0FBTyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxFQUFFLENBQUM7U0FDbkQ7UUFFRCxNQUFNLFdBQVcsR0FBRztZQUNoQixTQUFTLEVBQUUsT0FBTztTQUNyQixDQUFBO1FBRUQsSUFBSSxXQUFtQixDQUFDO1FBQ3hCLElBQUk7WUFDQSxXQUFXLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQztTQUM3QztRQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQ1IsRUFBRSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQ2xCLFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLHdDQUF3QyxDQUFDO2tCQUNqRSxXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQywrQ0FBK0MsQ0FBQyxDQUFDLENBQUE7WUFDakYsV0FBVyxHQUFHLEtBQUssQ0FBQztTQUN2QjtRQUVELElBQUksV0FBVyxFQUFFO1lBQ2IsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUNULE1BQU0sRUFBRSxNQUFNO2dCQUNkLEdBQUcsRUFBRSxjQUFjO2dCQUNuQixXQUFXLEVBQUUsa0JBQWtCO2dCQUMvQixJQUFJLEVBQUUsV0FBVzthQUNwQixDQUFDLENBQUM7U0FDTjtJQUNMLENBQUM7Q0FBQSIsImZpbGUiOiJEaXNjb3JkSW50ZWdyYXRpb24uanMiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUT0RPIGRpc2NvcmQtaW50ZWdyYXRpb24jMzQ6IFRocm93biBvbiBIb29rcy5vbigpLCBjYXVzZSBhbmQgZml4IHVua25vd25cclxuLyogZXNsaW50LWRpc2FibGUgQHR5cGVzY3JpcHQtZXNsaW50L25vLXVuc2FmZS1jYWxsICovXHJcblxyXG5pbXBvcnQgeyBBY3RvckRhdGEgfSBmcm9tIFwiQGxlYWd1ZS1vZi1mb3VuZHJ5LWRldmVsb3BlcnMvZm91bmRyeS12dHQtdHlwZXMvc3JjL2ZvdW5kcnkvY29tbW9uL2RhdGEvZGF0YS5tanMvYWN0b3JEYXRhXCI7XHJcblxyXG5sZXQgZ2FtZVVzZXJzOiBTdG9yZWREb2N1bWVudDxVc2VyPltdXHJcbmxldCBmb3VuZHJ5R2FtZTogR2FtZTtcclxuXHJcbi8vIERpc2NvcmQgdXNlci1pZHMgYXJlIGFsd2F5cyBleGFjdGx5IDE4IGRpZ2l0cy5cclxuY29uc3QgRElTQ09SRF9JRF9MRU5HVEggPSAxODtcclxuXHJcbmZ1bmN0aW9uIGdldEdhbWUoKTogR2FtZSB7XHJcbiAgICByZXR1cm4gZ2FtZTtcclxufVxyXG5cclxuSG9va3Mub25jZShcInJlYWR5XCIsIGZ1bmN0aW9uICgpIHtcclxuICAgIGdhbWVVc2VycyA9IChnYW1lLnVzZXJzKS5jb250ZW50cztcclxufSk7XHJcblxyXG5Ib29rcy5vbmNlKFwiaW5pdFwiLCBmdW5jdGlvbiAoKSB7XHJcbiAgICBmb3VuZHJ5R2FtZSA9IGdldEdhbWUoKTtcclxuICAgIC8vIGFkZCBzZXR0aW5ncyBvcHRpb24gZm9yIFVSTCBvZiBEaXNjb3JkIFdlYmhvb2tcclxuICAgIGZvdW5kcnlHYW1lLnNldHRpbmdzLnJlZ2lzdGVyKFwiZGlzY29yZC1pbnRlZ3JhdGlvblwiLCBcImRpc2NvcmRXZWJob29rXCIsIHtcclxuICAgICAgICBuYW1lOiBmb3VuZHJ5R2FtZS5pMThuLmxvY2FsaXplKFwiRElTQ09SRElOVEVHUkFUSU9OLlNldHRpbmdzRGlzY29yZFdlYmhvb2tcIiksXHJcbiAgICAgICAgaGludDogZm91bmRyeUdhbWUuaTE4bi5sb2NhbGl6ZShcIkRJU0NPUkRJTlRFR1JBVElPTi5TZXR0aW5nc0Rpc2NvcmRXZWJob29rSGludFwiKSxcclxuICAgICAgICBzY29wZTogXCJ3b3JsZFwiLFxyXG4gICAgICAgIGNvbmZpZzogdHJ1ZSxcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgZGVmYXVsdDogXCJcIixcclxuICAgIH0pO1xyXG4gICAgLy8gYWRkIHNldHRpbmdzIG9wdGlvbiBmb3IgcGluZ2luZyBieSBvbiBjaGFyYWN0ZXIgbmFtZVxyXG4gICAgZm91bmRyeUdhbWUuc2V0dGluZ3MucmVnaXN0ZXIoXCJkaXNjb3JkLWludGVncmF0aW9uXCIsIFwicGluZ0J5Q2hhcmFjdGVyTmFtZVwiLCB7XHJcbiAgICAgICAgbmFtZTogZm91bmRyeUdhbWUuaTE4bi5sb2NhbGl6ZShcIkRJU0NPUkRJTlRFR1JBVElPTi5TZXR0aW5nc1BpbmdCeUNoYXJhY3Rlck5hbWVcIiksXHJcbiAgICAgICAgaGludDogZm91bmRyeUdhbWUuaTE4bi5sb2NhbGl6ZShcIkRJU0NPUkRJTlRFR1JBVElPTi5TZXR0aW5nc1BpbmdCeUNoYXJhY3Rlck5hbWVIaW50XCIpLFxyXG4gICAgICAgIHNjb3BlOiBcIndvcmxkXCIsXHJcbiAgICAgICAgY29uZmlnOiB0cnVlLFxyXG4gICAgICAgIGRlZmF1bHQ6IHRydWUsXHJcbiAgICAgICAgdHlwZTogQm9vbGVhblxyXG4gICAgICAgIFxyXG4gICAgfSk7XHJcbiAgICAvLyBhZGQgc2V0dGluZ3Mgb3B0aW9uIGZvciBwaW5naW5nIGJ5IHVzZXIgbmFtZVxyXG4gICAgZm91bmRyeUdhbWUuc2V0dGluZ3MucmVnaXN0ZXIoXCJkaXNjb3JkLWludGVncmF0aW9uXCIsIFwicGluZ0J5VXNlck5hbWVcIiwge1xyXG4gICAgICAgIG5hbWU6IGZvdW5kcnlHYW1lLmkxOG4ubG9jYWxpemUoXCJESVNDT1JESU5URUdSQVRJT04uU2V0dGluZ3NQaW5nQnlVc2VyTmFtZVwiKSxcclxuICAgICAgICBoaW50OiBmb3VuZHJ5R2FtZS5pMThuLmxvY2FsaXplKFwiRElTQ09SRElOVEVHUkFUSU9OLlNldHRpbmdzUGluZ0J5VXNlck5hbWVIaW50XCIpLFxyXG4gICAgICAgIHNjb3BlOiBcIndvcmxkXCIsXHJcbiAgICAgICAgY29uZmlnOiB0cnVlLFxyXG4gICAgICAgIGRlZmF1bHQ6IHRydWUsXHJcbiAgICAgICAgdHlwZTogQm9vbGVhblxyXG4gICAgfSk7XHJcbn0pO1xyXG5cclxuLy8gYWRkIGluIHRoZSBleHRyYSBmaWVsZCBmb3IgRGlzY29yZElEXHJcbkhvb2tzLm9uKFwicmVuZGVyVXNlckNvbmZpZ1wiLCBhc3luYyBmdW5jdGlvbiAoY29uZmlnOiBVc2VyQ29uZmlnLCBlbGVtZW50OiBKUXVlcnkpIHtcclxuXHJcbiAgICAvLyBmaW5kIHRoZSB1c2VyIHRoYXQgeW91J3JlIG9wZW5pbmcgY29uZmlnIGZvclxyXG4gICAgY29uc3QgZm91bmRyeVVzZXI6IFN0b3JlZERvY3VtZW50PFVzZXI+ID0gZm91bmRyeUdhbWUudXNlcnMuY29udGVudHMuZmlsdGVyKCh1c2VyOiBVc2VyKSA9PiB7IHJldHVybiB1c2VyLmlkID09PSAoY29uZmlnLm9iamVjdCkuZGF0YS5faWQgfSlbMF07XHJcblxyXG4gICAgLy8gZ2V0IHRoZWlyIERpc2NvcmQgSUQgaWYgaXQgZXhpc3RzXHJcbiAgICBsZXQgZGlzY29yZFVzZXJJZDogc3RyaW5nID0gYXdhaXQgZm91bmRyeVVzZXIuZ2V0RmxhZygnZGlzY29yZC1pbnRlZ3JhdGlvbicsICdkaXNjb3JkSUQnKSBhcyBzdHJpbmdcclxuICAgIGRpc2NvcmRVc2VySWQgPSBkaXNjb3JkVXNlcklkID8gZGlzY29yZFVzZXJJZCA6IFwiXCJcclxuXHJcbiAgICAvLyBjcmVhdGUgdGhlIGlucHV0IGZpZWxkIHRvIGNvbmZpZ3VyZSBpdC5cclxuICAgIGNvbnN0IGRpc2NvcmRJZElucHV0ID0gYDxpbnB1dCB0eXBlPVwidGV4dFwiIG5hbWU9XCJkaXNjb3JkLWlkLWNvbmZpZ1wiIHZhbHVlPVwiJHtkaXNjb3JkVXNlcklkfVwiIGRhdGEtZHR5cGU9XCJTdHJpbmdcIj5gXHJcblxyXG4gICAgY29uc3QgZGlzY29yZElEU2V0dGluZyA9IGBcclxuICAgICAgICA8ZGl2IGlkPVwiZGlzY29yZC1pZC1zZXR0aW5nXCIgY2xhc3M9XCJmb3JtLWdyb3VwIGRpc2NvcmRcIj5cclxuICAgICAgICAgICAgPGxhYmVsPiR7Zm91bmRyeUdhbWUuaTE4bi5sb2NhbGl6ZShcIkRJU0NPUkRJTlRFR1JBVElPTi5Vc2VyRGlzY29yZElkTGFiZWxcIil9PC9sYWJlbD5cclxuICAgICAgICAgICAgJHtkaXNjb3JkSWRJbnB1dH1cclxuICAgICAgICA8L2Rpdj5gXHJcblxyXG4gICAgLy8gUHV0IHRoZSBpbnB1dCBmaWVsZHMgYmVsb3cgdGhlIFwiUGxheWVyIENvbG9yIGdyb3VwXCIgZmllbGQuXHJcbiAgICBjb25zdCBwbGF5ZXJDb2xvckdyb3VwID0gZWxlbWVudC5maW5kKCcuZm9ybS1ncm91cCcpLmVxKDIpO1xyXG4gICAgcGxheWVyQ29sb3JHcm91cC5hZnRlcihbJChkaXNjb3JkSURTZXR0aW5nKV0pO1xyXG5cclxuICAgIGlmIChmb3VuZHJ5VXNlci5pc0dNKSB7XHJcbiAgICAgICAgLypcclxuICAgICAgICAvLyBnZXQgdGhlaXIgR00gTm90aWZpY2F0aW9uIHN0YXR1cyBpZiBpdCBleGlzdHMsIGRlZmF1bHRpbmcgdG8gdHJ1ZS5cclxuICAgICAgICBjb25zdCBzZW5kR01Ob3RpZmljYXRpb25zOiBib29sZWFuID0gYXdhaXQgZm91bmRyeVVzZXIuZ2V0RmxhZygnZGlzY29yZC1pbnRlZ3JhdGlvbicsICdzZW5kR01Ob3RpZmljYXRpb25zJykgYXMgYm9vbGVhbjtcclxuXHJcbiAgICAgICAgXHJcbiAgICAgICAgY29uc3QgaXNDaGVja2VkID0gc2VuZEdNTm90aWZpY2F0aW9ucyA/IFwiY2hlY2tlZFwiIDogXCJcIjtcclxuICAgICAgICBjb25zdCBnbU5vdGlmaWNhdGlvbkNoZWNrYm94ID0gYDxpbnB1dCB0eXBlPVwiY2hlY2tib3hcIiBuYW1lPVwiZ20tbm90aWZpY2F0aW9uLWNvbmZpZ1wiICR7aXNDaGVja2VkfT5gXHJcblxyXG4gICAgICAgIGNvbnN0IGdtTm90aWZpY2F0aW9uU2V0dGluZyA9IGBcclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbD4ke2dhbWUuaTE4bi5sb2NhbGl6ZShcIkRJU0NPUkRJTlRFR1JBVElPTi5HTU5vdGlmaWNhdGlvbnNMYWJlbFwiKSBhcyBzdHJpbmd9PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICR7Z21Ob3RpZmljYXRpb25DaGVja2JveH1cclxuICAgICAgICAgICAgPC9kaXY+YFxyXG4gICAgICAgICovXHJcbiAgICB9XHJcbn0pO1xyXG5cclxuLy8gY29tbWl0IGFueSBjaGFuZ2VzIHRvIHVzZXJDb25maWdcclxuSG9va3Mub24oXCJjbG9zZVVzZXJDb25maWdcIiwgYXN5bmMgZnVuY3Rpb24gKGNvbmZpZzogVXNlckNvbmZpZywgZWxlbWVudDogSlF1ZXJ5KSB7XHJcbiAgICAvLyBmaW5kIHRoZSB1c2VyIHRoYXQgdGhlIGNvbmZpZyB3YXMgb3BlbiBmb3JcclxuICAgIGNvbnN0IGZvdW5kcnlVc2VyOiBTdG9yZWREb2N1bWVudDxVc2VyPiA9IGdhbWVVc2Vycy5maWx0ZXIodXNlciA9PiB7IHJldHVybiB1c2VyLmlkID09PSAoY29uZmlnLm9iamVjdCkuZGF0YS5faWQgfSlbMF07XHJcbiAgICBjb25zdCBkaXNjb3JkSUQ6IHN0cmluZyA9IChlbGVtZW50LmZpbmQoXCJpbnB1dFtuYW1lID0gJ2Rpc2NvcmQtaWQtY29uZmlnJ11cIilbMF0gYXMgSFRNTElucHV0RWxlbWVudCkudmFsdWU7XHJcblxyXG4gICAgaWYgKGRpc2NvcmRJRC5sZW5ndGggIT09IERJU0NPUkRfSURfTEVOR1RIIHx8IGlzTmFOKHBhcnNlSW50KGRpc2NvcmRJRCkpKSB7XHJcbiAgICAgICAgdWkubm90aWZpY2F0aW9ucy5lcnJvcihmb3VuZHJ5R2FtZS5pMThuLmxvY2FsaXplKFwiRElTQ09SRElOVEVHUkFUSU9OLkludmFsaWRJZEVycm9yXCIpKVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgICBhd2FpdCBmb3VuZHJ5VXNlci51cGRhdGUoeyAnZmxhZ3MuZGlzY29yZC1pbnRlZ3JhdGlvbi5kaXNjb3JkSUQnOiBkaXNjb3JkSUQgfSk7XHJcbiAgICB9XHJcbiAgICAvKlxyXG4gICAgY29uc3QgZ21Ob3RpZmljYXRpb25FbGVtZW50ID0gZWxlbWVudC5maW5kKFwiaW5wdXRbbmFtZSA9ICdnbS1ub3RpZmljYXRpb24tY29uZmlnJ11cIik7XHJcbiAgICBsZXQgZ21Ob3RpZmljYXRpb25zOiBib29sZWFuXHJcbiAgICBpZiAoZ21Ob3RpZmljYXRpb25FbGVtZW50ICYmIGdtTm90aWZpY2F0aW9uRWxlbWVudFswXSkge1xyXG4gICAgICAgIGdtTm90aWZpY2F0aW9ucyA9IChlbGVtZW50LmZpbmQoXCJpbnB1dFtuYW1lID0gJ2dtLW5vdGlmaWNhdGlvbi1jb25maWcnXVwiKVswXSBhcyBIVE1MSW5wdXRFbGVtZW50KS5jaGVja2VkO1xyXG4gICAgfVxyXG4gICAgKi9cclxuICAgIC8vIHVwZGF0ZSB0aGUgZmxhZ1xyXG4gICAgLy9hd2FpdCBmb3VuZHJ5VXNlci51cGRhdGUoeyAnZmxhZ3MuZGlzY29yZC1pbnRlZ3JhdGlvbi5zZW5kR01Ob3RpZmljYXRpb25zJzogZ21Ob3RpZmljYXRpb25zIH0pO1xyXG59KTtcclxuXHJcbi8qKlxyXG4gKiBUbyBmb3J3YXJkIGEgbWVzc2FnZSB0byBkaXNjb3JkLCBkbyBvbmUgb2YgdHdvIHRoaW5nczpcclxuICogXHJcbiAqIC1pbmNsdWRlIFwiQDx1c2VybmFtZT5cIiBmb3IgYSB1c2VyIGluIHRoZSBnYW1lLCBpdCB3aWxsIHRoZW4gbG9vayB1cCB0aGUgY29ycmVzcG9uZGluZyBkaXNjb3JkSUQgXHJcbiAqIGFuZCBzZW5kIGEgbWVzc2FnZSBwaW5naW5nIHRoZW0uIElmIHlvdSBAIG11bHRpcGxlIHBlb3BsZSwgaXQgd2lsbCBwaW5nIGFsbCBvZiB0aGVtLiBXaWxsIG5vdFxyXG4gKiBzZW5kIGEgbWVzc2FnZSB1bmxlc3MgdGhlIHVzZXJuYW1lIG1hdGNoZXMgdXAgd2l0aCBhbiBhY3R1YWwgdXNlci5cclxuICogXHJcbiAqIC1pbmNsdWRlIFwiQERpc2NvcmRcIiwgd2hpY2ggd2lsbCB1bmNvbmRpdGlvbmFsbHkgZm9yd2FyZCB0aGUgbWVzc2FnZSAobWludXMgdGhlIEBEaXNjb3JkKSB0byB0aGUgRGlzY29yZCBXZWJob29rLlxyXG4gKi9cclxuXHJcbi8vIHdoZW5ldmVyIHNvbWVvbmUgc2VuZHMgYSBjaGF0IG1lc3NhZ2UsIGlmIGl0IGlzIG1hcmtlZCB1cCBwcm9wZXJseSBmb3J3YXJkIGl0IHRvIERpc2NvcmQuXHJcbkhvb2tzLm9uKFwiY2hhdE1lc3NhZ2VcIiwgZnVuY3Rpb24gKF9jaGF0TG9nOiBDaGF0TG9nLCBtZXNzYWdlOiBzdHJpbmcpIHtcclxuICAgIGNvbnN0IGRpc2NvcmRUYWdzOiBzdHJpbmdbXSA9IFtdO1xyXG4gICAgZGlzY29yZFRhZ3MucHVzaChcIkBEaXNjb3JkXCIpO1xyXG5cclxuICAgIGZvdW5kcnlHYW1lLnVzZXJzLmZvckVhY2godXNlciA9PiB7XHJcbiAgICAgICAgZGlzY29yZFRhZ3MucHVzaChgQCR7dXNlci5uYW1lfWApXHJcbiAgICAgICAgaWYgKHVzZXIuY2hhcmFjdGVyKSB7XHJcbiAgICAgICAgICAgIGRpc2NvcmRUYWdzLnB1c2goYEAkeyh1c2VyLmNoYXJhY3RlciBhcyBBY3RvckRhdGEpLm5hbWV9YClcclxuICAgICAgICB9XHJcbiAgICB9KVxyXG5cclxuICAgIGxldCBzaG91bGRTZW5kTWVzc2FnZSA9IGZhbHNlO1xyXG4gICAgZGlzY29yZFRhZ3MuZm9yRWFjaCh0YWcgPT4ge1xyXG4gICAgICAgIGlmIChtZXNzYWdlLmluY2x1ZGVzKHRhZykpIHtcclxuICAgICAgICAgICAgc2hvdWxkU2VuZE1lc3NhZ2UgPSB0cnVlO1xyXG4gICAgICAgIH1cclxuICAgIH0pXHJcblxyXG4gICAgaWYgKHNob3VsZFNlbmRNZXNzYWdlKSB7XHJcbiAgICAgICAgSG9va3MuY2FsbEFsbChcInNlbmREaXNjb3JkTWVzc2FnZVwiLCBtZXNzYWdlKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgLy8gVE9ETyBkaXNjb3JkLWludGVncmF0aW9uIzM1OiBUaGlzIGV4aXN0cyBhcyBhIHdheSB0byB0ZXN0IHdoZW4gYSBtZXNzYWdlIGlzIG5vdCBzZW50LiBGaWd1cmUgb3V0IGEgd2F5IHRvIGRvIGl0IHdpdGhvdXQgbW9kaWZ5aW5nIHRoZSBjb2RlIGxhdGVyLlxyXG4gICAgICAgIGNvbnNvbGUubG9nKFwiTWVzc2FnZSBub3Qgc2VudC5cIilcclxuICAgIH1cclxufSk7XHJcblxyXG5Ib29rcy5vbihcInNlbmREaXNjb3JkTWVzc2FnZVwiLCBmdW5jdGlvbiAobWVzc2FnZTogc3RyaW5nKSB7XHJcbiAgICBzZW5kRGlzY29yZE1lc3NhZ2UobWVzc2FnZSkuY2F0Y2goKHJlYXNvbikgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IocmVhc29uKTtcclxuICAgIH0pO1xyXG59KTtcclxuXHJcbi8qKlxyXG4gKiBTZW5kcyBhIG1lc3NhZ2UgdGhyb3VnaCB0aGUgZGlzY29yZCB3ZWJob29rIGFzIGNvbmZpZ3VyZWQgaW4gc2V0dGluZ3MuXHJcbiAqIFxyXG4gKiBNZXNzYWdlcyB0aGF0IHBpbmcgdXNlcnMgaW4gRGlzY29yZCBuZWVkIHRvIGhhdmUgXCJAPGdhbWVVc2VyTmFtZT5cIiBhbmQgdGhlIHVzZXJzIG11c3QgaGF2ZSB0aGVpciBkaXNjb3JkIElEcyBjb25maWd1cmVkLlxyXG4gKiBcclxuICogQHBhcmFtIG1lc3NhZ2UgVGhlIG1lc3NhZ2UgdG8gZm9yd2FyZCB0byBEaXNjb3JkXHJcbiAqL1xyXG5hc3luYyBmdW5jdGlvbiBzZW5kRGlzY29yZE1lc3NhZ2UobWVzc2FnZTogc3RyaW5nKSB7XHJcblxyXG4gICAgbGV0IHNlbmRNZXNzYWdlID0gdHJ1ZTtcclxuXHJcbiAgICBjb25zdCBkaXNjb3JkV2ViaG9vayA9IGdhbWUuc2V0dGluZ3MuZ2V0KCdkaXNjb3JkLWludGVncmF0aW9uJywgJ2Rpc2NvcmRXZWJob29rJykgYXMgc3RyaW5nO1xyXG4gICAgaWYgKCFkaXNjb3JkV2ViaG9vaykge1xyXG4gICAgICAgIHVpLm5vdGlmaWNhdGlvbnMuZXJyb3IoXHJcbiAgICAgICAgICAgIGZvdW5kcnlHYW1lLmkxOG4ubG9jYWxpemUoXCJESVNDT1JESU5URUdSQVRJT04uQ291bGROb3RTZW5kTWVzc2FnZVwiKVxyXG4gICAgICAgICAgICArIGZvdW5kcnlHYW1lLmkxOG4ubG9jYWxpemUoXCJESVNDT1JESU5URUdSQVRJT04uTm9EaXNjb3JkV2ViaG9va0Vycm9yXCIpKVxyXG4gICAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCB1c2Vyc1RvQ2hhcnM6IE1hcDxzdHJpbmcsIHN0cmluZz4gPSBuZXcgTWFwPHN0cmluZywgc3RyaW5nPigpO1xyXG5cclxuICAgIGNvbnN0IHVzZXJzVG9QaW5nOiBzdHJpbmdbXSA9IFtdO1xyXG5cclxuICAgIGdhbWVVc2Vycy5mb3JFYWNoKCh1c2VyOiBVc2VyKSA9PiB7XHJcbiAgICAgICAgaWYgKG1lc3NhZ2UuaW5kZXhPZihgQCR7dXNlci5uYW1lfWApICE9PSAtMSkge1xyXG4gICAgICAgICAgICB1c2Vyc1RvUGluZy5wdXNoKHVzZXIubmFtZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh1c2VyLmNoYXJhY3Rlcikge1xyXG4gICAgICAgICAgICB1c2Vyc1RvQ2hhcnMuc2V0KHVzZXIubmFtZSwgKCh1c2VyLmNoYXJhY3RlciBhcyBBY3RvckRhdGEpLm5hbWUpKTtcclxuICAgICAgICB9XHJcbiAgICB9KVxyXG5cclxuICAgIHVzZXJzVG9DaGFycy5mb3JFYWNoKChjaGFyTmFtZSA6IHN0cmluZywgdXNlck5hbWUgOiBzdHJpbmcsIF9tYXApID0+IHtcclxuICAgICAgICAvLyBQaW5nIGlmIGEgdXNlciBvciB0aGVpciBjaGFyYWN0ZXIncyBuYW1lIGlzIHRhZ2dlZFxyXG4gICAgICAgIGlmIChtZXNzYWdlLmluZGV4T2YoYEAke2NoYXJOYW1lfWApICE9PSAtMSkge1xyXG4gICAgICAgICAgICB1c2Vyc1RvUGluZy5wdXNoKHVzZXJOYW1lKTtcclxuICAgICAgICB9IFxyXG4gICAgfSlcclxuICAgIFxyXG4gICAgLy8gc2VhcmNoIGZvciBARGlzY29yZCBpbiB0aGUgbWVzc2FnZVxyXG4gICAgY29uc3Qgc2hvdWxkUGluZ0Rpc2NvcmQ6IGJvb2xlYW4gPSAobWVzc2FnZS5zZWFyY2goYEBEaXNjb3JkYCkgIT09IC0xKTtcclxuXHJcbiAgICAvLyBpZiBpdCBmb3VuZCBhbnkgQDx1c2VybmFtZT4gdmFsdWVzLCByZXBsYWNlIHRoZSB2YWx1ZXMgaW4gdGhlIG1lc3NhZ2Ugd2l0aCBhcHByb3ByaWF0ZSBkaXNjb3JkIHBpbmdzLCB0aGVuIHNlbmQgZGlzY29yZCBtZXNzYWdlLlxyXG4gICAgaWYgKHVzZXJzVG9QaW5nLmxlbmd0aCAhPT0gMCkge1xyXG4gICAgICAgIHVzZXJzVG9QaW5nLmZvckVhY2goKHVzZXJOYW1lOiBzdHJpbmcpID0+IHtcclxuICAgICAgICAgICAgY29uc3QgY3VycmVudFVzZXI6IFVzZXIgfCB1bmRlZmluZWQgPSBnYW1lVXNlcnMuZmlsdGVyKCh1c2VyOiBVc2VyKSA9PiB7IHJldHVybiB1c2VyLmRhdGEubmFtZSA9PT0gdXNlck5hbWUgfSlbMF07XHJcbiAgICAgICAgICAgIGlmIChjdXJyZW50VXNlcikge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgY3VycmVudFVzZXJEaXNjb3JkSUQ6IHN0cmluZyA9IGN1cnJlbnRVc2VyLmdldEZsYWcoJ2Rpc2NvcmQtaW50ZWdyYXRpb24nLCAnZGlzY29yZElEJykgYXMgc3RyaW5nO1xyXG4gICAgICAgICAgICAgICAgaWYgKCFjdXJyZW50VXNlckRpc2NvcmRJRCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHVpLm5vdGlmaWNhdGlvbnMuZXJyb3IoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvdW5kcnlHYW1lLmkxOG4ubG9jYWxpemUoXCJESVNDT1JESU5URUdSQVRJT04uQ291bGROb3RTZW5kTWVzc2FnZVwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICArIGN1cnJlbnRVc2VyLm5hbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgKyBmb3VuZHJ5R2FtZS5pMThuLmxvY2FsaXplKFwiRElTQ09SRElOVEVHUkFUSU9OLlVzZXJIYXNOb0lkRXJyb3JcIikpXHJcbiAgICAgICAgICAgICAgICAgICAgc2VuZE1lc3NhZ2UgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhtZXNzYWdlKTtcclxuICAgICAgICAgICAgICAgIG1lc3NhZ2UgPSBtZXNzYWdlLnJlcGxhY2UoYEAke3VzZXJOYW1lfWAsIGA8QCR7Y3VycmVudFVzZXJEaXNjb3JkSUR9PmApO1xyXG4gICAgICAgICAgICAgICAgbWVzc2FnZSA9IG1lc3NhZ2UucmVwbGFjZShgQCR7dXNlcnNUb0NoYXJzLmdldCh1c2VyTmFtZSl9YCwgYDxAJHtjdXJyZW50VXNlckRpc2NvcmRJRH0+YCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KVxyXG4gICAgICAgIC8vIGVsc2UgaWYgRGlzY29yZCBhcyBhIHdob2xlIGlzIGJlaW5nIHBpbmdlZCwgcmVtb3ZlIHRoZSBcIkBEaXNjb3JkXCIgcGFydCBhbmQgdGhlbiBzZW5kIHRoZSBtZXNzYWdlLlxyXG4gICAgfSBlbHNlIGlmIChzaG91bGRQaW5nRGlzY29yZCkge1xyXG4gICAgICAgIG1lc3NhZ2UgPSBtZXNzYWdlLnNwbGl0KFwiQERpc2NvcmRcIikucG9wKCkgfHwgXCJcIjtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBtZXNzYWdlSlNPTiA9IHtcclxuICAgICAgICBcImNvbnRlbnRcIjogbWVzc2FnZVxyXG4gICAgfVxyXG5cclxuICAgIGxldCBqc29uTWVzc2FnZTogc3RyaW5nO1xyXG4gICAgdHJ5IHtcclxuICAgICAgICBqc29uTWVzc2FnZSA9IEpTT04uc3RyaW5naWZ5KG1lc3NhZ2VKU09OKTtcclxuICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICB1aS5ub3RpZmljYXRpb25zLmVycm9yKFxyXG4gICAgICAgICAgICBmb3VuZHJ5R2FtZS5pMThuLmxvY2FsaXplKFwiRElTQ09SRElOVEVHUkFUSU9OLkNvdWxkTm90U2VuZE1lc3NhZ2VcIilcclxuICAgICAgICAgICAgKyBmb3VuZHJ5R2FtZS5pMThuLmxvY2FsaXplKFwiRElTQ09SRElOVEVHUkFUSU9OLkNvdWxkTm90U3RyaW5naWZ5SnNvbkVycm9yXCIpKVxyXG4gICAgICAgIHNlbmRNZXNzYWdlID0gZmFsc2U7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKHNlbmRNZXNzYWdlKSB7XHJcbiAgICAgICAgYXdhaXQgJC5hamF4KHtcclxuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXHJcbiAgICAgICAgICAgIHVybDogZGlzY29yZFdlYmhvb2ssXHJcbiAgICAgICAgICAgIGNvbnRlbnRUeXBlOiBcImFwcGxpY2F0aW9uL2pzb25cIixcclxuICAgICAgICAgICAgZGF0YToganNvbk1lc3NhZ2VcclxuICAgICAgICB9KTtcclxuICAgIH1cclxufSJdfQ==
