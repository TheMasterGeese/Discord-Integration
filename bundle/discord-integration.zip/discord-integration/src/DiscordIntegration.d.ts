/**
* Sends a message through the discord webhook as configured in settings.
*
* Messages that ping users in Discord need to have "@<gameUserName>" and the users must have their discord IDs configured.
*
* @param message The message to forward to Discord
*/
export declare function sendDiscordMessage(message: string): Promise<void>;
